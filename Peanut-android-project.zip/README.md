# Peanut (v3)

**Peanut** — 30 din ka challenge, apne room ke saath. Tasks, habits, study planner, focus timer,
community room (chat + games), aur **har room ka apna music channel**.

Plain HTML/CSS/JS (ES modules) + Firebase (Auth + Firestore). Build step nahi chahiye.

> Pehle is app ka naam "NNN" tha. Ab iska naam **Peanut** hai — mascot (peanut + sprout), logo,
> splash aur UI sab isi ke hisaab se banaye gaye hain. Storage keys (`nnn_*`) jaan boojh kar
> same rakhe gaye hain taaki purana data safe rahe.

---

## Firebase me 3 cheezein (ek baar)

1. **Authentication > Sign-in method** me **Email/Password** enable karo.
2. **Firestore Database > Create database** (production mode). Phir **Rules** tab me
   `firestore.rules` ka poora text paste karke **Publish** karo.
3. `firebase-config.js` me jo key hai wo screenshot se utaari gayi hai. Agar login pe
   "API key galat hai" aaye to Console > Project settings > Your apps se config dobara copy karo.

## Chalana

- Local test: is folder me `npx serve .` chalao (file:// se kaam nahi karega, modules http maangte hain).
- Deploy: `npm i -g firebase-tools`, `firebase login`, phir `firebase deploy`.
- Phone pe: Chrome me link kholo > menu > **Add to Home screen / Install app**.
- Launcher icon (Peanut), splash aur app naam `manifest.json` + `icons/` se aate hain.
- APK: GitHub Actions pe banta hai (free). `github-workflow/build-apk.yml` dekho.
  1. github.com pe naya private repo banao.
  2. Is zip ko repo me upload karo (file ka naam kuch bhi rakh sakte ho — workflow pehla `.zip` utha leta hai).
  3. Add file > Create new file, naam: `.github/workflows/build-apk.yml`, andar `github-workflow/build-apk.yml` ka text paste karo, Commit.
  4. Actions tab > **Build Peanut APK** > Run workflow. 4-6 minute baad run ke neeche Artifacts me `Peanut-apk` milega.
  5. Download karke zip kholo, `app-debug.apk` install karo (Unknown sources allow karna padega).
  - APK me reminders native notifications se chalte hain, app band hone par bhi.

---

## Music — har community ka apna channel

Ye app ka naya hissa hai. Music ab ek **per-room channel** hai:

- Room code se ek channel auto assign hota hai (hash), isliye **alag alag communities me alag alag music** chalta hai.
- Room owner Music screen se community channel badal sakta hai. Member apni pasand ka channel locally override kar sakta hai.
- 8 channels hain — Lo-Fi Chill, Midnight Drive, Sunny Side, Rain Room, Focus Pulse, **Bloom**, Zen Garden, Desi Lo-Fi.
- Play/pause header ke note button se, agla channel `▶|` button se, poora player **More > Music** se.

**Engine:** original WebAudio synthesis (pad + bass + arp + drums + delay + reverb + limiter).
Koi copyrighted sample nahi — isliye offline bhi chalta hai aur app chhoti rehti hai.

**Inspiration / credit:** [Bloomee](https://github.com/HemantKArya/BloomeeTunes) — open-source
music player by HemantKArya (GPL-2.0). Player flow (channel list + per-community mood + local
files) yahin se inspired hai.

**Apne gaane:** mp3 `music/` folder me rakho aur `music/manifest.json` me list karo:

```json
{ "lofi": [{ "title": "Lofi 1", "src": "music/lofi1.mp3" }] }
```

Channel id `music.js` ke `CHANNELS` se match hona chahiye. Sirf wo gaane daalo jinke rights tumhare paas hain.

---

## Planner — ab sach me kaam karta hai

Pehle planner **khaali** dikhta tha. Do wajah thi, dono fix ho gayi:

1. Planner sirf `study/homework/...` types dikhata tha — default `task` type ke saare tasks invisible the.
   Ab **saare types** dikhte hain (task, homework, assignment, project, backlog, study, revision, test).
2. Smart plan sessions ko **ek hi din** pe thoos deta tha. Ab sessions exam ke aage **dino me spread** hoti hain,
   aur exam na ho tab bhi backlog tasks se plan ban jata hai.

Ab planner me hai:

- **Aaj / Kal / Week / Backlog** views
- Summary strip — bache hue tasks, done, focus minutes, backlog count
- Exam, event aur task — sab ek hi timeline me
- Backlog me ek-tap **"aaj" / "kal"** scheduling
- **Smart study plan** — chapter-wise sessions + weak-chapter revision, approve karne par hi tasks bante hain

Aur **Day timeline** (More > Day timeline): time-blocked schedule jo routine, events, exams aur tasks
ko dekh kar khud time slots me baantta hai. Raat ke 10 baje ke baad kholo to plan kal subah 7:00 se
shuru hota hai (pehle ye khaali aa raha tha).

---

## Games — 9 games, puri tarah playable

Pehle sirf 4 game the (aur 2 "jald aa raha hai" lock). Ab **9 games** hain, sab khelne layak:

| Game | Type | Kaise khele |
|---|---|---|
| Tic-Tac-Toe | 2 Player (real-time) | Code bhejo, board pe X/O |
| Math Speed Battle | 2 Player (real-time) | 60 sec, dono ko same sawaal |
| **Rock-Paper-Scissors** | 2 Player (real-time) | ✊✋✌️ — dono pick kare, result dikhe |
| **Quiz Battle** | 2 Player (real-time) | 5 MCQ sawaal, head-to-head, answer reveal |
| Memory Challenge | Solo | Pattern yaad rakh, 3 levels |
| Daily Brain | Solo | Roz ek naya 5-question puzzle |
| **2048 Merge** | Solo | Arrows / swipe / on-screen buttons |
| **Word Challenge** | Solo | Scrabbled word ko solve karo (40s timer + hint) |
| **Reflex Test** | Solo | 5 rounds, green hote hi tap — best ms save |

**Games hub UI bilkul naya:** hero art, **filter chips** (All / 2 Player / Solo), har game ka apna
gradient art tile, aur har card par best-score badge. Solo games ke best scores `users/{uid}` me
`gameBest` me save hote hain aur room leaderboard me dikhte hain.

---

## Music — OpenTune + local songs + 16 channels

Spotify hata diya gaya. Ab Music section **OpenTune** (Arturo254 ka open-source YouTube Music
client, GPL-3.0 — <https://github.com/Arturo254/OpenTune>) se inspired hai.

### 1) OpenTune — streaming (ad-free, no login)

- **Search** — song / artist / album, YouTube Music catalogue se.
- **Playback** — direct stream (no ads, no login). Background me bhi chalta hai (MediaSession +
  lock-screen controls).
- **Library** — saved tracks + playlists, device me locally save.
- **Silence skip** — silent stretch ko automatically skip karta hai.
- **Audio normalize** — loud/soft tracks ko ek level pe laata hai.
- **Tempo & pitch control** — 0.5× se 2× tak, pitch lock ke saath.
- **Server (Piped / Invidious)** — dono open-source YouTube frontends hain. App khud ek kaam
  karta server dhoondhta hai; **Music > OpenTune > Server > Edit** se apna server daal sakte ho
  (recommended — public instances kabhi down ho jaate hain).

### 2) Local Music — device ke gaane

- Mp3/wav/m4a device se add karo. Audio **IndexedDB** me store hota hai, reload ke baad bhi rehta hai.
- Kisi gaane ko "is channel me lagao" karke **kisi bhi** channel se jod sakte ho.

### 3) Channels — 16, do alag-alag sets

| Set | Count | Naam / tag |
|---|---|---|
| **Hinglish channels** | 8 | Lo-Fi Chill, Midnight Drive, Sunny Side, Rain Room, Focus Pulse, Bloom, Zen Garden, Desi Lo-Fi — Hinglish tag ke saath ("khidki khuli", "khaali highway", "Arpeggios jo phoolte hain") |
| **English channels** | 8 | Lo-Fi Chill, Neon Nights, Golden Hour, Rainy Window, Deep Focus, Bloom, Quiet Garden, Desi Beats — pure English tag ke saath |

Do sets **independent** hain: room ka community channel kisi bhi set se ho sakta hai, member apna
local channel override kar sakta hai, aur local gaana kisi bhi channel me lagaya ja sakta hai.
Dono sets me same mood ka pattern alag parameters se banta hai, isliye sound bhi alag hai.

Engine: original WebAudio synthesis (pad + bass + arp + drums + delay + reverb + limiter) —
koi copyrighted sample nahi, offline bhi chalta hai.

**Credit:** [Bloomee](https://github.com/HemantKArya/BloomeeTunes) (GPL-2.0) — channel/player flow
se inspired; [OpenTune](https://github.com/Arturo254/OpenTune) (GPL-3.0) — streaming section.

## Language — 10 bhashayein, login page par switch

**English, हिन्दी, বাংলা, தமிழ், తెలుగు, ಕನ್ನಡ, മലയാളം, ગુજરાતી, ਪੰਜਾਬੀ, मराठी**

- **Login page par hi globe button** — login se pehle language badal sakte ho.
- Settings > Language me bhi hai (compact chip strip).
- 232 strings × 10 bhashayein translate hain: nav, headings, buttons, section labels, games,
  music, settings, auth screen — sab kuch.
- Device ki language detect hoti hai (pehli baar).
- Indic fonts (Noto Sans Devanagari/Tamil/Telugu/…) Google Fonts se load hote hain, isliye
  har script sahi render hoti hai.

---

## Avatar / Memojis — functional face shape

Pehle "face shape" sirf outline badalta tha — aankh, naak aur mooh hamesha wahi jagah rehte the.
Ab har shape apni **geometry** deti hai (width, jaw, cheek, chin) aur saare features usi hisaab se
position hote hain:

- 7 shapes: Round, Oval, Square, Heart, Diamond, Long, Triangle
- **Face width** aur **Face length** sliders (82%–122%)
- Square shape me flat top + seedhi jaw + hard corners
- Heart/Diamond/Triangle me narrow chin, wide temples
- Baal, cap, glasses, daadhi — sab face ke size ke saath adjust hote hain
- 8 ready-made memoji presets — har ek alag face shape

Ye real 3D engine nahi hai: layered 2.5D SVG hai jisme rotate slider head ko ghumata hai.
Budget phones pe halka chalta hai.

---

## Themes

8 themes: **Garden** (dark), **Cream** (light), **Vapor**, **Bubble**, **Ocean**, **Sunset**, **Forest**, **Ink**.
Profile sheet me tap karke badlo. Language (English/हिन्दी), bada text, high contrast aur kam animation
bhi Settings me hai.

---

## UI / images

- Cards pe layer + soft shadows, gaps aur padding bade (pehle "congested" lagta tha).
- Naye illustrations: home, tracker, study, community, music hero + empty-state mascot + login banner
  (`assets/art/*.webp`, total ~160 KB).
- Now-playing strip header ke neeche, jab music chal raha ho.

---

## Reminders

Notifications tab tak chalti hain jab app khula ho ya background me ho (installed app). App poori tarah
band hone par reminder ke liye Firebase Cloud Messaging + server chahiye, wo is version me nahi hai.

---

## Files

`core.js` (firebase, data layer, sheets), `notify.js` (reminders), `tasks.js` (tasks/habits/focus),
`study.js` (syllabus, datesheet, **planner**, revision, scores), `life.js` (events, calendar, notes, search, .ics),
`insights.js` (analytics, XP/badges, **day timeline**, settings, backup, PIN), `music.js` (**per-room music engine**),
`localmusic.js` (**device se gaane, IndexedDB**), `opentune.js` (**YouTube Music client — search,
streams, library, silence-skip, normalize, tempo/pitch**),
`i18n.js` + `i18n/*.js` (**10 bhashayein**), `avatar.js` (**memojis + face geometry**),
`emoji.js`, `games.js` (**9 games**), `home.js`, `parse.js`.

**Ho chuka aur headless Chromium me (mock Firebase ke saath) test hua:**
5-tab nav, Student/Adult mode, tasks (subtasks, repeat, priority), habits (streak, rest days, weekdays),
focus timer + history, syllabus/chapters/topics/revision, datesheet (list+calendar, text-paste import),
test scores, **study planner (saare task types, backlog, smart plan, din-me spread)**,
**day timeline (late-night fix, routine/exam/event conflicts)**, events, universal calendar, notes,
global search, analytics + XP + badges, **avatar creator (7 face shapes + width/length sliders)**,
emoji picker, room chat/reactions/avatar reactions/announcement, games, PIN lock, language/accessibility,
**music engine (16 channels — 8 Hinglish + 8 English, per-room channel, visualizer, volume,
now-playing strip)**, **local music (IndexedDB)**, **OpenTune streaming (search, library,
silence-skip, normalize, tempo/pitch)**, **9 games** (Tic-Tac-Toe, Math, RPS, Quiz Battle,
Memory, Daily Brain, 2048, Word Challenge, Reflex Test) with filters + best scores,
**10 languages × 232 strings** with login-page switcher, **8 themes**,
forgot password. 64/64 automated checks pass, zero console errors.

**Code me hai par is environment me test NAHI ho paya:** real Firebase (Auth/Firestore/rules),
**OpenTune streaming ka live playback** (Piped/Invidious instances is sandbox se network-blocked
hain — phone pe normal internet pe chalenge),
asli Android device pe notifications/reboot/snooze, Photo/PDF OCR import (tesseract.js / pdf.js CDN se,
internet chahiye; text-paste import tested hai), file share/download (Web Share) APK webview me,
print/PDF report, APK build.

**Abhi nahi bana:** real 3D avatar (ye layered 2.5D SVG hai), Quiz Battle, Word Challenge, friend
requests/friend list, shared goals/group challenges, custom room emojis, home-screen widgets (native code
chahiye), AI-based planner (ye rule-based hai, cloud AI nahi), file attachments (Firebase Storage nahi laga;
link field hai), Google/system calendar sync (.ics export hai).

Game results client-side compute hote hain (rules turn/player check karte hain); server-validated scoring
ke liye Cloud Functions chahiye.

---

## Migration (purana data safe)

- Koi purana field/collection badla nahi. `users/{uid}` me naye optional fields jude:
  `mode, xp, study, status, username, avatars, privacy, skippedRoom, focusTarget, gameWins, memBest`.
- Naye per-user collections: `users/{uid}/{tasks,habits,events,notes,subjects,exams,sessions,scores}`.
  Naya top-level: `games/{code}`. Rooms me `announce`, `music`; messages me `reacts`/`kind`.
- **Zaroori:** `firestore.rules` dobara paste karke Publish karo (naye collections ke liye).
- Purane users pehli baar khulne par Student/Adult poochha jaata hai; room na ho to "skip" ka option hai.
- Offline: Firestore persistent cache chalu hai, offline likha data net aate hi sync ho jata hai.
- Backup/Restore (Settings): restore sirf wo records banata hai jo pehle se nahi hain, purana data overwrite nahi hota.
  Purani "NNN" backup files bhi ab restore ho jaati hain.

---

## Data kahan jaata hai

- `users/{uid}`: naam, avatar, room code, schedule
- `rooms/{code}`: start date, announcement, music channel
- `rooms/{code}/members/{uid}`: points, check-in days, avatar
- `rooms/{code}/messages/{id}`: chat
