import {
  onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile, sendPasswordResetEmail
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  $, $$, esc, clamp, pad, store, ic, P, S, D, db, auth, doc, getDoc, setDoc, updateDoc, deleteDoc, addDoc, collection, query, orderBy, limit,
  onSnapshot, serverTimestamp, increment, arrayUnion, arrayRemove, runTransaction, toast, fail, copyText, openOv, closeOv, formSheet,
  startData, stopData, onData, saveMe, refreshSub, closeAllSubs, fmtTime, startOfToday, DAY, tr, openSub, topLayer, popLayer, heroArt,
  getLang, setLang, applyLang, langPickerHTML, LANGS
} from './core.js';
import { avatarHTML, MEMOJI, openAvatarCreator } from './avatar.js';
import { pickEmoji } from './emoji.js';
import * as Music from './music.js';
import * as N from './notify.js';
import { homeHTML, trackerExtraHTML, thirdTabHTML, moreHTML, renderSchedule, maybeAskMode } from './home.js';
import { gamesHTML } from './games.js';
import { applyA11y, lockIfNeeded } from './insights.js';
import './tasks.js'; import './study.js'; import './life.js';

/* ================= helpers ================= */
const dayNum = (startMs) => { const s = new Date(startMs); s.setHours(0, 0, 0, 0); return Math.round((startOfToday() - s.getTime()) / DAY) + 1; };
function streakOf(ck, today) {
  const s = new Set(ck || []);
  let d = s.has(today) ? today : today - 1, n = 0;
  while (d >= 1 && s.has(d)) { n++; d--; }
  return n;
}
const meMember = () => S.members.find((m) => m.uid === S.user?.uid);
const ranked = () => [...S.members].sort((a, b) => (b.points || 0) - (a.points || 0) || String(a.name).localeCompare(String(b.name)));
const online = (m) => m.seen && Date.now() - m.seen < 150000;

const PEANUT = `<svg viewBox="0 0 200 240" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<defs><linearGradient id="plBody" x1="0" y1="0" x2=".35" y2="1"><stop offset="0" stop-color="#F7D9A0"/><stop offset=".45" stop-color="#E8B96F"/><stop offset="1" stop-color="#D69A50"/></linearGradient>
<linearGradient id="plL1" x1="0" y1="1" x2=".6" y2="0"><stop offset="0" stop-color="#4E7C2E"/><stop offset="1" stop-color="#8CC63F"/></linearGradient>
<linearGradient id="plL2" x1="1" y1="1" x2=".4" y2="0"><stop offset="0" stop-color="#3E6B24"/><stop offset="1" stop-color="#6FA044"/></linearGradient></defs>
<path d="M100 20 C95 6 82 -2 72 3 C74 16 86 24 100 20 Z" fill="url(#plL2)"/><path d="M100 20 C105 5 119 -3 129 2 C127 15 114 24 100 20 Z" fill="url(#plL1)"/>
<path d="M100 22 V6" stroke="#2F4A1C" stroke-width="4" stroke-linecap="round"/>
<path d="M100 16 C129 16 149 34 149 59 C149 77 134 84 134 94 C134 105 153 113 155 133 C158 162 132 185 100 185 C68 185 42 162 45 133 C47 113 66 105 66 94 C66 84 51 77 51 59 C51 34 71 16 100 16 Z" fill="url(#plBody)" stroke="#141810" stroke-width="7" stroke-linejoin="round"/>
<g fill="#C48B4A" opacity=".5"><ellipse cx="120" cy="44" rx="4.5" ry="3.2" transform="rotate(-18 120 44)"/><ellipse cx="72" cy="96" rx="4" ry="2.9" transform="rotate(14 72 96)"/><ellipse cx="66" cy="134" rx="4.6" ry="3.3" transform="rotate(-8 66 134)"/><ellipse cx="133" cy="128" rx="4.2" ry="3" transform="rotate(22 133 128)"/><ellipse cx="128" cy="163" rx="4.6" ry="3.3" transform="rotate(-12 128 163)"/></g>
<path d="M74 46 Q80 28 98 25" fill="none" stroke="#FBEBC6" stroke-width="8" stroke-linecap="round" opacity=".85"/>
<g fill="#E08A62" opacity=".42"><ellipse cx="71" cy="88" rx="9" ry="6.5"/><ellipse cx="129" cy="88" rx="9" ry="6.5"/></g>
<g fill="#141810"><ellipse cx="83" cy="76" rx="7.4" ry="8.4"/><ellipse cx="117" cy="76" rx="7.4" ry="8.4"/></g>
<g fill="#fff" opacity=".92"><circle cx="85.6" cy="73" r="2.5"/><circle cx="119.6" cy="73" r="2.5"/></g>
<g fill="none" stroke="#141810" stroke-width="4" stroke-linecap="round"><path d="M74 60 Q83 55 92 59"/><path d="M126 60 Q117 55 108 59"/></g>
<path d="M84 96 Q100 114 116 94" fill="none" stroke="#141810" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

const DEFAULT_SCHEDULE = () => [
  { id: 'a1', time: '06:30', title: 'Subah ki walk', sub: '20 min, phone ghar pe', on: true },
  { id: 'a2', time: '08:00', title: 'Cold shower', sub: 'Din ki shuruaat', on: true },
  { id: 'a3', time: '10:00', title: 'Focus block', sub: '2 ghante, notifications band', on: true },
  { id: 'a4', time: '13:30', title: 'Lunch + paani', sub: 'Screen se door', on: true },
  { id: 'a5', time: '18:00', title: 'Gym ya khel', sub: 'Energy bahar nikaal', on: true },
  { id: 'a6', time: '21:00', title: 'Aaj ka check-in', sub: 'App kholo, streak bachao', on: true },
  { id: 'a7', time: '23:00', title: 'Sone ka time', sub: '7 ghante ki neend', on: true }
];
const newUserDoc = (name) => ({
  name, avatar: { type: 'memoji', idx: Math.floor(Math.random() * MEMOJI.length) },
  roomCode: null, schedule: DEFAULT_SCHEDULE(), remindersOn: true, createdAt: serverTimestamp()
});

/* ================= ui plumbing ================= */
function show(id) {
  ['auth', 'setup', 'dash'].forEach((s) => $('#' + s).classList.toggle('hidden', s !== id));
  document.documentElement.dataset.screen = id;
  if (id === 'dash') setTimeout(maybeAskMode, 600);
}
function applyTheme(t) {
  document.documentElement.dataset.theme = t; store.set('nnn_theme', t);
  const m = $('meta[name=theme-color]');
  if (m) m.content = getComputedStyle(document.documentElement).getPropertyValue('--bg').trim() || '#0E0F0C';
}
const BG = { olive: '#8F9B5A', sage: '#AEBB9F', mint: '#BFE3CB', sand: '#E6D6B4' };
function applyLoginBg(k) {
  if (!BG[k]) k = 'sage';
  store.set('nnn_bg', k);
  $('#auth').style.setProperty('--loginbg', BG[k]);
  $$('.dot-btn').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === k)));
}

/* ================= auth ================= */
let authMode = 'login';
function setMode(m) {
  authMode = m;
  const signup = m === 'signup';
  $$('.seg button', $('#auth-form')).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === m)));
  $('#f-name').classList.toggle('hidden', !signup);
  $('#forgot-btn').classList.toggle('hidden', signup);
  const saved = store.get('nnn_name');
  $('#auth-title').textContent = signup ? tr('authNewAcc') : (saved ? tr('authWelcome') + ', ' + saved : tr('authLoginCta'));
  $('#auth-sub').textContent = signup ? tr('authSignTag') : (saved ? tr('authNameSaved') : tr('authEmailHint'));
  $('#auth-submit span').textContent = signup ? tr('authSignupCta') : tr('authLoginCta');
  $('#auth-alt').textContent = signup ? tr('authHaveAcc') : tr('authNoAcc');
  $('#auth-alt-btn').textContent = signup ? tr('authLoginCta') : tr('authSignupCta');
  $('#auth-alt-btn').dataset.v = signup ? 'login' : 'signup';
  $('#in-pass').autocomplete = signup ? 'new-password' : 'current-password';
}
$('#auth-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = $('#in-email').value.trim(), pass = $('#in-pass').value, name = $('#in-name').value.trim();
  if (!email || !pass) return toast('Email aur password daalo');
  const btn = $('#auth-submit'); btn.disabled = true;
  try {
    if (authMode === 'signup') {
      if (!name) { toast('Naam daalo'); return; }
      store.set('nnn_name', name);
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      try { await updateProfile(cred.user, { displayName: name }); } catch { /* optional */ }
    } else await signInWithEmailAndPassword(auth, email, pass);
    store.set('nnn_email', email);
  } catch (err) { fail(err); } finally { btn.disabled = false; }
});
async function forgotPassword(email) {
  email = (email || '').trim();
  if (!email) return toast('Pehle email daalo');
  try { await sendPasswordResetEmail(auth, email); toast('Reset link email pe bhej diya. Spam bhi check karo'); } catch (e) { fail(e); }
}

const splashDone = new Promise((r) => setTimeout(r, 1300));
onAuthStateChanged(auth, async (user) => {
  try { if (user) await boot(user); else showAuth(); }
  catch (e) { fail(e); try { await signOut(auth); } catch { /* ignore */ } }
  finally { await splashDone; $('#splash').classList.add('gone'); }
});

function showAuth() {
  unsubAll(); stopData(); if (userUnsub) { userUnsub(); userUnsub = null; }
  Object.assign(S, { user: null, me: null, room: null, code: null, members: [], msgs: [], chatFirst: true });
  closeAllSubs(); ['ov-profile', 'ov-notif', 'ov-add', 'ov-form', 'ov-emoji', 'ov-lang'].forEach(closeOv); $('#lock').classList.add('hidden');
  Music.stop(); Music.setRoom(null); N.cancelNative();
  const em = store.get('nnn_email'); if (em) $('#in-email').value = em;
  $('#in-pass').value = '';
  setMode('login'); show('auth');
}

let userUnsub = null, hbT = null;
async function boot(user) {
  S.user = user;
  const uref = doc(db, 'users', user.uid);
  let snap = await getDoc(uref);
  if (!snap.exists()) {
    const nm = user.displayName || store.get('nnn_name') || (user.email || 'Player').split('@')[0];
    await setDoc(uref, newUserDoc(nm));
    snap = await getDoc(uref);
  }
  S.me = snap.data();
  if (!S.me.schedule) S.me.schedule = DEFAULT_SCHEDULE();
  store.set('nnn_name', S.me.name);
  fillMe();
  startData(user.uid);
  /* cloud sync: doosre device pe profile/avatar/schedule badle to yahan aa jaata hai */
  userUnsub = onSnapshot(uref, (s) => {
    if (!s.exists() || s.metadata.hasPendingWrites) return;
    S.me = { ...S.me, ...s.data() }; fillMe(); renderAll(); N.sync();
  }, () => {});
  S.pending = genCode(); $('#pending-code').textContent = S.pending;
  const ok = S.me.roomCode ? await enterRoom(S.me.roomCode) : false;
  if (!ok) show(S.me.skippedRoom ? 'dash' : 'setup');
  renderAll(); go(0, false);
  setTimeout(maybeAskNotif, 1200);
  N.catchUpHistory(); N.sync(); lockIfNeeded();
  clearInterval(hbT); hbT = setInterval(heartbeat, 60000); heartbeat();
}
function fillMe() {
  $$('[data-me-av]').forEach((el) => { el.innerHTML = avatarHTML(S.me.avatar, 44); });
  $$('[data-me-name]').forEach((el) => { el.textContent = S.me.name; });
}
function heartbeat() {
  if (!S.code || !S.user || document.hidden) return;
  const on = !(S.me.privacy && S.me.privacy.online === false);
  updateDoc(doc(db, 'rooms', S.code, 'members', S.user.uid), { seen: on ? Date.now() : 0 }).catch(() => {});
}

/* ================= rooms ================= */
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function genCode() { const a = new Uint32Array(6); crypto.getRandomValues(a); return [...a].map((n) => CODE_CHARS[n % CODE_CHARS.length]).join(''); }
function unsubAll() { S.unsubs.forEach((u) => { try { u(); } catch { /* ignore */ } }); S.unsubs = []; }
const snapErr = (e) => fail(e);

async function joinMember(code, verb) {
  const ref = doc(db, 'rooms', code, 'members', S.user.uid);
  const ex = await getDoc(ref);
  const base = { name: S.me.name, avatar: S.me.avatar, status: S.me.status || null };
  if (ex.exists()) await updateDoc(ref, base);
  else {
    await setDoc(ref, { ...base, points: 0, checkins: [], joinedAt: serverTimestamp() });
    await addDoc(collection(db, 'rooms', code, 'messages'), { uid: S.user.uid, name: S.me.name, system: true, text: `${S.me.name} ne room ${verb}`, ts: serverTimestamp() });
  }
  await updateDoc(doc(db, 'users', S.user.uid), { roomCode: code });
  S.me.roomCode = code;
}
async function enterRoom(code) {
  const rs = await getDoc(doc(db, 'rooms', code));
  if (!rs.exists()) return false;
  unsubAll();
  S.room = { code, ...rs.data() }; S.code = code; S.members = []; S.msgs = []; S.chatFirst = true;
  Music.setRoom(code, (S.room.music || {}).ch);
  S.unsubs.push(onSnapshot(doc(db, 'rooms', code), (s) => {
    if (s.exists()) {
      S.room = { code, ...s.data() };
      const mc = (S.room.music || {}).ch;
      if (mc) Music.setRoom(code, mc);
      renderCommunity();
    }
  }, () => {}));
  S.unsubs.push(onSnapshot(collection(db, 'rooms', code, 'members'), (snap) => { S.members = snap.docs.map((d) => ({ uid: d.id, ...d.data() })); renderAll(); }, snapErr));
  S.unsubs.push(onSnapshot(query(collection(db, 'rooms', code, 'messages'), orderBy('ts', 'desc'), limit(100)), (snap) => {
    S.msgs = snap.docs.map((d) => ({ id: d.id, ...d.data({ serverTimestamps: 'estimate' }) })).reverse(); renderChat();
  }, snapErr));
  show('dash'); go(0, false); renderAll();
  return true;
}
async function createRoom() {
  const btn = $('#btn-create'); btn.disabled = true;
  try {
    let code = S.pending || genCode();
    for (let i = 0; i < 6; i++) { if (!(await getDoc(doc(db, 'rooms', code))).exists()) break; code = genCode(); }
    await setDoc(doc(db, 'rooms', code), { code, owner: S.user.uid, startDate: startOfToday(), createdAt: serverTimestamp(), music: { ch: Music.channelForRoom(code), by: S.user.uid, ts: Date.now() } });
    await joinMember(code, 'banaya'); await enterRoom(code);
    const ok = await copyText(code);
    toast(ok ? `Room ban gaya. Code ${code} copy ho gaya` : `Room ban gaya. Code: ${code}`);
  } catch (e) { fail(e); } finally { btn.disabled = false; }
}
$('#join-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const code = $('#join-code').value.trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(code)) return toast('6 akshar ka code daalo');
  const btn = $('#btn-join'); btn.disabled = true;
  try {
    const rs = await getDoc(doc(db, 'rooms', code));
    if (!rs.exists()) { toast('Ye code kisi room ka nahi hai'); return; }
    await joinMember(code, 'join kiya'); await enterRoom(code); toast('Room join ho gaya');
  } catch (err) { fail(err); } finally { btn.disabled = false; }
});
async function leaveRoom() {
  if (!S.code) return;
  if (!confirm('Room chhodna hai? Tera score is room se hat jayega.')) return;
  try {
    await deleteDoc(doc(db, 'rooms', S.code, 'members', S.user.uid));
    await updateDoc(doc(db, 'users', S.user.uid), { roomCode: null });
    unsubAll(); S.me.roomCode = null; S.code = null; S.room = null; S.members = []; S.msgs = [];
    closeOv('ov-profile'); S.pending = genCode(); $('#pending-code').textContent = S.pending;
    renderAll(); toast('Room chhod diya');
  } catch (e) { fail(e); }
}
async function checkin() {
  if (!S.room) return;
  const day = dayNum(S.room.startDate);
  if (day < 1 || day > 30) return;
  const btn = $('#btn-checkin'); if (btn) btn.disabled = true;
  const ref = doc(db, 'rooms', S.code, 'members', S.user.uid);
  try {
    await runTransaction(db, async (tx) => {
      const s = await tx.get(ref), d = s.data() || {};
      if ((d.checkins || []).includes(day)) throw Object.assign(new Error('already'), { code: 'already' });
      tx.update(ref, { checkins: arrayUnion(day), points: increment(10), lastCheckin: serverTimestamp() });
    });
    toast('Check-in ho gaya, +10 points');
  } catch (e) { if (e.code === 'already') toast('Aaj ka check-in ho chuka hai'); else fail(e); if (btn) btn.disabled = false; }
}

/* ================= render ================= */
let renderT;
function renderAll() {
  if (!S.me) return;
  clearTimeout(renderT);
  renderT = setTimeout(() => {
    fillMe();
    const c = $('#top-code'); if (c) c.textContent = S.code ? 'ROOM ' + S.code : 'PEANUT';
    const sub = $('#top-sub');
    if (sub) {
      const m = meMember();
      const st = m ? streakOf(m.checkins || [], S.room ? dayNum(S.room.startDate) : 1) : 0;
      sub.textContent = st ? `Streak ${st} din · ${m.points || 0} pts` : (S.code ? 'Room me ho' : '30 din ka challenge');
    }
    renderHome(); renderTracker(); renderThird(); renderCommunity(); renderMore(); paintTabs();
    if (!$('#ov-profile').classList.contains('hidden')) renderProfile();
  }, 30);
}
const renderHome = () => { $('#p0').innerHTML = homeHTML(); };
const renderThird = () => { $('#p2').innerHTML = thirdTabHTML(); };
const renderMore = () => { $('#p4').innerHTML = moreHTML(); };
onData(() => { renderAll(); refreshSub(); N.sync(); });
window.addEventListener('nnn-mode', () => { renderAll(); });
window.addEventListener('nnn-lang', () => { renderAll(); });
window.addEventListener('nnn-profile', () => { renderProfile(); openOv('ov-profile'); });
window.addEventListener('nnn-logout', () => { signOut(auth).catch(fail); });
window.addEventListener('nnn-avatar', (e) => {
  S.me.avatar = e.detail; if (S.code) updateDoc(doc(db, 'rooms', S.code, 'members', S.user.uid), { avatar: e.detail }).catch(() => {});
  renderAll();
});

function renderTracker() {
  const hab = trackerExtraHTML();
  if (!S.room) {
    $('#p1').innerHTML = `<div class="phead"><h1>Tracker</h1></div>
<div class="lime2"><div class="mono lbl-d">30 DIN KA CHALLENGE</div><h2>Room ke saath</h2><p>Peanut challenge room me chalta hai. Room banao ya code se join karo.</p><button class="btn dark" data-act="gosetup">Room banao / join karo</button></div>${hab}`;
    return;
  }
  const day = dayNum(S.room.startDate), shown = clamp(day, 0, 30), m = meMember(), ck = m ? (m.checkins || []) : [], pts = m ? (m.points || 0) : 0;
  const rank = ranked().findIndex((x) => x.uid === S.user.uid) + 1, pct = Math.round(shown / 30 * 100), doneToday = ck.includes(day), over = day > 30, st = streakOf(ck, day);
  const s0 = new Date(S.room.startDate), s1 = new Date(S.room.startDate + 29 * DAY);
  const f = (d) => d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  let cells = '';
  for (let n = 1; n <= 30; n++) {
    const done = ck.includes(n);
    cells += `<div class="${['c', done ? 'done' : '', n === day ? 'today' : '', (!done && n < day) ? 'miss' : ''].join(' ')}" ${n === day ? 'aria-current="date"' : ''}>${n}</div>`;
  }
  const label = over ? 'Challenge khatam' : doneToday ? `${ic(P.check, 22, 2.4)}Aaj ka check-in ho gaya` : `${ic(P.check, 22, 2.4)}Aaj ka check-in karo`;
  $('#p1').innerHTML = `
<div class="phead"><h1>Tracker</h1></div>
${heroArt('assets/art/hero-tracker.webp', '30 DIN KA CHALLENGE', over ? 'Challenge khatam!' : `Din ${shown} / 30`, `Streak ${st} · ${ck.length} check-in`)}
<div class="card-big"><div class="stat-row"><div><div class="mono lbl">DIN HO GAYE</div><div class="bignum"><b>${shown}</b><span>/30</span></div></div>
<div class="stat-side"><div><div class="mono lbl">POINTS</div><div class="n">${pts}</div></div><div><div class="mono lbl">RANK</div><div class="n ac">${rank ? '#' + rank : '-'}</div></div></div></div>
<div class="bar" role="progressbar" aria-label="Challenge progress" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>
<div class="bar-l mono"><span>${pct}% done</span><span>${Math.max(0, 30 - shown)} din baaki</span></div></div>
<div class="card-big cal"><div class="cal-h"><b>Check-in</b><span class="mono">${f(s0)} – ${f(s1)}</span></div><div class="grid">${cells}</div></div>
<button id="btn-checkin" class="btn ${doneToday ? 'done' : over ? 'soft' : ''}" data-act="checkin" ${(doneToday || over) ? 'disabled' : ''}>${label}</button>
<div class="streakline mono">streak ${st} · ${ck.length} check-in</div>${hab}`;
}

/* ----- community ----- */
const noRoom = (t) => `<div class="lime2"><div class="mono lbl-d">ROOM</div><h2>${t}</h2><p>Dost ke saath leaderboard, wall aur challenges.</p><button class="btn dark" data-act="gosetup">Room banao / join karo</button></div>`;
const REACTS = [['like', '👍'], ['love', '❤️'], ['laugh', '😂'], ['fire', '🔥'], ['clap', '👏'], ['sad', '😢']];
function renderCommunity() {
  if (!S.me) return;
  const v = S.cm || 'board';
  const mem = S.members.length;
  $('#cm-seg').innerHTML = `<div class="seg sm" role="group">${[['board', tr('Board')], ['wall', tr('Wall')], ['games', tr('Games')], ['room', 'Room']].map(([k, l]) => `<button type="button" data-act="cmview" data-v="${k}" aria-pressed="${v === k}">${l}</button>`).join('')}</div>`;
  ['board', 'wall', 'games', 'room'].forEach((k) => $('#cm-' + k).classList.toggle('hidden', k !== v));
  $('#p3').classList.toggle('wall-on', v === 'wall' && !!S.code);
  $('#chat-count').textContent = S.code ? S.members.length + (S.members.length === 1 ? ' player' : ' players') : 'no room';
  const hero = $('#cm-hero');
  if (hero) hero.innerHTML = heroArt('assets/art/hero-community.webp',
    S.code ? 'ROOM ' + S.code : 'COMMUNITY',
    mem ? `${mem} log saath` : 'Apna room banao',
    S.code ? 'Leaderboard, wall aur challenges — sab yahin.' : 'Room banao ya code se join karo.');
  if (v === 'board') renderBoard();
  if (v === 'wall') renderChat();
  if (v === 'games') $('#cm-games').innerHTML = gamesHTML();
  if (v === 'room') renderRoomTab();
}
function renderBoard() {
  const el = $('#cm-board');
  if (!S.code) { el.innerHTML = noRoom('Leaderboard ke liye room chahiye'); return; }
  const list = ranked();
  let body = '';
  if (list.length) {
    const top = list[0], day = S.room ? dayNum(S.room.startDate) : 1;
    const stt = (m) => (m.status && m.status.emoji ? ' ' + esc(m.status.emoji) : '');
    body += `<div class="champ">${avatarHTML(top.avatar, 68)}<div class="mid"><div class="mono">RANK 01</div><div class="cn">${esc(top.name)}${stt(top)}</div><div class="mono">streak ${streakOf(top.checkins, day)}</div></div><div class="cp"><b>${top.points || 0}</b><span class="mono">PTS</span></div></div>`;
    body += '<div class="rows">' + list.slice(1).map((p, i) => {
      const me = p.uid === S.user.uid;
      return `<div class="row ${me ? 'me' : ''}"><div class="rk">${pad(i + 2)}</div><span class="avw">${avatarHTML(p.avatar, 42)}${online(p) ? '<i class="onl" aria-label="online"></i>' : ''}</span>
<div class="mid"><div class="t"><b>${esc(p.name)}${stt(p)}</b>${me ? '<span class="you">YOU</span>' : ''}</div><span class="s">streak ${streakOf(p.checkins, day)}</span></div><div class="pts">${p.points || 0}</div></div>`;
    }).join('') + '</div>';
  }
  if (list.length < 2) body += `<div class="empty">Abhi akele ho. Doston ko ye code bhejo<br><button class="codechip" data-act="copycode" aria-label="Code copy karo">${esc(S.code || '')}</button></div>`;
  body += `<div class="card-big invite"><div class="mono lbl">DOSTO KO BULAO</div><b>Room code share karo</b><p class="sub">${esc(S.code || '')} bhej de — jo join karega wahi leaderboard me aayega aur apna music channel bhi chalega.</p><button class="btn soft" data-act="copycode">${ic(P.copy, 18, 2)}Code copy karo</button></div>`;
  el.innerHTML = body;
}
function renderRoomTab() {
  const el = $('#cm-room');
  if (!S.code) { el.innerHTML = noRoom('Abhi kisi room me nahi ho'); return; }
  const owner = S.room && S.room.owner === S.user.uid, an = S.room && S.room.announce;
  el.innerHTML = `<div class="card-big"><div class="mono lbl">ROOM CODE</div><button class="codechip big" data-act="copycode">${esc(S.code)}</button><div class="bar-l mono"><span>${S.members.length} members</span><span>owner: ${esc((S.members.find((m) => m.uid === (S.room || {}).owner) || {}).name || '-')}</span></div></div>
${an ? `<div class="card-big"><div class="mono lbl">ANNOUNCEMENT</div><p>${esc(an.text)}</p></div>` : ''}
${owner ? `<button class="btn soft" data-act="announce">Announcement likho</button>` : ''}
<div class="mono lbl">MEMBERS</div>${S.members.map((m) => `<div class="row"><span class="avw">${avatarHTML(m.avatar, 40)}${online(m) ? '<i class="onl"></i>' : ''}</span><div class="mid"><b>${esc(m.name)}</b></div>${m.uid === (S.room || {}).owner ? '<span class="you">OWNER</span>' : ''}</div>`).join('')}
<button class="btn danger" data-act="leave">${ic(P.leave, 18, 1.9)}Leave room</button>`;
}
function renderChat() {
  const an = S.room && S.room.announce;
  $('#announce').innerHTML = an ? `<div class="annc"><b>📣</b><span>${esc(an.text)}</span></div>` : '';
  const box = $('#msgs');
  if (!S.code) { box.innerHTML = ''; $('#msgs').innerHTML = noRoom('Wall ke liye room chahiye'); return; }
  const near = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  const byUid = new Map(S.members.map((m) => [m.uid, m]));
  box.innerHTML = S.msgs.map((m) => {
    if (m.system) return `<div class="sys">${esc(m.text)}</div>`;
    const me = m.uid === S.user?.uid, mem = byUid.get(m.uid), nm = mem ? mem.name : m.name;
    if (m.kind === 'areact') return `<div class="areact ${me ? 'me' : ''}">${avatarHTML(mem && mem.avatar, 56)}<span class="aemo">${esc(m.emoji || '👋')}</span><em class="mono">${me ? 'You' : esc(nm)}</em></div>`;
    const rx = m.reacts || {};
    const chips = REACTS.filter(([k]) => (rx[k] || []).length).map(([k, e]) => `<button class="rx ${(rx[k] || []).includes(S.user.uid) ? 'on' : ''}" data-act="react" data-id="${m.id}" data-v="${k}">${e} ${(rx[k] || []).length}</button>`).join('');
    const pick = S.rxOpen === m.id ? REACTS.map(([k, e]) => `<button class="rx pick" data-act="react" data-id="${m.id}" data-v="${k}">${e}</button>`).join('') : `<button class="rx add" data-act="rxopen" data-id="${m.id}" aria-label="Reaction lagao">+</button>`;
    return `<div class="m ${me ? 'me' : ''}">${me ? '' : avatarHTML(mem && mem.avatar, 32)}
<div class="col"><div class="meta">${me ? fmtTime(m.ts) + ' · You' : esc(nm) + ((mem && mem.status && mem.status.emoji) ? ' ' + esc(mem.status.emoji) : '') + ' · ' + fmtTime(m.ts)}</div><div class="bub">${esc(m.text)}</div><div class="rxs">${chips}${pick}</div></div></div>`;
  }).join('');
  if (near || S.chatFirst) { box.scrollTop = box.scrollHeight; if (S.msgs.length) S.chatFirst = false; }
}
const scrollChat = () => { const b = $('#msgs'); requestAnimationFrame(() => { b.scrollTop = b.scrollHeight; }); };
$('#chat-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const inp = $('#chat-input'), text = inp.value.trim().slice(0, 400);
  if (!text || !S.code) return;
  inp.value = '';
  try { await addDoc(collection(db, 'rooms', S.code, 'messages'), { uid: S.user.uid, name: S.me.name, text, ts: serverTimestamp() }); }
  catch (err) { inp.value = text; fail(err); }
});
async function react(id, k) {
  const m = S.msgs.find((x) => x.id === id); if (!m) return;
  const has = ((m.reacts || {})[k] || []).includes(S.user.uid);
  S.rxOpen = null;
  try { await updateDoc(doc(db, 'rooms', S.code, 'messages', id), { [`reacts.${k}`]: has ? arrayRemove(S.user.uid) : arrayUnion(S.user.uid) }); } catch (e) { fail(e); }
}

/* ----- profile ----- */
function renderProfile() {
  const me = S.me, inRoom = !!S.code, curTheme = document.documentElement.dataset.theme, st = me.status || {};
  const themes = [['dark', 'Garden', '#0C0E0A', '#C8F23A'], ['light', 'Cream', '#F4F1E6', '#2F6B2A'], ['neon', 'Vapor', '#0A0722', '#00F5D4'], ['candy', 'Bubble', '#FFDFEB', '#FF4F8B'],
    ['ocean', 'Ocean', '#07171F', '#3DD6C4'], ['sunset', 'Sunset', '#1C0F14', '#FF9F5A'], ['forest', 'Forest', '#0A1410', '#7BE495'], ['mono', 'Ink', '#0E0E0E', '#FFFFFF']];
  $('#profile-sheet').innerHTML = `
<div class="grab"></div>
<div class="pf-top"><div class="pf-av">${avatarHTML(me.avatar, 96)}<button class="cam" data-act="pickphoto" aria-label="Photo badlo">${ic(P.camera, 20, 2)}</button></div>
<div class="pf-name">${esc(me.name)} ${st.emoji ? esc(st.emoji) : ''}</div><div class="pf-mail">${me.username ? '@' + esc(me.username) + ' · ' : ''}${esc(S.user.email || '')}</div>${st.text ? `<div class="sub">${esc(st.text)}</div>` : ''}</div>
<button class="btn" data-act="avcreate">${ic(P.smile, 20, 1.9)}Avatar banao / badlo</button>
<div class="two"><button class="btn soft" data-act="editprofile">${ic(P.edit, 18, 1.9)}Naam / status</button><button class="btn soft" data-act="resetpw">Password reset</button></div>
<div class="mono lbl">MEMOJI AVATAR</div>
<div class="av-grid">${MEMOJI.map((_, i) => { const on = me.avatar && me.avatar.type === 'memoji' && (Number(me.avatar.idx) | 0) === i; return `<button class="avopt" data-act="setav" data-v="${i}" aria-pressed="${on}" aria-label="Avatar ${i + 1}">${avatarHTML({ type: 'memoji', idx: i }, 66)}</button>`; }).join('')}</div>
<button class="btn soft" data-act="pickphoto">${ic(P.camera, 20, 1.9)}Apni photo upload karo</button>
<div class="mono lbl">THEME</div>
<div class="th-grid">${themes.map(([k, n, bg, dot]) => `<button class="thopt" data-act="theme" data-v="${k}" aria-pressed="${curTheme === k}"><span class="sw-c" style="background:${bg}"><i style="background:${dot}"></i></span>${n}</button>`).join('')}</div>
<div class="two">${inRoom ? `<button class="btn soft" data-act="leave">${ic(P.leave, 18, 1.9)}Leave room</button>` : ''}<button class="btn danger" data-act="logout">${ic(P.logout, 18, 1.9)}Logout</button></div>`;
}
async function saveAvatar(av) {
  S.me.avatar = av;
  try {
    await updateDoc(doc(db, 'users', S.user.uid), { avatar: av });
    if (S.code) await updateDoc(doc(db, 'rooms', S.code, 'members', S.user.uid), { avatar: av });
  } catch (e) { fail(e); }
  fillMe(); renderProfile(); renderAll();
}
function shrink(file, size) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas'); c.width = c.height = size;
      const x = c.getContext('2d'), s = Math.min(img.width, img.height);
      x.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
      URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.72));
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
    img.src = url;
  });
}
$('#photo-in').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = '';
  if (!f) return;
  try { await saveAvatar({ type: 'photo', data: await shrink(f, 128) }); toast('Photo set ho gayi'); } catch { toast('Photo load nahi hui'); }
});
function editProfile() {
  const me = S.me, st = me.status || {};
  formSheet._emoji = undefined;
  formSheet({
    title: 'Profile edit', values: { name: me.name, username: me.username || '', stext: st.text || '' },
    extraHtml: `<button class="btn soft" type="button" data-act="statusemoji">${esc(st.emoji || '🙂')} Status emoji chuno</button>`,
    fields: [{ k: 'name', l: 'Display name', req: 1, max: 20 }, { k: 'username', l: 'Username (a-z, 0-9, _)', max: 20, ph: 'tera_username' }, { k: 'stext', l: 'Status', max: 30, ph: 'Padhai mode on' }],
    onSave: (f) => {
      const username = f.username.toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 20);
      const status = { emoji: formSheet._emoji ?? st.emoji ?? '', text: f.stext };
      saveMe({ name: f.name, username, status });
      updateProfile(auth.currentUser, { displayName: f.name }).catch(() => {});
      if (S.code) updateDoc(doc(db, 'rooms', S.code, 'members', S.user.uid), { name: f.name, status }).catch(() => {});
      store.set('nnn_name', f.name); renderAll(); renderProfile(); toast('Profile update ho gaya');
    }
  });
}

/* ================= schedule actions ================= */
async function saveSchedule() {
  try { await updateDoc(doc(db, 'users', S.user.uid), { schedule: S.me.schedule, remindersOn: !!S.me.remindersOn }); } catch (e) { fail(e); }
  renderSchedule($('#sub-body').querySelector('.list') ? $('#sub-body') : null); refreshSub(); renderAll(); N.sync();
}
$('#add-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const time = $('#add-time').value, title = $('#add-title').value.trim();
  if (!time || !title) return;
  S.me.schedule.push({ id: Date.now().toString(36), time, title, sub: '', on: true });
  $('#add-title').value = ''; closeOv('ov-add'); await saveSchedule();
});

/* ================= notifications permission ================= */
async function maybeAskNotif() {
  if (!S.user || store.get('nnn_notif_asked')) return;
  if ((await N.permState()) !== 'default') return;
  openOv('ov-notif');
}

/* ================= language ================= */
function applyStaticI18n() {
  $$('[data-t]').forEach((el) => {
    const k = el.dataset.t;
    if (!k) return;
    const v = tr(k);
    if (v && el.textContent !== v) el.textContent = v;
  });
}
function paintLangBtn() {
  const b = $('#langbtn-txt');
  if (b) b.textContent = (getLang() || 'en').toUpperCase();
}
function openLangSheet() {
  const list = $('#lang-list');
  if (list) list.innerHTML = langPickerHTML({ act: 'setlang2' });
  const ti = $('#lang-title'); if (ti) ti.textContent = tr('langTitle');
  const su = $('#lang-sub'); if (su) su.textContent = tr('langPick');
  openOv('ov-lang');
}
window.addEventListener('pn-lang', () => {
  applyStaticI18n();
  paintLangBtn();
  renderAll();
  const list = $('#lang-list'); if (list && !$('#ov-lang').classList.contains('hidden')) list.innerHTML = langPickerHTML({ act: 'setlang2' });
});

/* ================= music =================
   Neeche music.js me poora engine hai. Yahan sirf app wiring:
   room ka channel set karna, header ka play/pause, aur badge paint. */
Music.bindRoomMusic(async (chId) => {
  if (!S.code) return;
  try {
    await updateDoc(doc(db, 'rooms', S.code), { music: { ch: chId, by: S.user.uid, ts: Date.now() } });
  } catch (e) { fail(e); }
});
function paintMusic() {
  const b = $('#music'); if (!b) return;
  const on = Music.isPlaying();
  b.setAttribute('aria-pressed', String(on));
  b.setAttribute('aria-label', on ? 'Music roko' : 'Music chalao');
  const ch = Music.currentChannel();
  const lbl = $('#music-ch');
  if (lbl) lbl.textContent = ch.emoji + '  ' + ch.name;
  const np = $('#np');
  if (np) np.classList.toggle('hidden', !on);
}
Music.onChange(paintMusic);

/* ================= navigation ================= */
const TAB_ICONS = [P.home, P.cal, null, P.users, P.more];
function paintTabs() {
  const st = (S.me && S.me.mode) !== 'adult';
  const labels = [tr('Home'), tr('Tracker'), st ? tr('Study') : tr('Life'), tr('Community'), tr('More')];
  const icons = [P.home, P.cal, st ? P.book : P.calp, P.users, P.more];
  $$('.tabs .tab').forEach((b, i) => { b.innerHTML = ic(icons[i], 22, 1.9) + `<span class="lb">${labels[i]}</span>`; b.setAttribute('aria-label', labels[i]); });
}
function go(i, anim = true) {
  S.tab = clamp(i, 0, 4);
  const t = $('#track');
  t.style.transition = anim ? '' : 'none';
  t.style.transform = `translateX(-${S.tab * 20}%)`;
  $$('.tabs .tab').forEach((b, k) => { b.classList.toggle('on', k === S.tab); b.setAttribute('aria-current', k === S.tab ? 'page' : 'false'); });
  $$('.page').forEach((p, k) => { p.inert = k !== S.tab; });
  if (S.tab === 3 && S.cm === 'wall') scrollChat();
  renderAll();
}
(() => {
  const pg = $('#pages'); let sx = 0, sy = 0, skip = false;
  pg.addEventListener('touchstart', (e) => { const t = e.touches[0]; sx = t.clientX; sy = t.clientY; skip = !!e.target.closest('input,textarea,.scrollx,.msgs'); }, { passive: true });
  pg.addEventListener('touchend', (e) => {
    if (skip) return;
    const t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.6) go(S.tab + (dx < 0 ? 1 : -1));
  }, { passive: true });
})();

/* ================= click delegation ================= */
document.addEventListener('click', async (e) => {
  if (e.target.classList && e.target.classList.contains('ov') && !e.target.classList.contains('glass') && e.target.id !== 'ov-form') { closeOv(e.target.id); return; }
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const a = b.dataset.act, v = b.dataset.v, id = b.dataset.id;
  switch (a) {
    case 'bg': applyLoginBg(v); break;
    case 'langopen': openLangSheet(); break;
    case 'setlang2': {
      setLang(v);
      closeOv('ov-lang');
      toast(tr('langChanged'));
      paintLangBtn();
      renderAll();
      break;
    }
    case 'mode': setMode(v); break;
    case 'forgot': forgotPassword($('#in-email').value); break;
    case 'pwtoggle': { const i = $('#in-pass'); i.type = i.type === 'password' ? 'text' : 'password'; break; }
    case 'tab': go(Number(v)); break;
    case 'cmview': S.cm = v; renderCommunity(); if (v === 'wall') scrollChat(); break;
    case 'gosetup': show('setup'); break;
    case 'skiproom': saveMe({ skippedRoom: true }); show('dash'); go(0, false); renderAll(); break;
    case 'profile': renderProfile(); openOv('ov-profile'); break;
    case 'closeov': closeOv(v); break;
    case 'copycode': { const ok = await copyText(S.code); toast(ok ? 'Code copy ho gaya: ' + S.code : 'Code: ' + S.code); break; }
    case 'copypending': { const ok = await copyText(S.pending); toast(ok ? 'Code copy ho gaya' : 'Code: ' + S.pending); break; }
    case 'create': createRoom(); break;
    case 'checkin': checkin(); break;
    case 'music': { const ok = Music.toggle(); if (!ok) toast('Is browser me audio nahi chalta'); else toast('Music: ' + Music.currentChannel().name); break; }
    case 'musicnext': { const c = Music.nextChannel(); toast('Music: ' + c.name); break; }
    case 'musicopen': Music.openMusic(); break;
    case 'setav': saveAvatar({ type: 'memoji', idx: Number(v) }); break;
    case 'avcreate': closeOv('ov-profile'); setTimeout(openAvatarCreator, 30); break;
    case 'editprofile': editProfile(); break;
    case 'statusemoji': pickEmoji((em) => { formSheet._emoji = em; b.firstChild.textContent = em + ' Status emoji chuno'; }); break;
    case 'resetpw': forgotPassword(S.user.email); break;
    case 'pickphoto': $('#photo-in').click(); break;
    case 'theme': applyTheme(v); renderProfile(); break;
    case 'leave': leaveRoom(); break;
    case 'logout': try { await signOut(auth); } catch (err) { fail(err); } break;
    case 'rxopen': S.rxOpen = id; renderChat(); break;
    case 'react': react(id, v); break;
    case 'chatemoji': pickEmoji((em) => { const i = $('#chat-input'); i.value = (i.value + em).slice(0, 400); i.focus(); }); break;
    case 'avreact': pickEmoji(async (em) => { if (!S.code) return; try { await addDoc(collection(db, 'rooms', S.code, 'messages'), { uid: S.user.uid, name: S.me.name, text: '', kind: 'areact', emoji: em, ts: serverTimestamp() }); } catch (err) { fail(err); } }); break;
    case 'announce': formSheet({ title: 'Room announcement', values: { t: (S.room.announce || {}).text || '' }, fields: [{ k: 't', l: 'Message (khali = hata do)', max: 200 }], onSave: (f) => updateDoc(doc(db, 'rooms', S.code), { announce: f.t ? { text: f.t, by: S.user.uid, ts: Date.now() } : null }).catch(fail) }); break;
    case 'additem': openOv('ov-add'); setTimeout(() => $('#add-title').focus(), 50); break;
    case 'toggleitem': { const it = S.me.schedule.find((x) => x.id === id); if (it) { it.on = !it.on; await saveSchedule(); } break; }
    case 'delitem': S.me.schedule = S.me.schedule.filter((x) => x.id !== id); await saveSchedule(); break;
    case 'togglemaster': {
      S.me.remindersOn = !S.me.remindersOn;
      if (S.me.remindersOn && (await N.permState()) === 'default') { const r = await N.askPermission(); if (r !== 'granted') toast('Notification allow nahi hui'); }
      await saveSchedule(); break;
    }
    case 'notif-allow': {
      store.set('nnn_notif_asked', '1'); closeOv('ov-notif');
      const r = await N.askPermission();
      if (r === 'granted') { S.me.remindersOn = true; await saveSchedule(); toast('Reminders chalu'); }
      break;
    }
    case 'notif-later': store.set('nnn_notif_asked', '1'); closeOv('ov-notif'); break;
  }
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { const t = topLayer(); if (t && t !== 'sub') popLayer(); } });
document.addEventListener('visibilitychange', () => { if (!document.hidden && S.me) { N.tick(); renderAll(); } });
setInterval(() => { if (S.me && !document.hidden) renderAll(); }, 60000);
N.startTicker();

/* ================= boot ui ================= */
$$('[data-peanut]').forEach((el) => { el.innerHTML = PEANUT; });
$$('[data-bell]').forEach((el) => { el.innerHTML = ic(P.bell, 28, 2); });
$$('.eye').forEach((el) => { el.innerHTML = ic(P.eye, 22, 1.8); });
$$('[data-act=logout].ibtn').forEach((el) => { el.innerHTML = ic(P.logout, 20, 1.8); });
$('.ibtn-d').innerHTML = ic(P.copy, 20, 1.8);
$('#music').innerHTML = `<span class="noteic">${ic(P.note, 20, 1.9)}</span><span class="eqbars" aria-hidden="true"><i></i><i></i><i></i></span>`;
$('#music-next').innerHTML = ic(P.next, 18, 1.9);
$('.send').innerHTML = ic(P.arrow, 22, 2.2);
$('[data-act=chatemoji]').innerHTML = ic(P.smile, 20, 1.9);
$('[data-act=avreact]').innerHTML = ic(P.spark, 20, 1.9);
paintTabs();
paintMusic();
paintLangBtn();
applyLang();
applyStaticI18n();
Music.loadLocalTracks();


applyLoginBg(store.get('nnn_bg', 'sage'));
applyTheme(store.get('nnn_theme', 'dark'));
applyA11y();
setMode('login');
$$('.page').forEach((p, k) => { p.inert = k !== 0; });

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
