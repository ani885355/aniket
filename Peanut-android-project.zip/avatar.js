/* ============================================================
   avatar.js — Peanut avatars.

   Do systems hain:
   1) MEMOJI   — 8 ready-made presets (har ek alag face shape).
   2) CREATOR  — layered SVG avatar jisme face shape, aankh, baal,
      daadhi, kapde, cap, accessory sab adjust ho sakte hain.

   Face shape FUNCTIONAL hai: har shape apni geometry deti hai
   (width, jaw, cheek, chin) aur aankh / naak / mooh / eyebrow
   usi geometry se position hote hain. Isliye "Square" chunne pe
   features bhi sahi jagah move karte hain — sirf outline nahi badalta.
   Face width aur face length ke sliders bhi hain (fw / fh).

   Ye real 3D engine nahi hai: layered 2.5D SVG hai jisme rotate
   slider head ko ghumata hai. Budget phones pe halka chalta hai.
   ============================================================ */
import { $, $$, esc, S, saveMe, toast, openSub, refreshSub, levelOf, ic, P, pad } from './core.js';

/* ---------- palette ---------- */
const SKIN = ['#FBE0C8', '#F0C9A5', '#E0AC7E', '#C98F5E', '#A9714B', '#8B5A3C', '#6B4430', '#4A2E22'];
const HAIRC = ['#14110E', '#3B2416', '#6B4423', '#A9712B', '#D8B25A', '#B5452F', '#9AA0A6', '#E8E4DA', '#5B3FA0', '#2E7D5B', '#C8F23A', '#FF5C93'];
const CLOTH = ['#2F3A2B', '#C8F23A', '#E7E2D0', '#20231C', '#3E6FB0', '#C8553D', '#7C5CBF', '#E8B96F', '#2E8B6E', '#FF5C93', '#6B6F63', '#141810'];
const BGS = ['#8FB8DE', '#E8B96F', '#B7A6E0', '#9AD1B5', '#F0A58A', '#E6D6B4', '#2F3A2B', '#C8F23A'];

/* ---------- FACE GEOMETRY ----------
   cx,cy  : face centre
   rx,ry  : half width / half height  (rw = rx*fw, rh = ry*fh)
   jaw    : jaw width factor (1 = full, <1 = narrow chin)
   side   : cheekbone width factor
   top    : forehead height factor (<1 = flat top)
   chin   : chin length factor
*/
export const FACES = {
  round: { label: 'Round', rx: 21, ry: 21.5, jaw: 0.92, side: 1.00, top: 1.00, chin: 0.96, sq: 0 },
  oval: { label: 'Oval', rx: 17.5, ry: 25.5, jaw: 0.78, side: 1.00, top: 1.00, chin: 1.00, sq: 0 },
  square: { label: 'Square', rx: 23, ry: 21, jaw: 1.02, side: 1.04, top: 0.80, chin: 0.88, sq: 1 },
  heart: { label: 'Heart', rx: 21, ry: 22, jaw: 0.66, side: 1.06, top: 1.02, chin: 1.08, sq: 0 },
  diamond: { label: 'Diamond', rx: 23, ry: 24, jaw: 0.54, side: 1.00, top: 0.70, chin: 1.08, sq: 0 },
  long: { label: 'Long', rx: 17, ry: 28, jaw: 0.86, side: 0.98, top: 1.00, chin: 0.99, sq: 0 },
  triangle: { label: 'Triangle', rx: 23, ry: 22, jaw: 0.60, side: 1.00, top: 0.70, chin: 1.10, sq: 0 }
};
export const FACE_KEYS = Object.keys(FACES);

/* ---------- parts catalogue ---------- */
export const CAT = {
  face: [['round', 'Round'], ['oval', 'Oval'], ['square', 'Square'], ['heart', 'Heart'], ['diamond', 'Diamond'], ['long', 'Long'], ['triangle', 'Triangle']],
  eyes: [['dot', 'Simple'], ['wide', 'Wide'], ['sleepy', 'Sleepy'], ['happy', 'Happy'], ['wink', 'Wink', 2]],
  brows: [['normal', 'Normal'], ['angry', 'Serious'], ['raised', 'Raised'], ['thin', 'Thin'], ['none', 'None']],
  nose: [['dot', 'Small'], ['line', 'Line'], ['round', 'Round']],
  mouth: [['smile', 'Smile'], ['grin', 'Grin'], ['neutral', 'Neutral'], ['wow', 'Wow'], ['smirk', 'Smirk', 2]],
  hair: [['short', 'Short'], ['side', 'Side part'], ['buzz', 'Buzz'], ['long', 'Long'], ['curly', 'Curly', 2], ['bun', 'Bun', 3], ['mohawk', 'Mohawk', 5], ['none', 'Bald']],
  beard: [['none', 'None'], ['stubble', 'Stubble'], ['mustache', 'Mustache', 2], ['beard', 'Beard', 3]],
  top: [['tee', 'T-shirt'], ['hoodie', 'Hoodie'], ['jacket', 'Jacket', 3], ['shirt', 'Shirt', 2]],
  shoes: [['sneaker', 'Sneakers'], ['boot', 'Boots', 4], ['flat', 'Flats']],
  glasses: [['none', 'None'], ['round', 'Round'], ['square', 'Square', 2], ['shades', 'Shades', 4]],
  hat: [['none', 'None'], ['cap', 'Cap'], ['beanie', 'Beanie', 3], ['bucket', 'Bucket hat', 6]],
  extra: [['none', 'None'], ['earring', 'Earring'], ['headphones', 'Headphones', 4], ['chain', 'Chain', 5], ['star', 'Star pin', 8]],
  pose: [['down', 'Relax'], ['wave', 'Wave'], ['up', 'Hands up', 3], ['hip', 'Hands on hip', 2]],
  ring: [['none', 'None'], ['lime', 'Lime'], ['gold', 'Gold', 5], ['pink', 'Pink', 3], ['white', 'White', 2]]
};
export const DEFAULT_P = {
  face: 'round', fw: 1, fh: 1, skin: 3, eyes: 'dot', brows: 'normal', nose: 'dot', mouth: 'smile',
  hair: 'short', hairc: 0, beard: 'none', top: 'tee', topc: 0, pants: 3, shoes: 'sneaker',
  glasses: 'none', hat: 'none', hatc: 1, extra: 'none', bg: 0, pose: 'down', ring: 'lime'
};
const RING = { none: null, lime: '#C8F23A', gold: '#F2C94C', pink: '#FF5C93', white: '#F2F1E8' };

/* ---------- MEMOJI presets (har ek alag face shape) ---------- */
export const MEMOJI = [
  { face: 'round', fw: 1, fh: 1, skin: 3, eyes: 'dot', brows: 'normal', nose: 'dot', mouth: 'smile', hair: 'short', hairc: 0, beard: 'none', top: 'tee', topc: 0, pants: 3, shoes: 'sneaker', glasses: 'none', hat: 'none', hatc: 1, extra: 'none', bg: 0, pose: 'down', ring: 'lime' },
  { face: 'oval', fw: 0.96, fh: 1.05, skin: 5, eyes: 'wide', brows: 'normal', nose: 'line', mouth: 'grin', hair: 'long', hairc: 1, beard: 'none', top: 'hoodie', topc: 4, pants: 3, shoes: 'sneaker', glasses: 'none', hat: 'none', hatc: 1, extra: 'earring', bg: 1, pose: 'wave', ring: 'pink' },
  { face: 'square', fw: 1.08, fh: 0.96, skin: 2, eyes: 'dot', brows: 'angry', nose: 'round', mouth: 'smirk', hair: 'buzz', hairc: 0, beard: 'stubble', top: 'jacket', topc: 5, pants: 11, shoes: 'boot', glasses: 'none', hat: 'none', hatc: 1, extra: 'none', bg: 3, pose: 'hip', ring: 'white' },
  { face: 'heart', fw: 1, fh: 1, skin: 1, eyes: 'happy', brows: 'raised', nose: 'dot', mouth: 'smile', hair: 'curly', hairc: 3, beard: 'none', top: 'shirt', topc: 2, pants: 4, shoes: 'flat', glasses: 'round', hat: 'none', hatc: 1, extra: 'none', bg: 2, pose: 'down', ring: 'gold' },
  { face: 'diamond', fw: 1, fh: 1.04, skin: 6, eyes: 'wide', brows: 'thin', nose: 'line', mouth: 'neutral', hair: 'mohawk', hairc: 9, beard: 'none', top: 'tee', topc: 6, pants: 11, shoes: 'boot', glasses: 'shades', hat: 'none', hatc: 1, extra: 'chain', bg: 5, pose: 'down', ring: 'none' },
  { face: 'long', fw: 0.94, fh: 1.08, skin: 4, eyes: 'sleepy', brows: 'normal', nose: 'dot', mouth: 'smile', hair: 'bun', hairc: 1, beard: 'none', top: 'tee', topc: 8, pants: 3, shoes: 'sneaker', glasses: 'none', hat: 'beanie', hatc: 1, extra: 'none', bg: 4, pose: 'wave', ring: 'pink' },
  { face: 'triangle', fw: 1.02, fh: 1, skin: 0, eyes: 'wink', brows: 'raised', nose: 'dot', mouth: 'wow', hair: 'side', hairc: 4, beard: 'none', top: 'hoodie', topc: 9, pants: 4, shoes: 'sneaker', glasses: 'none', hat: 'cap', hatc: 1, extra: 'headphones', bg: 6, pose: 'up', ring: 'lime' },
  { face: 'round', fw: 1.04, fh: 0.98, skin: 7, eyes: 'dot', brows: 'normal', nose: 'round', mouth: 'grin', hair: 'short', hairc: 6, beard: 'beard', top: 'tee', topc: 10, pants: 3, shoes: 'sneaker', glasses: 'square', hat: 'none', hatc: 1, extra: 'none', bg: 7, pose: 'down', ring: 'none' }
];

const PHOTO_RE = /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/;
const shade = (hex, amt) => {
  const n = parseInt(hex.slice(1), 16);
  const f = (v) => Math.max(0, Math.min(255, v + amt));
  return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => f(v).toString(16).padStart(2, '0')).join('');
};

/* ============================================================
   Geometry
   ============================================================ */
function geom(p) {
  const f = FACES[p.face] || FACES.round;
  const cx = 50, cy = 43;
  const fw = Number(p.fw) || 1, fh = Number(p.fh) || 1;
  const rx = f.rx * fw, ry = f.ry * fh;
  const ty = cy - ry * f.top;                 /* forehead top */
  const eyeY = cy - ry * 0.07;
  const eyeDX = rx * f.side * 0.44;
  const eyeR = Math.max(2.2, rx * 0.115);
  return {
    cx, cy, rx, ry, ty,
    jaw: f.jaw, side: f.side, top: f.top, chin: f.chin, sq: f.sq || 0,
    eyeY, eyeDX, eyeR,
    browY: eyeY - ry * 0.30,
    noseY: cy + ry * 0.16,
    mouthY: cy + ry * 0.40,
    mouthW: rx * f.jaw * 0.64,
    cheekY: cy + ry * 0.04, cheekX: rx * 0.74,
    earY: cy + ry * 0.06, earX: rx + 1.2
  };
}

/* Face outline — shape + jaw/cheek/chin se generated path */
function facePath(g) {
  const { cx, cy, rx, ry, ty, jaw, side, chin, sq } = g;
  const by = cy + ry * chin;                  /* chin bottom */
  const bx = rx * jaw * 0.56;                 /* chin half width */
  const mx = rx * side;                       /* cheekbone half width */
  const hx = rx * 0.94;                       /* temple */
  if (sq) {
    /* square: flat top, seedhi seedhi straight sides, hard jaw corners */
    return `M${cx - hx} ${ty + ry * 0.12}
C${cx - hx * 0.45} ${ty - ry * 0.04} ${cx + hx * 0.45} ${ty - ry * 0.04} ${cx + hx} ${ty + ry * 0.12}
L${cx + mx} ${cy - ry * 0.22}
L${cx + mx} ${by - ry * 0.36}
L${cx + rx * jaw * 0.70} ${by}
Q${cx} ${by + ry * 0.13} ${cx - rx * jaw * 0.70} ${by}
L${cx - mx} ${by - ry * 0.36}
L${cx - mx} ${cy - ry * 0.22} Z`;
  }
  return `M${cx} ${ty}
C${cx + hx} ${ty} ${cx + mx} ${cy - ry * 0.52} ${cx + mx} ${cy - ry * 0.06}
C${cx + mx} ${cy + ry * 0.40} ${cx + rx * jaw} ${by - ry * 0.30} ${cx + bx} ${by}
C${cx + bx * 0.46} ${by + ry * 0.11} ${cx - bx * 0.46} ${by + ry * 0.11} ${cx - bx} ${by}
C${cx - rx * jaw} ${by - ry * 0.30} ${cx - mx} ${cy + ry * 0.40} ${cx - mx} ${cy - ry * 0.06}
C${cx - mx} ${cy - ry * 0.52} ${cx - hx} ${ty} ${cx} ${ty} Z`;
}

/* Hair — geometry se derive hota hai taaki har face shape pe fit ho.
   Return kare to poora SVG markup (path/circle elements). */
function hairPaths(p, g) {
  const { cx, cy, rx, ry, ty } = g;
  const T = ty, B = ty + ry * 0.34;
  const X = rx * 0.99;
  const cap = (extra = '') => `<path d="M${cx - X} ${B} C${cx - X * 1.08} ${T - ry * 0.62} ${cx + X * 1.08} ${T - ry * 0.62} ${cx + X} ${B}
C${cx + X * 0.9} ${T + ry * 0.03} ${cx + rx * 0.58} ${T - ry * 0.09} ${cx} ${T - ry * 0.09}
C${cx - rx * 0.58} ${T - ry * 0.09} ${cx - X * 0.9} ${T + ry * 0.03} ${cx - X} ${B} Z"${extra}/>`;
  switch (p.hair) {
    case 'short': return { back: '', front: cap() };
    case 'side': return {
      back: '',
      front: `<path d="M${cx - X} ${B} C${cx - X * 1.08} ${T - ry * 0.62} ${cx + X * 1.08} ${T - ry * 0.62} ${cx + X} ${B}
C${cx + X * 0.92} ${T + ry * 0.02} ${cx + rx * 0.30} ${T - ry * 0.16} ${cx - rx * 0.10} ${T - ry * 0.02}
C${cx - rx * 0.45} ${T + ry * 0.10} ${cx - X * 0.92} ${T + ry * 0.06} ${cx - X} ${B} Z"/>`
    };
    case 'buzz': return {
      back: '',
      front: `<path d="M${cx - X * 0.98} ${B - ry * 0.04} C${cx - X * 1.02} ${T - ry * 0.54} ${cx + X * 1.02} ${T - ry * 0.54} ${cx + X * 0.98} ${B - ry * 0.04}
C${cx + X * 0.84} ${T + ry * 0.06} ${cx + rx * 0.54} ${T - ry * 0.03} ${cx} ${T - ry * 0.03}
C${cx - rx * 0.54} ${T - ry * 0.03} ${cx - X * 0.84} ${T + ry * 0.06} ${cx - X * 0.98} ${B - ry * 0.04} Z" opacity=".72"/>`
    };
    case 'long': return {
      back: `<path d="M${cx - X * 0.96} ${cy - ry * 0.1} C${cx - X * 1.08} ${cy + ry * 0.95} ${cx - X * 0.72} ${cy + ry * 1.45} ${cx - rx * 0.42} ${cy + ry * 1.5}
C${cx - rx * 0.1} ${cy + ry * 1.55} ${cx + rx * 0.1} ${cy + ry * 1.55} ${cx + rx * 0.42} ${cy + ry * 1.5}
C${cx + X * 0.72} ${cy + ry * 1.45} ${cx + X * 1.08} ${cy + ry * 0.95} ${cx + X * 0.96} ${cy - ry * 0.1} Z"/>`,
      front: cap()
    };
    case 'curly': {
      const pts = [[-0.95, 0.18], [-0.62, -0.10], [-0.24, -0.28], [0.16, -0.30], [0.55, -0.18], [0.88, 0.06], [-1.0, 0.42], [1.0, 0.42]];
      const cr = pts.map(([dx, dy]) => `<circle cx="${(cx + dx * rx).toFixed(2)}" cy="${(ty + ry * dy).toFixed(2)}" r="${(rx * 0.30).toFixed(2)}"/>`).join('');
      return { back: '', front: cr };
    }
    case 'bun': return {
      back: `<circle cx="${cx}" cy="${ty - ry * 0.42}" r="${(rx * 0.28).toFixed(2)}"/>`,
      front: cap()
    };
    case 'mohawk': return {
      back: '',
      front: `<path d="M${cx - rx * 0.42} ${T - ry * 0.08} C${cx - rx * 0.40} ${T - ry * 0.95} ${cx + rx * 0.40} ${T - ry * 0.95} ${cx + rx * 0.42} ${T - ry * 0.08} Z"/>`
    };
    default: return { back: '', front: '' };
  }
}

/* ============================================================
   Renderer
   ============================================================ */
export function avatarSVG(pp, opt = {}) {
  const p = { ...DEFAULT_P, ...(pp || {}) };
  const size = opt.size || 64, full = !!opt.full, yaw = Number(opt.yaw) || 0;
  const skin = SKIN[p.skin] || SKIN[3], skinD = shade(skin, -26), hairC = HAIRC[p.hairc] || HAIRC[0];
  const topC = CLOTH[p.topc] || CLOTH[0], pantC = CLOTH[p.pants] || CLOTH[3], hatC = CLOTH[p.hatc] || CLOTH[1];
  const bg = BGS[p.bg] || BGS[0], ring = RING[p.ring] || null;
  const rad = (yaw * Math.PI) / 180, cxr = Math.cos(rad), sx = Math.sin(rad) * 9;
  const ink = '#1B1510', uid = 'a' + Math.random().toString(36).slice(2, 7);
  const g = geom(p);
  const { cx, cy, rx, ry, ty } = g;

  const head = (inner) => `<g transform="translate(50 43) scale(${cxr.toFixed(3)} 1) translate(-50 -43)">${inner}</g>`;
  const feat = (inner) => `<g transform="translate(${(sx / Math.max(cxr, .5)).toFixed(2)} 0)">${inner}</g>`;

  /* --- eyes --- */
  const E = (x, side) => {
    const r = g.eyeR, y = g.eyeY;
    switch (p.eyes) {
      case 'wide': return `<ellipse cx="${x}" cy="${y}" rx="${(r * 1.16).toFixed(2)}" ry="${(r * 1.28).toFixed(2)}" fill="#fff"/><circle cx="${x}" cy="${(y + r * 0.2).toFixed(2)}" r="${(r * 0.72).toFixed(2)}" fill="${ink}"/>`;
      case 'sleepy': return `<path d="M${x - r * 1.35} ${y} H${x + r * 1.35}" stroke="${ink}" stroke-width="${(r * 0.7).toFixed(2)}" stroke-linecap="round"/><circle cx="${x}" cy="${(y + r * 0.62).toFixed(2)}" r="${(r * 0.62).toFixed(2)}" fill="${ink}"/>`;
      case 'happy': return `<path d="M${x - r * 1.35} ${y + r * 0.35} Q${x} ${y - r * 1.0} ${x + r * 1.35} ${y + r * 0.35}" fill="none" stroke="${ink}" stroke-width="${(r * 0.78).toFixed(2)}" stroke-linecap="round"/>`;
      case 'wink': return side < 0
        ? `<circle cx="${x}" cy="${y}" r="${(r * 0.92).toFixed(2)}" fill="${ink}"/>`
        : `<path d="M${x - r * 1.35} ${y + r * 0.2} Q${x} ${y - r * 0.85} ${x + r * 1.35} ${y + r * 0.2}" fill="none" stroke="${ink}" stroke-width="${(r * 0.78).toFixed(2)}" stroke-linecap="round"/>`;
      default: return `<circle cx="${x}" cy="${y}" r="${(r * 0.95).toFixed(2)}" fill="${ink}"/>`;
    }
  };
  /* --- brows --- */
  const B = (x, side) => {
    const y = g.browY, w = g.eyeDX * 0.46;
    switch (p.brows) {
      case 'none': return '';
      case 'angry': return `<path d="M${x - w} ${y - side * w * 0.3} L${x + w} ${y + side * w * 0.3}" stroke="${hairC}" stroke-width="${(g.eyeR * 0.78).toFixed(2)}" stroke-linecap="round"/>`;
      case 'raised': return `<path d="M${x - w} ${y + side * w * 0.1} Q${x} ${y - g.eyeR * 2.1} ${x + w} ${y + side * w * 0.1}" fill="none" stroke="${hairC}" stroke-width="${(g.eyeR * 0.66).toFixed(2)}" stroke-linecap="round"/>`;
      case 'thin': return `<path d="M${x - w} ${y} H${x + w}" stroke="${hairC}" stroke-width="${(g.eyeR * 0.4).toFixed(2)}" stroke-linecap="round"/>`;
      default: return `<path d="M${x - w} ${y} H${x + w}" stroke="${hairC}" stroke-width="${(g.eyeR * 0.78).toFixed(2)}" stroke-linecap="round"/>`;
    }
  };
  /* --- nose --- */
  const noseY = g.noseY, noseW = rx * 0.075;
  const nose = p.nose === 'line'
    ? `<path d="M${cx} ${noseY - ry * 0.14} V${noseY} H${(cx + noseW * 1.5).toFixed(2)}" fill="none" stroke="${skinD}" stroke-width="${(rx * 0.062).toFixed(2)}" stroke-linecap="round"/>`
    : p.nose === 'round'
      ? `<circle cx="${cx}" cy="${noseY}" r="${(rx * 0.09).toFixed(2)}" fill="${skinD}"/>`
      : `<ellipse cx="${cx}" cy="${noseY}" rx="${(noseW * 1.1).toFixed(2)}" ry="${(rx * 0.05).toFixed(2)}" fill="${skinD}"/>`;
  /* --- mouth --- */
  const my = g.mouthY, mw = g.mouthW;
  const mouth = {
    smile: `<path d="M${cx - mw * 0.5} ${my - ry * 0.03} Q${cx} ${my + ry * 0.19} ${cx + mw * 0.5} ${my - ry * 0.03}" fill="none" stroke="${ink}" stroke-width="${(rx * 0.075).toFixed(2)}" stroke-linecap="round"/>`,
    grin: `<path d="M${cx - mw * 0.55} ${my - ry * 0.05} Q${cx} ${my + ry * 0.28} ${cx + mw * 0.55} ${my - ry * 0.05} Z" fill="#fff" stroke="${ink}" stroke-width="${(rx * 0.068).toFixed(2)}" stroke-linejoin="round"/>`,
    neutral: `<path d="M${cx - mw * 0.42} ${my} H${cx + mw * 0.42}" stroke="${ink}" stroke-width="${(rx * 0.075).toFixed(2)}" stroke-linecap="round"/>`,
    wow: `<ellipse cx="${cx}" cy="${my + ry * 0.05}" rx="${(mw * 0.23).toFixed(2)}" ry="${(ry * 0.13).toFixed(2)}" fill="${ink}"/>`,
    smirk: `<path d="M${cx - mw * 0.45} ${my + ry * 0.02} Q${cx + mw * 0.1} ${my + ry * 0.12} ${cx + mw * 0.5} ${my - ry * 0.08}" fill="none" stroke="${ink}" stroke-width="${(rx * 0.075).toFixed(2)}" stroke-linecap="round"/>`
  }[p.mouth] || '';
  /* --- beard --- */
  const by = cy + ry * 0.20, bwid = rx * g.jaw;
  const beard = {
    stubble: `<path d="M${cx - bwid} ${by} Q${cx} ${cy + ry * 1.12} ${cx + bwid} ${by} Q${cx} ${cy + ry * 0.72} ${cx} ${cy + ry * 0.72} Q${cx - bwid * 0.72} ${cy + ry * 0.72} ${cx - bwid} ${by} Z" fill="${hairC}" opacity=".26"/>`,
    mustache: `<path d="M${cx - mw * 0.42} ${my - ry * 0.09} Q${cx - mw * 0.12} ${my - ry * 0.19} ${cx} ${my - ry * 0.10} Q${cx + mw * 0.12} ${my - ry * 0.19} ${cx + mw * 0.42} ${my - ry * 0.09} Q${cx + mw * 0.2} ${my - ry * 0.01} ${cx} ${my - ry * 0.03} Q${cx - mw * 0.2} ${my - ry * 0.01} ${cx - mw * 0.42} ${my - ry * 0.09} Z" fill="${hairC}"/>`,
    beard: `<path d="M${cx - bwid} ${by - ry * 0.04} Q${cx - bwid * 0.9} ${cy + ry * 1.16} ${cx} ${cy + ry * 1.16} Q${cx + bwid * 0.9} ${cy + ry * 1.16} ${cx + bwid} ${by - ry * 0.04} Q${cx + mw * 0.5} ${cy + ry * 0.66} ${cx} ${cy + ry * 0.66} Q${cx - mw * 0.5} ${cy + ry * 0.66} ${cx - bwid} ${by - ry * 0.04} Z" fill="${hairC}"/><path d="M${cx - mw * 0.42} ${my - ry * 0.09} Q${cx - mw * 0.12} ${my - ry * 0.19} ${cx} ${my - ry * 0.10} Q${cx + mw * 0.12} ${my - ry * 0.19} ${cx + mw * 0.42} ${my - ry * 0.09} Q${cx + mw * 0.2} ${my - ry * 0.01} ${cx} ${my - ry * 0.03} Q${cx - mw * 0.2} ${my - ry * 0.01} ${cx - mw * 0.42} ${my - ry * 0.09} Z" fill="${hairC}"/>`
  }[p.beard] || '';
  /* --- glasses --- */
  const ex = g.eyeDX, ey = g.eyeY, er = g.eyeR;
  const glasses = {
    round: `<g fill="rgba(255,255,255,.18)" stroke="${ink}" stroke-width="${(rx * 0.05).toFixed(2)}"><circle cx="${cx - ex}" cy="${ey}" r="${(er * 2.1).toFixed(2)}"/><circle cx="${cx + ex}" cy="${ey}" r="${(er * 2.1).toFixed(2)}"/></g><path d="M${cx - ex + er * 2.1} ${ey} H${cx + ex - er * 2.1}" stroke="${ink}" stroke-width="${(rx * 0.05).toFixed(2)}"/>`,
    square: `<g fill="rgba(255,255,255,.18)" stroke="${ink}" stroke-width="${(rx * 0.05).toFixed(2)}"><rect x="${cx - ex - er * 2.2}" y="${ey - er * 1.6}" width="${(er * 4.4).toFixed(2)}" height="${(er * 3.2).toFixed(2)}" rx="${(er * 0.7).toFixed(2)}"/><rect x="${cx + ex - er * 2.2}" y="${ey - er * 1.6}" width="${(er * 4.4).toFixed(2)}" height="${(er * 3.2).toFixed(2)}" rx="${(er * 0.7).toFixed(2)}"/></g><path d="M${cx - ex + er * 2.2} ${ey - er * 0.2} H${cx + ex - er * 2.2}" stroke="${ink}" stroke-width="${(rx * 0.05).toFixed(2)}"/>`,
    shades: `<g fill="#141810"><rect x="${cx - ex - er * 2.3}" y="${ey - er * 1.6}" width="${(er * 4.6).toFixed(2)}" height="${(er * 3.1).toFixed(2)}" rx="${(er * 0.9).toFixed(2)}"/><rect x="${cx + ex - er * 2.3}" y="${ey - er * 1.6}" width="${(er * 4.6).toFixed(2)}" height="${(er * 3.1).toFixed(2)}" rx="${(er * 0.9).toFixed(2)}"/></g><path d="M${cx - ex + er * 2.3} ${ey - er * 0.4} H${cx + ex - er * 2.3}" stroke="#141810" stroke-width="${(rx * 0.055).toFixed(2)}"/>`
  }[p.glasses] || '';
  /* --- hat --- */
  const hatTop = ty - ry * 0.16;
  const hat = {
    cap: `<path d="M${cx - rx * 1.02} ${hatTop + ry * 0.1} C${cx - rx * 1.0} ${hatTop - ry * 1.05} ${cx + rx * 1.0} ${hatTop - ry * 1.05} ${cx + rx * 1.02} ${hatTop + ry * 0.1} Z" fill="${hatC}"/><path d="M${cx - rx * 1.06} ${hatTop + ry * 0.08} H${cx + rx * 0.28} Q${cx + rx * 0.5} ${hatTop + ry * 0.3} ${cx + rx * 0.2} ${hatTop + ry * 0.3} H${cx - rx * 1.06} Z" fill="${shade(hatC, -30)}"/>`,
    beanie: `<path d="M${cx - rx * 1.04} ${hatTop + ry * 0.12} C${cx - rx * 1.02} ${hatTop - ry * 1.18} ${cx + rx * 1.02} ${hatTop - ry * 1.18} ${cx + rx * 1.04} ${hatTop + ry * 0.12} Z" fill="${hatC}"/><rect x="${cx - rx * 1.06}" y="${hatTop + ry * 0.02}" width="${(rx * 2.12).toFixed(2)}" height="${(ry * 0.26).toFixed(2)}" rx="${(ry * 0.13).toFixed(2)}" fill="${shade(hatC, -30)}"/><circle cx="${cx}" cy="${hatTop - ry * 1.2}" r="${(rx * 0.13).toFixed(2)}" fill="${shade(hatC, -30)}"/>`,
    bucket: `<path d="M${cx - rx * 0.86} ${hatTop + ry * 0.06} C${cx - rx * 0.86} ${hatTop - ry * 0.92} ${cx + rx * 0.86} ${hatTop - ry * 0.92} ${cx + rx * 0.86} ${hatTop + ry * 0.06} Z" fill="${hatC}"/><ellipse cx="${cx}" cy="${hatTop + ry * 0.06}" rx="${(rx * 1.16).toFixed(2)}" ry="${(ry * 0.2).toFixed(2)}" fill="${shade(hatC, -30)}"/>`
  }[p.hat] || '';
  const earring = p.extra === 'earring' ? `<circle cx="${(cx - g.earX).toFixed(2)}" cy="${(g.earY + ry * 0.16).toFixed(2)}" r="${(rx * 0.07).toFixed(2)}" fill="#F2C94C"/>` : '';
  const phones = p.extra === 'headphones'
    ? `<path d="M${cx - rx * 1.0} ${g.earY} C${cx - rx * 1.06} ${ty - ry * 1.2} ${cx + rx * 1.06} ${ty - ry * 1.2} ${cx + rx * 1.0} ${g.earY}" fill="none" stroke="#141810" stroke-width="${(rx * 0.12).toFixed(2)}"/>
       <rect x="${(cx - rx * 1.12).toFixed(2)}" y="${(g.earY - ry * 0.18).toFixed(2)}" width="${(rx * 0.26).toFixed(2)}" height="${(ry * 0.52).toFixed(2)}" rx="${(rx * 0.13).toFixed(2)}" fill="#C8F23A"/>
       <rect x="${(cx + rx * 0.86).toFixed(2)}" y="${(g.earY - ry * 0.18).toFixed(2)}" width="${(rx * 0.26).toFixed(2)}" height="${(ry * 0.52).toFixed(2)}" rx="${(rx * 0.13).toFixed(2)}" fill="#C8F23A"/>`
    : '';

  /* --- body --- */
  const bodyTop = cy + ry * 0.92;
  const arm = (side) => {
    const sgn = side === 'L' ? -1 : 1, sx0 = cx + sgn * rx * 0.95, y0 = bodyTop + rx * 0.12;
    let ex, ey;
    if (p.pose === 'wave' && side === 'R') { ex = cx + rx * 1.4; ey = cy - ry * 0.1; }
    else if (p.pose === 'up') { ex = cx + sgn * rx * 1.28; ey = cy - ry * 0.05; }
    else if (p.pose === 'hip') { ex = cx + sgn * rx * 1.22; ey = bodyTop + rx * 0.7; }
    else { ex = cx + sgn * rx * 1.14; ey = bodyTop + rx * 0.92; }
    const bend = (p.top === 'tee') ? 0.45 : 1;
    const mx = sx0 + (ex - sx0) * bend, my = y0 + (ey - y0) * bend;
    const hipBend = p.pose === 'hip' ? `Q${cx + sgn * rx * 1.5} ${bodyTop + rx * 0.4} ${ex} ${ey}` : `L${ex} ${ey}`;
    return `<path d="M${sx0} ${y0} ${hipBend}" stroke="${skin}" stroke-width="${(rx * 0.36).toFixed(2)}" stroke-linecap="round" fill="none"/>
<path d="M${sx0} ${y0} L${mx} ${my}" stroke="${topC}" stroke-width="${(rx * 0.42).toFixed(2)}" stroke-linecap="round" fill="none"/><circle cx="${ex}" cy="${ey}" r="${(rx * 0.21).toFixed(2)}" fill="${skin}"/>`;
  };
  const torsoTop = {
    tee: '',
    hoodie: `<path d="M${cx - rx * 0.52} ${bodyTop + rx * 0.02} Q${cx} ${bodyTop + rx * 0.46} ${cx + rx * 0.52} ${bodyTop + rx * 0.02} Q${cx} ${bodyTop + rx * 0.24} ${cx - rx * 0.52} ${bodyTop + rx * 0.02} Z" fill="${shade(topC, -28)}"/><rect x="${cx - rx * 0.42}" y="${bodyTop + rx * 0.58}" width="${(rx * 0.84).toFixed(2)}" height="${(rx * 0.38).toFixed(2)}" rx="${(rx * 0.19).toFixed(2)}" fill="${shade(topC, -18)}"/>`,
    jacket: `<path d="M${cx} ${bodyTop + rx * 0.06} V${bodyTop + rx * 1.0}" stroke="${shade(topC, -40)}" stroke-width="${(rx * 0.08).toFixed(2)}"/><path d="M${cx - rx * 0.42} ${bodyTop} L${cx} ${bodyTop + rx * 0.5} L${cx - rx * 0.24} ${bodyTop} Z M${cx + rx * 0.42} ${bodyTop} L${cx} ${bodyTop + rx * 0.5} L${cx + rx * 0.24} ${bodyTop} Z" fill="${shade(topC, -30)}"/>`,
    shirt: `<path d="M${cx - rx * 0.34} ${bodyTop - rx * 0.02} L${cx} ${bodyTop + rx * 0.3} L${cx + rx * 0.34} ${bodyTop - rx * 0.02} L${cx + rx * 0.17} ${bodyTop - rx * 0.08} L${cx} ${bodyTop + rx * 0.06} L${cx - rx * 0.17} ${bodyTop - rx * 0.08} Z" fill="#F2F1E8"/><g fill="#F2F1E8"><circle cx="${cx}" cy="${bodyTop + rx * 0.62}" r="${(rx * 0.045).toFixed(2)}"/><circle cx="${cx}" cy="${bodyTop + rx * 0.95}" r="${(rx * 0.045).toFixed(2)}"/></g>`
  }[p.top] || '';
  const shoeC = p.shoes === 'boot' ? '#5A3A22' : p.shoes === 'flat' ? '#141810' : '#F2F1E8';
  const legTop = bodyTop + rx * 1.3;
  const bodyFull = `
<rect x="${cx - rx * 0.55}" y="${legTop}" width="${(rx * 0.5).toFixed(2)}" height="${(rx * 1.8).toFixed(2)}" rx="${(rx * 0.21).toFixed(2)}" fill="${pantC}"/>
<rect x="${cx + rx * 0.05}" y="${legTop}" width="${(rx * 0.5).toFixed(2)}" height="${(rx * 1.8).toFixed(2)}" rx="${(rx * 0.21).toFixed(2)}" fill="${pantC}"/>
<rect x="${cx - rx * 0.66}" y="${legTop + rx * 1.68}" width="${(rx * 0.68).toFixed(2)}" height="${(rx * 0.38).toFixed(2)}" rx="${(rx * 0.19).toFixed(2)}" fill="${shoeC}"/>
<rect x="${cx - rx * 0.02}" y="${legTop + rx * 1.68}" width="${(rx * 0.68).toFixed(2)}" height="${(rx * 0.38).toFixed(2)}" rx="${(rx * 0.19).toFixed(2)}" fill="${shoeC}"/>
${p.shoes === 'sneaker' ? `<path d="M${cx - rx * 0.66} ${legTop + rx * 1.88} H${cx + rx * 0.02} M${cx - rx * 0.02} ${legTop + rx * 1.88} H${cx + rx * 0.66}" stroke="#C8F23A" stroke-width="${(rx * 0.06).toFixed(2)}"/>` : ''}`;
  const torso = `<g transform="translate(${cx} ${bodyTop + rx * 0.5}) scale(${(0.82 + 0.18 * cxr).toFixed(3)} 1) translate(${-cx} ${-(bodyTop + rx * 0.5)})">
<path d="M${cx - rx * 1.05} ${bodyTop + rx * 1.35} C${cx - rx * 1.08} ${bodyTop + rx * 0.3} ${cx - rx * 0.6} ${bodyTop - rx * 0.02} ${cx} ${bodyTop - rx * 0.02} C${cx + rx * 0.6} ${bodyTop - rx * 0.02} ${cx + rx * 1.08} ${bodyTop + rx * 0.3} ${cx + rx * 1.05} ${bodyTop + rx * 1.35} Z" fill="${topC}"/>${torsoTop}${arm('L')}${arm('R')}
${p.extra === 'chain' ? `<path d="M${cx - rx * 0.38} ${bodyTop - rx * 0.02} Q${cx} ${bodyTop + rx * 0.52} ${cx + rx * 0.38} ${bodyTop - rx * 0.02}" fill="none" stroke="#F2C94C" stroke-width="${(rx * 0.07).toFixed(2)}"/><circle cx="${cx}" cy="${bodyTop + rx * 0.38}" r="${(rx * 0.1).toFixed(2)}" fill="#F2C94C"/>` : ''}
${p.extra === 'star' ? `<path d="m${cx - rx * 0.5} ${bodyTop + rx * 0.42} ${rx * 0.07} ${rx * 0.15} ${rx * 0.16} ${rx * 0.02} -${rx * 0.12} ${rx * 0.11} ${rx * 0.03} ${rx * 0.16} -${rx * 0.14} -${rx * 0.08} -${rx * 0.14} ${rx * 0.08} ${rx * 0.03} -${rx * 0.16} -${rx * 0.12} -${rx * 0.11} ${rx * 0.16} -${rx * 0.02} Z" fill="#F2C94C"/>` : ''}</g>`;
  const neck = `<rect x="${(cx - rx * 0.26).toFixed(2)}" y="${(cy + ry * 0.62).toFixed(2)}" width="${(rx * 0.52).toFixed(2)}" height="${(ry * 0.5).toFixed(2)}" rx="${(rx * 0.2).toFixed(2)}" fill="${skinD}"/>`;

  const hp = hairPaths(p, g);
  const headSvg = head(`${hp.back}<circle cx="${(cx - g.earX).toFixed(2)}" cy="${g.earY}" r="${(rx * 0.18).toFixed(2)}" fill="${skin}"/><circle cx="${(cx + g.earX).toFixed(2)}" cy="${g.earY}" r="${(rx * 0.18).toFixed(2)}" fill="${skin}"/>${earring}
<g fill="${skin}"><path d="${facePath(g)}"/></g>${feat(`${beard}<g fill="#E39A6B" opacity=".34"><circle cx="${(cx - g.cheekX).toFixed(2)}" cy="${g.cheekY}" r="${(rx * 0.15).toFixed(2)}"/><circle cx="${(cx + g.cheekX).toFixed(2)}" cy="${g.cheekY}" r="${(rx * 0.15).toFixed(2)}"/></g>${E(cx - g.eyeDX, -1)}${E(cx + g.eyeDX, 1)}${B(cx - g.eyeDX, 1)}${B(cx + g.eyeDX, -1)}${nose}${mouth}${glasses}`)}<g fill="${hairC}">${hp.front}</g>${hat}${phones}`);

  const vb = full ? '0 0 100 156' : '12 8 76 76';
  const w = full ? Math.round(size * 100 / 156) : size, h = full ? size : size;
  const clip = full ? '' : `<clipPath id="${uid}"><circle cx="50" cy="45" r="38"/></clipPath>`;
  const bgShape = full
    ? `<rect x="0" y="0" width="100" height="156" rx="16" fill="${bg}"/><ellipse cx="50" cy="152" rx="26" ry="3.5" fill="#000" opacity=".18"/>`
    : `<circle cx="50" cy="45" r="38" fill="${bg}"/>`;
  return `<svg class="av ${full ? 'avfull' : ''}" viewBox="${vb}" width="${w}" height="${h}" role="img" aria-label="Avatar" xmlns="http://www.w3.org/2000/svg">${clip}${bgShape}
<g ${full ? '' : `clip-path="url(#${uid})"`}>${full ? bodyFull : ''}${torso}${neck}${headSvg}</g>${!full && ring ? `<circle cx="50" cy="45" r="37" fill="none" stroke="${ring}" stroke-width="2.6"/>` : ''}${full && ring ? `<rect x="1.5" y="1.5" width="97" height="153" rx="15" fill="none" stroke="${ring}" stroke-width="2.4"/>` : ''}</svg>`;
}

export function avatarHTML(av, size) {
  if (av && av.type === 'photo' && typeof av.data === 'string' && PHOTO_RE.test(av.data)) {
    return `<img class="av" src="${av.data}" width="${size}" height="${size}" alt="">`;
  }
  if (av && av.type === 'custom' && av.p && typeof av.p === 'object') return avatarSVG(av.p, { size });
  const idx = (Number(av && av.idx) | 0) % MEMOJI.length;
  return avatarSVG(MEMOJI[idx < 0 ? 0 : idx], { size });
}

/* ============================================================
   Creator
   ============================================================ */
const TABS = [
  ['face', 'Face', ['face', 'fw', 'fh']], ['eyes', 'Eyes', ['eyes', 'brows']], ['nose', 'Nose+Mouth', ['nose', 'mouth']],
  ['hair', 'Hair', ['hair', 'hairc']], ['beard', 'Beard', ['beard']], ['outfit', 'Outfit', ['top', 'topc', 'pants']],
  ['shoes', 'Shoes', ['shoes']], ['acc', 'Glasses+Hat', ['glasses', 'hat', 'hatc']], ['extra', 'Extras', ['extra', 'ring']],
  ['bg', 'Bg+Pose', ['bg', 'pose']]
];
const SW = { skin: SKIN, hairc: HAIRC, topc: CLOTH, pants: CLOTH, hatc: CLOTH, bg: BGS };
const LABEL = {
  face: 'Face shape', fw: 'Face width', fh: 'Face length', skin: 'Skin tone', eyes: 'Eyes', brows: 'Eyebrows',
  nose: 'Nose', mouth: 'Expression', hair: 'Hairstyle', hairc: 'Hair colour', beard: 'Facial hair',
  top: 'Top', topc: 'Top colour', pants: 'Trouser colour', shoes: 'Shoes', glasses: 'Glasses',
  hat: 'Cap / hat', hatc: 'Hat colour', extra: 'Accessory', ring: 'Border', bg: 'Background', pose: 'Pose'
};
let C = null;

const lvl = () => levelOf(S.me.xp || 0);

export function openAvatarCreator() {
  const cur = S.me.avatar && S.me.avatar.type === 'custom' ? S.me.avatar.p : null;
  C = { p: { ...DEFAULT_P, ...(cur || {}) }, tab: 'face', yaw: 0, spin: null };
  openSub('Avatar banao', renderCreator, '');
}
function stopSpin() { if (C && C.spin) { clearInterval(C.spin); C.spin = null; } }

function slider(k, min, max, step, fmt) {
  const v = Number(C.p[k] ?? 1);
  return `<div class="mono lbl">${LABEL[k]} <b class="slval">${fmt(v)}</b></div>
<input class="rng" type="range" data-act="avslide" data-k="${k}" min="${min}" max="${max}" step="${step}" value="${v}" aria-label="${LABEL[k]}">`;
}

function renderCreator(body) {
  const L = lvl(), tab = TABS.find((t) => t[0] === C.tab);
  const keys = tab[2];
  const group = (k) => {
    if (k === 'fw') return slider('fw', 0.82, 1.22, 0.01, (v) => Math.round(v * 100) + '%');
    if (k === 'fh') return slider('fh', 0.82, 1.22, 0.01, (v) => Math.round(v * 100) + '%');
    if (SW[k]) return `<div class="mono lbl">${LABEL[k]}</div><div class="swatches">${SW[k].map((c, i) => `<button class="swatch" style="background:${c}" data-act="avset" data-k="${k}" data-v="${i}" aria-pressed="${C.p[k] === i}" aria-label="${LABEL[k]} ${i + 1}"></button>`).join('')}</div>`;
    return `<div class="mono lbl">${LABEL[k]}</div><div class="chips">${CAT[k].map(([id, name, min = 1]) => {
      const lock = L < min;
      return `<button class="chip ${lock ? 'locked' : ''}" data-act="avset" data-k="${k}" data-v="${id}" aria-pressed="${C.p[k] === id}" ${lock ? 'aria-disabled="true"' : ''}>${esc(name)}${lock ? ` · Lv${min}` : ''}</button>`;
    }).join('')}</div>`;
  };
  body.innerHTML = `<div class="avc">
<div class="avc-prev" id="avc-prev">${avatarSVG(C.p, { size: 220, full: true, yaw: C.yaw })}</div>
<div class="avc-ctl"><button class="ibtn" data-act="avrand" aria-label="Randomize">${ic(P.dice, 20, 1.9)}</button>
<input type="range" id="avc-yaw" min="-40" max="40" value="${C.yaw}" aria-label="Rotate"><button class="ibtn" data-act="avspin" aria-label="Auto rotate">${ic(P.spark, 20, 1.9)}</button></div>
<div class="chips scrollx">${TABS.map(([id, n]) => `<button class="chip" data-act="avtab" data-v="${id}" aria-pressed="${C.tab === id}">${n}</button>`).join('')}</div>
<div class="avc-opts">${keys.map(group).join('')}</div>
<div class="mono lbl">Level ${L} · naye items level badhne par unlock hote hain</div>
<button class="btn" data-act="avsave">Avatar save karo</button>
<div class="two"><button class="btn soft" data-act="avoutfit">Outfit ke naam se save</button><button class="btn soft" data-act="avreset">Reset</button></div>
${(S.me.avatars || []).length ? `<div class="mono lbl">SAVED OUTFITS</div><div class="outfits">${(S.me.avatars || []).map((o, i) => `<div class="outfit"><button class="avopt" data-act="avload" data-i="${i}" aria-label="${esc(o.name)}">${avatarSVG(o.p, { size: 64 })}</button><span>${esc(o.name)}</span><button class="xb" data-act="avdel" data-i="${i}" aria-label="Delete">${ic(P.x, 14, 2)}</button></div>`).join('')}</div>` : ''}
</div>`;
  const yaw = $('#avc-yaw');
  yaw.oninput = () => { C.yaw = Number(yaw.value); updPrev(); };
}
const updPrev = () => { const el = $('#avc-prev'); if (el) el.innerHTML = avatarSVG(C.p, { size: 220, full: true, yaw: C.yaw }); };

function randomize() {
  const L = lvl(), pick = (k) => { const ok = CAT[k].filter((o) => (o[2] || 1) <= L); return ok[Math.floor(Math.random() * ok.length)][0]; };
  const r = (n) => Math.floor(Math.random() * n);
  Object.keys(CAT).forEach((k) => { C.p[k] = pick(k); });
  ['skin', 'hairc', 'topc', 'pants', 'hatc', 'bg'].forEach((k) => { C.p[k] = r(SW[k].length); });
  C.p.face = FACE_KEYS[Math.floor(Math.random() * FACE_KEYS.length)];
  C.p.fw = 0.9 + Math.random() * 0.22;
  C.p.fh = 0.9 + Math.random() * 0.22;
  C.p.hat = Math.random() < 0.7 ? 'none' : C.p.hat;
}
function persistAvatar() {
  const av = { type: 'custom', p: { ...C.p } };
  saveMe({ avatar: av });
  window.dispatchEvent(new CustomEvent('nnn-avatar', { detail: av }));
  toast('Avatar save ho gaya');
}
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]');
  if (!b || !C || !$('#avc-prev')) return;
  const a = b.dataset.act;
  if (a === 'avtab') { C.tab = b.dataset.v; refreshSub(); }
  else if (a === 'avset') {
    if (b.getAttribute('aria-disabled') === 'true') return toast('Ye item abhi locked hai, XP kamao');
    const k = b.dataset.k, v = SW[k] ? Number(b.dataset.v) : b.dataset.v;
    C.p[k] = v; refreshSub();
  } else if (a === 'avrand') { randomize(); refreshSub(); }
  else if (a === 'avreset') { C.p = { ...DEFAULT_P }; C.yaw = 0; refreshSub(); }
  else if (a === 'avspin') {
    if (C.spin) return stopSpin();
    let d = 1; C.spin = setInterval(() => { if (!$('#avc-prev')) return stopSpin(); C.yaw += d * 4; if (Math.abs(C.yaw) >= 40) d = -d; const y = $('#avc-yaw'); if (y) y.value = C.yaw; updPrev(); }, 90);
  } else if (a === 'avsave') persistAvatar();
  else if (a === 'avoutfit') {
    const list = (S.me.avatars || []);
    if (list.length >= 6) return toast('Max 6 outfits, pehle ek hata do');
    const name = (prompt('Outfit ka naam?', 'Outfit ' + (list.length + 1)) || '').trim().slice(0, 16);
    if (!name) return;
    saveMe({ avatars: [...list, { name, p: { ...C.p } }] }); refreshSub();
  } else if (a === 'avload') { const o = (S.me.avatars || [])[Number(b.dataset.i)]; if (o) { C.p = { ...DEFAULT_P, ...o.p }; refreshSub(); } }
  else if (a === 'avdel') { saveMe({ avatars: (S.me.avatars || []).filter((_, i) => i !== Number(b.dataset.i)) }); refreshSub(); }
});

/* sliders: input event (range drag) */
document.addEventListener('input', (e) => {
  const b = e.target.closest && e.target.closest('[data-act="avslide"]');
  if (!b || !C) return;
  const k = b.dataset.k, v = Number(b.value);
  C.p[k] = v;
  const lbl = b.previousElementSibling && b.previousElementSibling.querySelector('.slval');
  if (lbl) lbl.textContent = Math.round(v * 100) + '%';
  updPrev();
});
