/* Peanut core: firebase, helpers, state, data layer, sheets, sub-screens, XP, i18n.
   Sab feature modules yahin se import karte hain. */
import { firebaseConfig } from './firebase-config.js';
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import {
  initializeFirestore, getFirestore, persistentLocalCache, persistentMultipleTabManager,
  doc, getDoc, setDoc, updateDoc, deleteDoc, addDoc, collection, query, orderBy, limit, where,
  onSnapshot, serverTimestamp, increment, arrayUnion, arrayRemove, runTransaction
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';

export {
  doc, getDoc, setDoc, updateDoc, deleteDoc, addDoc, collection, query, orderBy, limit, where,
  onSnapshot, serverTimestamp, increment, arrayUnion, arrayRemove, runTransaction
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
/* Offline cache: data phone pe cache hota hai, net aate hi sync ho jata hai */
export const db = (() => {
  try { return initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) }); }
  catch (e) { console.warn('persistent cache off', e); return getFirestore(app); }
})();

/* ================= helpers ================= */
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
export const pad = (n) => String(n).padStart(2, '0');
export const uid8 = () => Math.random().toString(36).slice(2, 10);
export const store = {
  get(k, d = null) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch { /* private mode */ } },
  json(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  setJson(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* ignore */ } }
};
export const ic = (d, s = 22, sw = 1.9) =>
  `<svg aria-hidden="true" viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
export const P = {
  cal: '<rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/><path d="m9 15 2 2 4-4"/>',
  calp: '<rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/>',
  board: '<rect x="3.5" y="11" width="4.5" height="9" rx="1.5"/><rect x="9.75" y="4" width="4.5" height="16" rx="1.5"/><rect x="16" y="14" width="4.5" height="6" rx="1.5"/>',
  chat: '<path d="M5 5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-7l-5 4v-4H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15L6 16Z"/><path d="M10 21a2 2 0 0 0 4 0"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  logout: '<path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3"/><path d="M16 8l4 4-4 4M20 12H9"/>',
  leave: '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3"/><path d="M10 8l-4 4 4 4M6 12h10"/>',
  camera: '<path d="M4 8h3l1.5-2h7L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13.5" r="3.5"/>',
  note: '<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
  next: '<path d="M5 5l9 7-9 7z"/><path d="M19 5v14"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="3"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="3"/>',
  home: '<path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/>',
  book: '<path d="M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h10"/>',
  users: '<circle cx="9" cy="9" r="3.5"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M16 5.5a3.5 3.5 0 0 1 0 7M18 14.5a6 6 0 0 1 3 5.5"/>',
  more: '<circle cx="5.5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="18.5" cy="12" r="1.6"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  edit: '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/>',
  trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  star: '<path d="m12 3.5 2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.8l6-.8z"/>',
  pin: '<path d="M9 4h6l-1 6 3 3H7l3-3z"/><path d="M12 13v7"/>',
  spark: '<path d="M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3 3M15 15l3 3M18 6l-3 3M9 15l-3 3"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>',
  lock: '<rect x="5" y="10.5" width="14" height="9.5" rx="3"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
  down: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  list: '<path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/>',
  timer: '<circle cx="12" cy="13" r="7.5"/><path d="M12 9v4l2.5 1.5M9.5 3h5"/>',
  flame: '<path d="M12 3c1 3.5 5 5.5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 .3 1.5 1 2 2 2-.5-3 0-5 1-8z"/>',
  chart: '<path d="M4 20V5M4 20h16"/><path d="m7.5 15 4-5 3 3 5-6"/>',
  game: '<rect x="3" y="7" width="18" height="11" rx="5"/><path d="M8 10.5v4M6 12.5h4"/><circle cx="16" cy="11.5" r=".9"/><circle cx="18" cy="13.5" r=".9"/>',
  smile: '<circle cx="12" cy="12" r="8.5"/><path d="M8.5 14a4 4 0 0 0 7 0"/><circle cx="9" cy="10" r=".8"/><circle cx="15" cy="10" r=".8"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
  play: '<path d="M7 4.5v15l12-7.5z"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2.5"/>',
  dice: '<rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="9" cy="9" r=".9"/><circle cx="15" cy="15" r=".9"/><circle cx="15" cy="9" r=".9"/><circle cx="9" cy="15" r=".9"/>'
};

/* ================= i18n (10 languages) ================= */
import { t as _t, getLang, setLang, applyLang, langPickerHTML, detectLang, LANGS } from './i18n.js';
export { getLang, setLang, applyLang, langPickerHTML, detectLang, LANGS };
export const tr = (k, fallback) => _t(k, fallback);

/* ================= dates ================= */
export const DAY = 864e5;
export const ymd = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
export const fromYmd = (s) => { const [y, m, d] = String(s).split('-').map(Number); return new Date(y, (m || 1) - 1, d || 1); };
export const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
export const addDaysY = (s, n) => ymd(addDays(fromYmd(s), n));
export const todayKey = () => ymd();
export const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };
export const daysBetween = (a, b) => Math.round((fromYmd(b) - fromYmd(a)) / DAY);
export const dt = (date, time) => { const d = fromYmd(date); if (time) { const [h, m] = time.split(':').map(Number); d.setHours(h || 0, m || 0, 0, 0); } return d.getTime(); };
export const fmtD = (s) => fromYmd(s).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
export const fmtDY = (s) => fromYmd(s).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
export const fmtDW = (s) => fromYmd(s).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
export const WD = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const nowHHMM = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
export const fmtTime = (t) => { const d = t && t.toDate ? t.toDate() : new Date(t || Date.now()); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
export const rel = (s) => {
  const n = daysBetween(todayKey(), s);
  return n === 0 ? 'Aaj' : n === 1 ? 'Kal' : n === -1 ? 'Kal tha' : n > 0 ? `${n} din baad` : `${-n} din pehle`;
};
export const fmtMin = (m) => { m = Math.round(m || 0); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60 ? pad(m % 60) + 'm' : ''}`.trim() : `${m}m`; };

/* Repeat wale events ki dates [from,to] ke beech */
export function occurrences(e, from, to) {
  const out = [];
  if (!e.date) return out;
  const rep = e.repeat || 'none';
  if (rep === 'none') { if (e.date >= from && e.date <= to) out.push(e.date); return out; }
  const start = fromYmd(e.date), end = fromYmd(to), lo = fromYmd(from);
  let cur = new Date(start), guard = 0;
  while (cur <= end && guard++ < 4000) {
    if (cur >= lo) out.push(ymd(cur));
    if (rep === 'daily') cur = addDays(cur, 1);
    else if (rep === 'weekly') cur = addDays(cur, 7);
    else if (rep === 'monthly') cur = monthStep(start, new Date(cur.getFullYear(), cur.getMonth() + 1, 1));
    else if (rep === 'yearly') cur = new Date(cur.getFullYear() + 1, start.getMonth(), start.getDate());
    else break;
  }
  return out;
}
function monthStep(start, approx) {
  /* approx se hatke seedha agle mahine ki wahi tareekh (month-end clamp ke saath) */
  const y = approx.getFullYear(), m = approx.getMonth();
  const last = new Date(y, m + 1, 0).getDate();
  return new Date(y, m, Math.min(start.getDate(), last));
}

/* ================= state ================= */
export const S = { user: null, me: null, room: null, code: null, members: [], msgs: [], tab: 0, unsubs: [], pending: null, mode: 'login', chatFirst: true };
export const D = { tasks: [], habits: [], events: [], notes: [], subjects: [], exams: [], sessions: [], scores: [] };
const COLS = Object.keys(D);
const isStudent = () => (S.me && S.me.mode) !== 'adult';
export { isStudent };

/* ================= toast / errors ================= */
let toastT;
export function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2800);
}
export function fail(e) {
  console.error(e);
  const c = (e && e.code) || '';
  const map = {
    'auth/invalid-credential': 'Email ya password galat hai',
    'auth/wrong-password': 'Email ya password galat hai',
    'auth/user-not-found': 'Is email ka account nahi hai, Sign up karo',
    'auth/email-already-in-use': 'Ye email pehle se registered hai, Login karo',
    'auth/weak-password': 'Password kam se kam 6 akshar ka rakho',
    'auth/invalid-email': 'Email sahi se likho',
    'auth/missing-password': 'Password daalo',
    'auth/too-many-requests': 'Bahut koshish ho gayi, thodi der baad try karo',
    'auth/network-request-failed': 'Internet check karo',
    'auth/operation-not-allowed': 'Firebase Console me Email/Password sign-in chalu karo',
    'auth/api-key-not-valid.-please-pass-a-valid-api-key.': 'API key galat hai, firebase-config.js check karo',
    'permission-denied': 'Permission nahi mili. firestore.rules publish kiye?',
    'unavailable': 'Server tak nahi pahuncha, internet check karo',
    'failed-precondition': 'Firestore database bani hai? Console me Create database karo'
  };
  toast(map[c] || ('Kuch gadbad hui' + (c ? ' (' + c + ')' : (e && e.message ? ': ' + String(e.message).slice(0, 100) : ''))));
}
export async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch { return false; }
}

/* ================= layers (back button support) ================= */
const layers = [];
let skipPop = 0, deferredPush = 0;
/* Programmatic close history.back() se hota hai (async). Uske pop hone tak naye push rok ke rakhte hain,
   warna naya layer galti se pop ho jata hai. */
export function pushLayer(id, close) {
  layers.push({ id, close });
  if (skipPop > 0) deferredPush++;
  else { try { history.pushState({ nnn: layers.length }, ''); } catch { /* ignore */ } }
}
export function popLayer() {
  const l = layers.pop(); if (!l) return;
  l.close();
  try { skipPop++; history.back(); } catch { skipPop = 0; }
}
window.addEventListener('popstate', () => {
  if (skipPop > 0) {
    skipPop--;
    if (skipPop === 0 && deferredPush > 0) { for (; deferredPush > 0; deferredPush--) { try { history.pushState({ nnn: 1 }, ''); } catch { /* ignore */ } } }
    return;
  }
  const l = layers.pop(); if (l) l.close();
});
export const topLayer = () => (layers.length ? layers[layers.length - 1].id : null);
export function openOv(id) {
  const el = $('#' + id); if (!el.classList.contains('hidden')) return;
  el.classList.remove('hidden');
  pushLayer(id, () => el.classList.add('hidden'));
}
export function closeOv(id) {
  const el = $('#' + id); if (el.classList.contains('hidden')) return;
  if (topLayer() === id) popLayer(); else el.classList.add('hidden');
}

/* ================= data layer (users/{uid}/{col}) ================= */
let dataUnsubs = [];
const dataListeners = new Set();
let emitT;
export const onData = (fn) => { dataListeners.add(fn); };
function emit() {
  clearTimeout(emitT);
  emitT = setTimeout(() => dataListeners.forEach((f) => { try { f(); } catch (e) { console.error(e); } }), 80);
}
export function startData(uid) {
  stopData();
  COLS.forEach((c) => {
    const q = query(collection(db, 'users', uid, c), limit(c === 'sessions' || c === 'notes' ? 400 : 600));
    dataUnsubs.push(onSnapshot(q, (snap) => {
      D[c] = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      emit();
    }, (e) => console.warn('data', c, e.code)));
  });
}
export function stopData() {
  dataUnsubs.forEach((u) => { try { u(); } catch { /* ignore */ } });
  dataUnsubs = [];
  COLS.forEach((c) => { D[c] = []; });
}
const clean = (o) => JSON.parse(JSON.stringify(o));
const ref = (c, id) => doc(db, 'users', S.user.uid, c, id);
/* Writes await nahi karte: offline me promise pending rehta hai, par local snapshot turant update ho jata hai */
export function add(c, o) {
  const r = doc(collection(db, 'users', S.user.uid, c));
  setDoc(r, { ...clean(o), createdAt: serverTimestamp() }).catch(fail);
  return r.id;
}
export function upd(c, id, patch) { updateDoc(ref(c, id), clean(patch)).catch(fail); }
export function updRaw(c, id, patch) { updateDoc(ref(c, id), patch).catch(fail); }
export function del(c, id) { deleteDoc(ref(c, id)).catch(fail); }
export function saveMe(patch) {
  Object.assign(S.me, patch);
  updateDoc(doc(db, 'users', S.user.uid), clean(patch)).catch(fail);
}
export const find = (c, id) => D[c].find((x) => x.id === id);

/* ================= XP / level ================= */
export const levelOf = (xp) => Math.floor(Math.sqrt(Math.max(0, xp || 0) / 40)) + 1;
export const xpForLevel = (l) => 40 * (l - 1) * (l - 1);
export function awardXP(n, why) {
  if (!S.user || !n) return;
  const before = levelOf(S.me.xp || 0);
  S.me.xp = (S.me.xp || 0) + n;
  updateDoc(doc(db, 'users', S.user.uid), { xp: increment(n) }).catch(() => {});
  const after = levelOf(S.me.xp);
  toast(after > before ? `Level ${after}! Naye avatar items unlock ho sakte hain` : `+${n} XP${why ? ' · ' + why : ''}`);
  dataListeners.forEach((f) => { try { f(); } catch { /* ignore */ } });
}

/* ================= sub-screens ================= */
const subStack = [];
function paintSub() {
  const el = $('#sub');
  if (!subStack.length) { el.classList.add('hidden'); $('#sub-body').innerHTML = ''; return; }
  const s = subStack[subStack.length - 1];
  el.classList.remove('hidden');
  $('#sub-title').textContent = s.title;
  $('#sub-actions').innerHTML = typeof s.actions === 'function' ? s.actions() : (s.actions || '');
  const body = $('#sub-body'), top = body.scrollTop;
  s.render(body);
  body.scrollTop = s.keepScroll ? top : 0;
  s.keepScroll = true;
}
export function openSub(title, render, actions = '', onClose = null) {
  subStack.push({ title, render, actions, keepScroll: false, onClose });
  pushLayer('sub', () => { const s = subStack.pop(); if (s && s.onClose) { try { s.onClose(); } catch (e) { console.warn(e); } } paintSub(); });
  paintSub();
}
export function refreshSub(force = false) {
  if (!subStack.length) return;
  const a = document.activeElement;
  if (!force && a && a.closest && a.closest('#sub-body') && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) return;
  paintSub();
}
export const subOpen = () => subStack.length > 0;
export const subTitle = () => (subStack.length ? subStack[subStack.length - 1].title : '');
export function closeAllSubs() { while (subStack.length) popLayer(); }
export const closeSub = () => { if (topLayer() === 'sub') popLayer(); };

/* ================= form sheet ================= */
let formState = null;
export function formSheet(cfg) {
  const { title, fields, values = {}, saveLabel = 'Save karo', onSave, onDelete, extraHtml = '' } = cfg;
  const body = fields.map((fd) => {
    const v = values[fd.k] ?? fd.d ?? '';
    const id = 'ff-' + fd.k;
    let inp;
    switch (fd.t) {
      case 'textarea':
        inp = `<textarea id="${id}" rows="${fd.rows || 3}" maxlength="${fd.max || 3000}" placeholder="${esc(fd.ph || '')}">${esc(v)}</textarea>`; break;
      case 'select':
        inp = `<select id="${id}">${fd.o.map(([ov, ol]) => `<option value="${esc(ov)}" ${String(ov) === String(v) ? 'selected' : ''}>${esc(ol)}</option>`).join('')}</select>`; break;
      case 'check':
        inp = `<button type="button" class="sw" role="switch" id="${id}" aria-checked="${!!v}" data-act="fswitch"><i></i></button>`; break;
      case 'chips': {
        const sel = new Set([].concat(v).map(String));
        inp = `<div class="chips" id="${id}" data-multi="${fd.multi ? 1 : 0}">${fd.o.map(([cv, cl]) =>
          `<button type="button" class="chip" data-act="fchip" data-v="${esc(cv)}" aria-pressed="${sel.has(String(cv))}">${esc(cl)}</button>`).join('')}</div>`;
        break;
      }
      default:
        inp = `<input id="${id}" type="${fd.t || 'text'}" value="${esc(v)}" maxlength="${fd.max || 80}" placeholder="${esc(fd.ph || '')}" ${fd.t === 'number' ? `inputmode="decimal" ${fd.min != null ? `min="${fd.min}"` : ''} ${fd.maxv != null ? `max="${fd.maxv}"` : ''}` : ''} ${fd.t === 'number' ? 'step="any"' : ''}>`;
    }
    return `<div class="field ${fd.t === 'check' ? 'inline' : ''}"><label class="mono lbl" for="${id}">${esc(fd.l)}</label>${inp}</div>`;
  }).join('');
  const box = $('#form-sheet');
  box.innerHTML = `<div class="grab"></div><h2 class="sh-h">${esc(title)}</h2>${extraHtml}${body}
    <button class="btn" type="submit">${esc(saveLabel)}</button>
    ${onDelete ? '<button class="btn danger" type="button" data-act="fdelete">Delete</button>' : ''}
    <button class="btn soft" type="button" data-act="fcancel">Cancel</button>`;
  formState = { fields, onSave, onDelete };
  if (!$('#ov-form').classList.contains('hidden')) { /* already open: sirf content badla */ return; }
  openOv('ov-form');
}
export function closeForm() { formState = null; closeOv('ov-form'); }
function readForm() {
  const out = {};
  for (const fd of formState.fields) {
    const el = $('#ff-' + fd.k, $('#form-sheet'));
    if (!el) continue;
    let v;
    if (fd.t === 'check') v = el.getAttribute('aria-checked') === 'true';
    else if (fd.t === 'chips') {
      const arr = $$('.chip[aria-pressed=true]', el).map((c) => (fd.num ? Number(c.dataset.v) : c.dataset.v));
      v = fd.multi ? arr : (arr[0] ?? (fd.num ? null : ''));
    } else if (fd.t === 'number') v = el.value === '' ? null : Number(el.value);
    else v = el.value.trim();
    if (fd.req && (v === '' || v === null || (Array.isArray(v) && !v.length))) { toast(`${fd.l} bharna zaroori hai`); el.focus && el.focus(); return null; }
    out[fd.k] = v;
  }
  return out;
}
document.addEventListener('submit', (e) => {
  if (e.target.id !== 'form-sheet') return;
  e.preventDefault();
  if (!formState) return;
  const v = readForm(); if (!v) return;
  const cb = formState.onSave;
  closeForm();
  cb && cb(v);
});
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]');
  if (!b) return;
  const a = b.dataset.act;
  if (a === 'fswitch') b.setAttribute('aria-checked', String(b.getAttribute('aria-checked') !== 'true'));
  else if (a === 'fchip') {
    const wrap = b.parentElement;
    if (wrap.dataset.multi === '1') b.setAttribute('aria-pressed', String(b.getAttribute('aria-pressed') !== 'true'));
    else $$('.chip', wrap).forEach((c) => c.setAttribute('aria-pressed', String(c === b)));
  } else if (a === 'fcancel') closeForm();
  else if (a === 'fdelete') {
    if (!formState || !confirm('Pakka delete karna hai?')) return;
    const cb = formState.onDelete; closeForm(); cb && cb();
  } else if (a === 'subback') closeSub();
});
document.addEventListener('click', (e) => {
  if (e.target.id === 'ov-form') closeForm();
});

/* ================= misc ui helpers ================= */
export const bar = (pct, h = 8) => `<div class="mbar" style="height:${h}px"><i style="width:${clamp(Math.round(pct), 0, 100)}%"></i></div>`;
/* Hero card with artwork — tabs ko sujana aur boring nahi dikhne deta hai */
export const heroArt = (src, kicker, title, sub) => `<div class="herocard sm">
  <img class="heroimg" src="${src}" alt="" loading="lazy" width="760" height="1018">
  <div class="heroin"><div class="mono lbl-d">${kicker}</div><h2>${title}</h2>${sub ? `<p>${sub}</p>` : ''}</div>
</div>`;
export const seg = (opts, cur, act) => `<div class="seg sm" role="group">${opts.map(([v, l]) => `<button type="button" data-act="${act}" data-v="${esc(v)}" aria-pressed="${String(v) === String(cur)}">${esc(l)}</button>`).join('')}</div>`;
export const emptyBox = (t) => `<div class="empty">${t}</div>`;
export const PRIO = { high: ['High', '#FF9A8A'], med: ['Medium', '#F2C94C'], low: ['Low', '#8FD19E'] };
export const dot = (c) => `<i class="cdot" style="background:${c}"></i>`;

export async function exportFile(name, mime, text) {
  try {
    const file = new File([text], name, { type: mime });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], title: name }); return true; }
  } catch (e) { if (e && e.name === 'AbortError') return false; }
  try {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: mime }));
    a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast('Download shuru: ' + name);
    return true;
  } catch { /* fall through */ }
  const ok = await copyText(text);
  toast(ok ? 'File ka text copy ho gaya' : 'Export nahi ho paya');
  return ok;
}
export function pickFile(accept) {
  return new Promise((res) => {
    const i = document.createElement('input');
    i.type = 'file'; i.accept = accept; i.style.display = 'none';
    i.onchange = () => { res(i.files[0] || null); i.remove(); };
    document.body.appendChild(i); i.click();
  });
}
export function loadScript(src) {
  return new Promise((res, rej) => {
    if (document.querySelector(`script[src="${src}"]`)) return res();
    const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('Load fail: ' + src));
    document.head.appendChild(s);
  });
}
