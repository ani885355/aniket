/* Searchable emoji picker: categories, recents, favorites */
import { $, $$, esc, store, openOv, closeOv } from './core.js';

const CATS = {
  'Smileys': '😀 grin|😂 laugh lol|🥹 touched|😊 smile happy|😍 love eyes|😎 cool|🤔 think|😴 sleep|😭 cry sad|😡 angry|🥳 party|🤯 mind blown|😅 sweat|🙃 upside|😇 angel|🤩 star struck|😬 awkward|🫡 salute|🥶 cold|🥵 hot',
  'People': '👍 like yes|👎 dislike no|👏 clap|🙌 hooray|🙏 pray thanks|💪 strong muscle|✌️ peace|🤞 luck|👋 wave hi|🤝 deal|🫶 heart hands|👀 eyes|🧠 brain|🫂 hug|👑 crown king',
  'Study': '📚 books study|📖 read|✏️ pencil write|📝 memo notes|🎓 graduate|🧮 abacus math|🔬 science|🧪 chemistry|🌍 geography|💻 laptop|📐 ruler geometry|🗓️ calendar|⏰ alarm|🏆 trophy|🥇 gold medal|🎯 target goal|📈 growth|✅ done check|💯 hundred|🧑‍🏫 teacher',
  'Life': '☕ coffee|🍵 tea|🍎 apple|🥗 salad|💧 water|🏃 run|🧘 yoga|🏋️ gym|🚴 cycle|😴 sleep|🛌 bed|🚿 shower|🧹 clean|💊 medicine|🏥 hospital|🎂 birthday cake|🎁 gift|💍 ring wedding|✈️ travel flight|🚗 car|🏠 home|💼 office work|💰 money|🧾 bill|📞 call|🎬 movie|🎵 music|🎮 game',
  'Nature': '🌱 sprout|🌿 leaf|🌸 flower|🌞 sun|🌙 moon|⭐ star|🔥 fire streak|⚡ lightning|🌈 rainbow|❄️ snow|🌊 wave|🐶 dog|🐱 cat|🥜 peanut|🦋 butterfly|🐼 panda',
  'Hearts': '❤️ red heart|🧡 orange|💛 yellow|💚 green|💙 blue|💜 purple|🖤 black|🤍 white|💔 broken|💖 sparkle heart|💯 hundred|✨ sparkles|🎉 tada party|🎊 confetti|🚀 rocket|💎 gem'
};
const ALL = Object.entries(CATS).flatMap(([c, s]) => s.split('|').map((x) => { const [e, ...k] = x.split(' '); return { e, k: k.join(' '), c }; }));
let cb = null, cat = 'Recent', q = '';
const rec = () => store.json('nnn_emo_r', []);
const fav = () => store.json('nnn_emo_f', []);

function paint() {
  const box = $('#emoji-sheet');
  let list;
  if (q) list = ALL.filter((x) => (x.k + ' ' + x.c).toLowerCase().includes(q.toLowerCase())).map((x) => x.e);
  else if (cat === 'Recent') list = rec();
  else if (cat === 'Fav') list = fav();
  else list = ALL.filter((x) => x.c === cat).map((x) => x.e);
  const tabs = ['Recent', 'Fav', ...Object.keys(CATS)];
  box.innerHTML = `<div class="grab"></div>
<input id="emo-q" class="emo-q" placeholder="Emoji khojo (love, study, fire...)" value="${esc(q)}" autocomplete="off">
<div class="chips scrollx">${tabs.map((t) => `<button class="chip" data-act="emocat" data-v="${t}" aria-pressed="${!q && cat === t}">${t === 'Fav' ? '★' : t}</button>`).join('')}</div>
<div class="emo-grid">${list.length ? list.map((e) => `<button class="emo" data-act="emopick" data-v="${esc(e)}">${e}</button>`).join('') : '<div class="empty">Yahan abhi kuch nahi. Emoji ko lamba dabao to favorite ban jayega.</div>'}</div>
<button class="btn soft" data-act="emoclose">Band karo</button>`;
  const inp = $('#emo-q'); inp.oninput = () => { q = inp.value; paintKeep(); };
}
function paintKeep() { const v = $('#emo-q'); const pos = v.selectionStart; paint(); const n = $('#emo-q'); n.focus(); n.setSelectionRange(pos, pos); }

export function pickEmoji(callback) {
  cb = callback; q = ''; cat = rec().length ? 'Recent' : 'Smileys';
  paint(); openOv('ov-emoji');
}
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act;
  if (a === 'emocat') { q = ''; cat = b.dataset.v; paint(); }
  else if (a === 'emopick') {
    const em = b.dataset.v;
    store.setJson('nnn_emo_r', [em, ...rec().filter((x) => x !== em)].slice(0, 24));
    closeOv('ov-emoji');
    const f = cb; cb = null; f && f(em);
  } else if (a === 'emoclose') closeOv('ov-emoji');
});
/* lamba dabao = favorite toggle */
let lp;
document.addEventListener('pointerdown', (e) => {
  const b = e.target.closest && e.target.closest('.emo'); if (!b) return;
  lp = setTimeout(() => {
    const em = b.dataset.v, f = fav();
    store.setJson('nnn_emo_f', f.includes(em) ? f.filter((x) => x !== em) : [em, ...f].slice(0, 40));
    b.dataset.act = 'x'; paint();
  }, 600);
});
['pointerup', 'pointerleave', 'pointercancel'].forEach((t) => document.addEventListener(t, () => clearTimeout(lp)));
