// Firebase web config (Console > Project settings > Your apps).
// Web API key secret nahi hota; asli suraksha firestore.rules se aati hai.
export const firebaseConfig = {
  apiKey: "AIzaSyBa66IF_n1jM8t08AKo6b3BRMJM5skG25s",
  authDomain: "no-nut-november-5b099.firebaseapp.com",
  projectId: "no-nut-november-5b099",
  storageBucket: "no-nut-november-5b099.firebasestorage.app",
  messagingSenderId: "16719743858",
  appId: "1:16719743858:web:3b1ac846d2c2435614ebeb",
  measurementId: "G-17GX0978XF"
};
