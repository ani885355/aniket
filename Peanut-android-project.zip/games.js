/* ============================================================
   games.js — Peanut games hub.

   9 games:
     2 Player (real-time, Firestore backed): Tic-Tac-Toe, Math Speed
     Battle, Rock-Paper-Scissors, Quiz Battle
     Solo (local): Memory Challenge, Daily Brain, 2048 Merge,
     Word Challenge, Reflex Test

   Multiplayer state Firestore ke games/{code} doc me rehta hai.
   Dhyan: result/turn client-side compute hote hain (rules sirf players
   + turn check karte hain). Fully server-validated scoring ke liye
   Cloud Functions chahiye.
   ============================================================ */
import {
  $, $$, esc, S, D, db, store, toast, ic, P, add, openSub, refreshSub, emptyBox, bar, todayKey, pad, awardXP, saveMe,
  doc, getDoc, setDoc, updateDoc, onSnapshot, runTransaction, serverTimestamp, increment, fail, copyText, find
} from './core.js';
import { avatarHTML } from './avatar.js';
import { focusActive } from './tasks.js';
import { t } from './i18n.js';

const CODE = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const mkCode = () => { const a = new Uint32Array(5); crypto.getRandomValues(a); return [...a].map((n) => CODE[n % CODE.length]).join(''); };
const gref = (c) => doc(db, 'games', c);
const me = () => S.user.uid;
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/* ================= catalogue ================= */
export const GAMES = [
  { id: 'ttt', n: 'gTtt', s: 'gTttSub', cat: '2p', icon: '✕', c1: '#C8F23A', c2: '#3E6B24', mp: true },
  { id: 'math', n: 'gMath', s: 'gMathSub', cat: '2p', icon: '∑', c1: '#8FB8DE', c2: '#2A4F73', mp: true },
  { id: 'rps', n: 'gRps', s: 'gRpsSub', cat: '2p', icon: '✊', c1: '#FF8FB1', c2: '#8C2F52', mp: true },
  { id: 'quiz', n: 'gQuiz', s: 'gQuizSub', cat: '2p', icon: '❓', c1: '#F2C94C', c2: '#8A6A12', mp: true },
  { id: 'memory', n: 'gMem', s: 'gMemSub', cat: 'solo', icon: '🧠', c1: '#B7A6E0', c2: '#4B3A78', mp: false },
  { id: 'brain', n: 'gBrain', s: 'gBrainSub', cat: 'solo', icon: '🧩', c1: '#9AD1B5', c2: '#2F5D48', mp: false },
  { id: 'merge', n: 'gMerge', s: 'gMergeSub', cat: 'solo', icon: '🔢', c1: '#E8B96F', c2: '#8A5A22', mp: false },
  { id: 'words', n: 'gWords', s: 'gWordsSub', cat: 'solo', icon: '🔤', c1: '#7FD1D1', c2: '#1E5E5E', mp: false },
  { id: 'reflex', n: 'gReflex', s: 'gReflexSub', cat: 'solo', icon: '⚡', c1: '#FF9F5A', c2: '#8C4212', mp: false }
];
const gMeta = (id) => GAMES.find((g) => g.id === id) || GAMES[0];

/* ================= best scores ================= */
const bestOf = (id) => (S.me.gameBest || {})[id];
async function saveBest(id, value, lowerIsBetter = false) {
  const gb = { ...(S.me.gameBest || {}) };
  const cur = gb[id];
  const better = cur === undefined || (lowerIsBetter ? value < cur : value > cur);
  if (!better) return false;
  gb[id] = value;
  saveMe({ gameBest: gb });
  if (S.code) updateDoc(doc(db, 'rooms', S.code, 'members', me()), { gameBest: gb }).catch(() => {});
  return true;
}
const bestLabel = (id) => {
  const v = bestOf(id); if (v === undefined) return '';
  if (id === 'reflex') return `${v} ms`;
  if (id === 'merge') return `${v}`;
  if (id === 'words') return `${v}`;
  return `${v}`;
};

/* ================= hub ================= */
let gFilter = 'all';
export function gamesHTML() {
  const list = gFilter === 'all' ? GAMES : GAMES.filter((g) => g.cat === gFilter);
  const last = store.json('nnn_game', null);
  const brainToday = D.scores.find((s) => s.kind === 'brain' && s.date === todayKey());
  const cat = (k, label, icon) => `<button class="chip" data-act="gfilter" data-v="${k}" aria-pressed="${gFilter === k}">${icon} ${label}</button>`;
  const cards = list.map((g) => {
    const b = g.id === 'brain' && brainToday ? `aaj: ${brainToday.score} pts` : (bestLabel(g.id) ? `best ${bestLabel(g.id)}` : t(g.s));
    return `<button class="gcard" data-act="gopen" data-v="${g.id}">
    <span class="gart" style="--g1:${g.c1};--g2:${g.c2}"><i>${g.icon}</i></span>
    <span class="gmeta"><b>${t(g.n)}</b><span class="mono">${esc(b)}</span>
    <span class="gtags"><i class="gtag${g.cat === '2p' ? ' two' : ''}">${g.cat === '2p' ? t('gameTwo') : t('gameSolo')}</i></span></span>
  </button>`;
  }).join('');
  const roomBest = S.members.filter((m) => m.gameBest && Object.keys(m.gameBest).length)
    .map((m) => ({ m, v: Math.max(...Object.values(m.gameBest).map(Number)) }))
    .sort((a, b) => b.v - a.v).slice(0, 5);
  return `${focusActive() ? `<div class="warnbox">${t('gameFocusWarn')}</div>` : ''}
<div class="ghero">
  <img src="assets/art/hero-games.webp" alt="" loading="lazy" width="760" height="1018">
  <div class="gheroin"><div class="mono lbl-d">${t('gameHub').toUpperCase()}</div><h2>${t('gameHubSub')}</h2><p>${t('gameHubText')}</p></div>
</div>
${last ? `<button class="btn soft" data-act="gcont" data-v="${last.type}" data-id="${last.code}">${t('gameContinue')} · ${esc(gMeta(last.type).n ? t(gMeta(last.type).n) : last.type)} · ${last.code}</button>` : ''}
<div class="chips scrollx">${cat('all', t('gameAll'), '🎮')}${cat('2p', t('gameTwo'), '👥')}${cat('solo', t('gameSolo'), '🧠')}</div>
<div class="ggrid">${cards}</div>
${roomBest.length ? `<div class="mono lbl">${t('gameRoomBest')}</div>${roomBest.map((x, i) => `<div class="row ${x.m.uid === me() ? 'me' : ''}"><div class="rk">${pad(i + 1)}</div>${avatarHTML(x.m.avatar, 36)}<div class="mid"><b>${esc(x.m.name)}</b></div><div class="pts">${x.v}</div></div>`).join('')}` : ''}`;
}

/* ================= multiplayer plumbing ================= */
let G = null; // {code,type,data,unsub}
function stopG() { if (G && G.unsub) G.unsub(); G = null; if (Mt) { clearInterval(Mt.t); Mt = null; } }
function lobby(type) {
  const gm = gMeta(type);
  openSub(t(gm.n), (body) => {
    body.innerHTML = `<div class="lime2"><div class="mono lbl-d">${t('gameNewGame')}</div><h2>${t('gameRoomSub')}</h2><p>${t('gameRoomText')}</p><button class="btn dark" data-act="gcreate" data-v="${type}">${t('gStartGame')}</button></div>
<form class="plain" id="gjoin"><div class="mono lbl">${t('gJoinCode')}</div><input id="gjoin-code" class="codein mono" maxlength="5" placeholder="ABCDE" autocapitalize="characters" autocomplete="off" aria-label="Game code"><button class="btn ghost" type="submit">${t('gJoin')}</button></form>`;
    $('#gjoin').onsubmit = (e) => { e.preventDefault(); joinGame(type, $('#gjoin-code').value.trim().toUpperCase()); };
  });
}
function baseDoc(type) {
  const base = { type, host: me(), players: [me()], names: { [me()]: S.me.name }, avs: { [me()]: S.me.avatar }, status: 'waiting', createdAt: serverTimestamp(), scores: {} };
  if (type === 'ttt') return { ...base, board: '---------', turn: me(), winner: '', round: 1, scores: { [me()]: 0 } };
  if (type === 'rps') return { ...base, picks: {}, round: 1, status: 'waiting', scores: { [me()]: 0 }, last: null };
  if (type === 'quiz') return { ...base, qs: quizPick(5), qi: 0, ans: {}, score: { [me()]: 0 }, status: 'waiting', last: null };
  return { ...base, seed: Math.floor(Math.random() * 1e9), startAt: 0, dur: 60, score: { [me()]: 0 }, done: {} };
}
async function createGame(type) {
  try {
    let code = mkCode();
    for (let i = 0; i < 5; i++) { if (!(await getDoc(gref(code))).exists()) break; code = mkCode(); }
    await setDoc(gref(code), baseDoc(type));
    enter(type, code);
    copyText(code).then((ok) => toast(ok ? `Code ${code} copy ho gaya` : `Code: ${code}`));
  } catch (e) { fail(e); }
}
async function joinGame(type, code) {
  if (!/^[A-Z0-9]{5}$/.test(code)) return toast('5 akshar ka code daalo');
  try {
    await runTransaction(db, async (tx) => {
      const s = await tx.get(gref(code));
      if (!s.exists()) throw Object.assign(new Error('nf'), { code: 'nf' });
      const d = s.data();
      if (d.type !== type) throw Object.assign(new Error('type'), { code: 'type' });
      if (d.players.includes(me())) return;
      if (d.players.length >= 2) throw Object.assign(new Error('full'), { code: 'full' });
      const patch = { players: [...d.players, me()], [`names.${me()}`]: S.me.name, [`avs.${me()}`]: S.me.avatar };
      if (type === 'ttt') { patch.status = 'playing'; patch[`scores.${me()}`] = 0; }
      else if (type === 'rps') { patch.status = 'playing'; patch[`scores.${me()}`] = 0; }
      else if (type === 'quiz') { patch.status = 'playing'; patch[`score.${me()}`] = 0; }
      else patch[`score.${me()}`] = 0;
      tx.update(gref(code), patch);
    });
    enter(type, code);
  } catch (e) { toast(e.code === 'nf' ? 'Ye code kisi game ka nahi' : e.code === 'full' ? 'Room full hai' : e.code === 'type' ? 'Ye code doosri game ka hai' : 'Join nahi hua'); if (!['nf', 'full', 'type'].includes(e.code)) fail(e); }
}
function enter(type, code) {
  store.setJson('nnn_game', { type, code });
  stopG();
  G = { code, type, data: null, unsub: null };
  const render = { ttt: renderTTT, math: renderMath, rps: renderRPS, quiz: renderQuiz }[type] || renderTTT;
  openSub(t(gMeta(type).n), render, '', () => stopG());
  G.unsub = onSnapshot(gref(code), (s) => {
    if (!s.exists()) { toast('Game khatam ho chuki hai'); store.set('nnn_game', ''); return; }
    G.data = s.data();
    const box = $('#sub-body');
    if (type === 'math' && $('#m-main')) paintMath();
    else if (box) render(box);
  }, (e) => fail(e));
}

/* ================= Tic-Tac-Toe ================= */
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
const sym = (d, uid) => (uid === d.host ? 'X' : 'O');
function renderTTT(body) {
  const d = G && G.data; if (!d) { body.innerHTML = emptyBox(t('loading')); return; }
  const [a, b] = d.players, mine = d.turn === me(), done = d.status === 'done';
  const who = (u) => u ? `<div class="gp ${d.turn === u && d.status === 'playing' ? 'turn' : ''}">${avatarHTML(d.avs[u], 44)}<b>${esc(d.names[u] || '...')}</b><span class="mono">${sym(d, u)} · ${(d.scores || {})[u] || 0}</span></div>` : `<div class="gp wait"><span class="mono">${t('comWaiting')}</span></div>`;
  const res = done ? (d.winner === 'draw' ? t('gDraw') : d.winner === me() ? t('gYouWon') : `${esc(d.names[d.winner])} ${t('gYouWon').replace('Tum jeet gaye!', 'jeet gaya')}`) : '';
  body.innerHTML = `<div class="mono lbl">${t('gRoomCode')} <button class="codechip" data-act="gcopy" data-id="${G.code}">${G.code}</button></div>
<div class="gps">${who(a)}${who(b)}</div>
<div class="status mono">${d.status === 'waiting' ? t('gameInviteCode') : done ? res : mine ? t('comYourTurn') : t('gameOpponentTurn')}</div>
<div class="ttt">${[...d.board].map((c, i) => `<button class="cell ${c !== '-' ? 'f' : ''}" data-act="tttmove" data-i="${i}" ${(c !== '-' || !mine || d.status !== 'playing') ? 'disabled' : ''} aria-label="Cell ${i + 1} ${c === '-' ? 'khaali' : c}">${c === '-' ? '' : c}</button>`).join('')}</div>
${done ? `<button class="btn" data-act="tttrematch">${t('btnRematch')}</button>` : ''}`;
  if (done && d.winner === me()) rewardOnce(`${G.code}:${d.round}`);
}
function rewardOnce(key) {
  if (store.get('nnn_gxp') === key) return;
  store.set('nnn_gxp', key);
  awardXP(15, 'game jeeta'); updateDoc(doc(db, 'users', me()), { gameWins: increment(1) }).catch(() => {}); S.me.gameWins = (S.me.gameWins || 0) + 1;
}
function winnerOf(board, d) {
  for (const [x, y, z] of LINES) if (board[x] !== '-' && board[x] === board[y] && board[y] === board[z]) return board[x];
  return board.includes('-') ? '' : 'draw';
}
async function tttMove(i) {
  try {
    await runTransaction(db, async (tx) => {
      const s = await tx.get(gref(G.code)), d = s.data();
      if (d.status !== 'playing' || d.turn !== me() || d.board[i] !== '-') return;
      const board = d.board.slice(0, i) + sym(d, me()) + d.board.slice(i + 1), w = winnerOf(board);
      const other = d.players.find((p) => p !== me());
      if (w === '') tx.update(gref(G.code), { board, turn: other });
      else { const winUid = w === 'draw' ? 'draw' : me(); const patch = { board, status: 'done', winner: winUid }; if (winUid !== 'draw') patch[`scores.${me()}`] = ((d.scores || {})[me()] || 0) + 1; tx.update(gref(G.code), patch); }
    });
  } catch (e) { fail(e); }
}
async function tttRematch() {
  try {
    await runTransaction(db, async (tx) => {
      const d = (await tx.get(gref(G.code))).data(); if (d.status !== 'done') return;
      const first = d.players[(d.round) % 2] || d.host;
      tx.update(gref(G.code), { board: '---------', status: 'playing', winner: '', turn: first, round: d.round + 1 });
    });
  } catch (e) { fail(e); }
}

/* ================= Math Speed Battle ================= */
let Mt = null;
function mathQ(seed, i) {
  const r = rng(seed + i * 977), lvl = Math.min(3, Math.floor(i / 5));
  const n = (a, b) => a + Math.floor(r() * (b - a + 1));
  const kind = n(0, 2 + (lvl > 0 ? 1 : 0));
  if (kind === 0) { const a = n(2, 20 + lvl * 30), b = n(2, 20 + lvl * 30); return { q: `${a} + ${b}`, a: a + b }; }
  if (kind === 1) { const a = n(10, 40 + lvl * 40), b = n(2, a); return { q: `${a} − ${b}`, a: a - b }; }
  if (kind === 2) { const a = n(2, 9 + lvl * 3), b = n(2, 9 + lvl * 2); return { q: `${a} × ${b}`, a: a * b }; }
  const b = n(2, 9), a = b * n(2, 12); return { q: `${a} ÷ ${b}`, a: a / b };
}
function renderMath(body) {
  const d = G && G.data; if (!d) { body.innerHTML = emptyBox(t('loading')); return; }
  body.innerHTML = `<div class="mono lbl">${t('gRoomCode')} <button class="codechip" data-act="gcopy" data-id="${G.code}">${G.code}</button></div>
<div class="gps" id="m-ps"></div><div id="m-main"></div>`;
  paintMath();
}
function paintMath() {
  const d = G && G.data, box = $('#m-main'); if (!d || !box) return;
  $('#m-ps').innerHTML = d.players.map((u) => `<div class="gp"><span id="ms-${u}"></span>${avatarHTML(d.avs[u], 44)}<b>${esc(d.names[u])}</b><span class="mono">${(d.score || {})[u] || 0} pts</span></div>`).join('') + (d.players.length < 2 ? `<div class="gp wait"><span class="mono">${t('comWaiting')}</span></div>` : '');
  const both = d.players.length === 2;
  if (d.status === 'waiting') {
    box.innerHTML = both ? (d.host === me() ? `<button class="btn" data-act="mstart">${t('gameStartIn')}</button>` : `<div class="status mono">${t('gameHostStart')}</div>`) : `<div class="status mono">${t('gameInviteCode')}</div>`;
    return;
  }
  const end = d.startAt + d.dur * 1000;
  if (d.done && d.done[me()]) return showMathResult(d, box);
  if (!Mt || Mt.start !== d.startAt) {
    Mt = { start: d.startAt, i: 0, score: 0, t: setInterval(mathTick, 200) };
    box.innerHTML = `<div class="mathbox"><div class="cd2 mono" id="m-cd"></div><div class="mq" id="m-q"></div><form id="m-f"><input id="m-in" inputmode="numeric" autocomplete="off" placeholder="${t('gAnswer')}" aria-label="${t('gAnswer')}"><button class="send" type="submit" aria-label="${t('gSubmit')}">${ic(P.arrow, 22, 2.2)}</button></form><div id="m-bar"></div></div>`;
    $('#m-f').onsubmit = (e) => { e.preventDefault(); mathAnswer(); };
  }
  mathTick(); if (Date.now() >= end) finishMath();
}
function mathTick() {
  const d = G && G.data; if (!d || !Mt) return;
  const now = Date.now(), end = d.startAt + d.dur * 1000, cd = $('#m-cd'); if (!cd) return;
  if (now < d.startAt) { cd.textContent = Math.ceil((d.startAt - now) / 1000); $('#m-q').textContent = t('gameGetReady'); $('#m-in').disabled = true; return; }
  const left = Math.max(0, end - now);
  cd.textContent = Math.ceil(left / 1000) + 's'; $('#m-bar').innerHTML = bar(left / (d.dur * 1000) * 100, 8);
  const inp = $('#m-in'); if (inp.disabled) { inp.disabled = false; inp.focus(); }
  $('#m-q').textContent = mathQ(d.seed, Mt.i).q + ' = ?';
  if (left <= 0) finishMath();
}
function mathAnswer() {
  const d = G.data, inp = $('#m-in'), v = inp.value.trim(); if (!v || Date.now() < d.startAt || Date.now() >= d.startAt + d.dur * 1000) return;
  const ok = Number(v) === mathQ(d.seed, Mt.i).a; inp.value = '';
  if (ok) { Mt.score += 10; updateDoc(gref(G.code), { [`score.${me()}`]: Mt.score }).catch(() => {}); }
  Mt.i++; mathTick();
}
function finishMath() {
  if (!Mt || Mt.fin) return; Mt.fin = true; clearInterval(Mt.t);
  updateDoc(gref(G.code), { [`score.${me()}`]: Mt.score, [`done.${me()}`]: true }).catch(() => {});
}
function showMathResult(d, box) {
  const [a, b] = d.players, sa = (d.score || {})[a] || 0, sb = (d.score || {})[b] || 0, all = d.players.length === 2 && d.done[a] && d.done[b];
  const w = sa === sb ? 'draw' : sa > sb ? a : b;
  box.innerHTML = `<div class="lime2"><div class="mono lbl-d">${all ? t('gResult') : t('gameWaitingResult')}</div><h2>${!all ? t('gameOpponentResult') : w === 'draw' ? t('gDraw') : w === me() ? t('gYouWon') : esc(d.names[w]) + ' ' + t('gYouLost')}</h2><p>${sa} – ${sb}</p></div>
${all ? `<button class="btn" data-act="mrematch">${t('btnRematch')}</button>` : ''}`;
  if (all && w === me()) rewardOnce(`${G.code}:${d.startAt}`);
}
async function mathStart() { try { await updateDoc(gref(G.code), { status: 'playing', startAt: Date.now() + 4000 }); } catch (e) { fail(e); } }
async function mathRematch() {
  try {
    Mt && clearInterval(Mt.t); Mt = null;
    const d = G.data, sc = {}; d.players.forEach((p) => { sc[p] = 0; });
    await updateDoc(gref(G.code), { status: 'playing', startAt: Date.now() + 4000, seed: Math.floor(Math.random() * 1e9), score: sc, done: {} });
  } catch (e) { fail(e); }
}

/* ================= Rock-Paper-Scissors ================= */
const RPS = { rock: '✊', paper: '✋', scissors: '✌️' };
const rpsWin = (a, b) => (a === b ? 'draw' : (a === 'rock' && b === 'scissors') || (a === 'paper' && b === 'rock') || (a === 'scissors' && b === 'paper') ? 'win' : 'lose');
function renderRPS(body) {
  const d = G && G.data; if (!d) { body.innerHTML = emptyBox(t('loading')); return; }
  const [a, b] = d.players, mine = me(), myPick = (d.picks || {})[mine];
  const op = d.players.find((p) => p !== mine);
  const opPick = (d.picks || {})[op];
  const both = myPick && opPick;
  const last = d.last;
  let res = '';
  if (last) {
    const mineWon = last.winner === mine, draw = last.winner === 'draw';
    res = `<div class="lime2"><div class="mono lbl-d">${t('gResult')}</div><h2>${draw ? t('gDraw') : mineWon ? t('gYouWon') : t('gYouLost')}</h2><p>${RPS[last.a]} vs ${RPS[last.b]} · ${(d.scores || {})[a] || 0} – ${(d.scores || {})[b] || 0}</p></div>`;
  }
  body.innerHTML = `<div class="mono lbl">${t('gRoomCode')} <button class="codechip" data-act="gcopy" data-id="${G.code}">${G.code}</button></div>
<div class="gps">${d.players.map((u) => `<div class="gp ${opPick ? 'turn' : ''}">${avatarHTML(d.avs[u], 44)}<b>${esc(d.names[u])}</b><span class="mono">${(d.scores || {})[u] || 0} pts${(d.picks || {})[u] ? ' · ' + RPS[(d.picks || {})[u]] : ''}</span></div>`).join('')}</div>
${d.players.length < 2 ? `<div class="status mono">${t('gameInviteCode')}</div>` : ''}
${res}
${d.status === 'done' ? `<button class="btn" data-act="rpsrematch">${t('btnRematch')}</button>` : `<div class="rpspick">
${Object.entries(RPS).map(([k, e]) => `<button class="rpsbtn ${myPick === k ? 'on' : ''}" data-act="rpspick" data-v="${k}" ${myPick ? 'disabled' : ''}><i>${e}</i><span>${k}</span></button>`).join('')}
</div>${myPick ? `<div class="status mono">${t('gameWaitingOpponent')}</div>` : `<div class="status mono">${t('gamePickOne')}</div>`}`}`;
  if (d.status === 'done') { const w = d.winner; if (w === mine) rewardOnce(`${G.code}:rps:${d.round}`); }
}
async function rpsPick(k) {
  try {
    await runTransaction(db, async (tx) => {
      const d = (await tx.get(gref(G.code))).data();
      if (d.status !== 'playing' || (d.picks || {})[me()]) return;
      const picks = { ...(d.picks || {}), [me()]: k };
      const other = d.players.find((p) => p !== me());
      if (!picks[other]) { tx.update(gref(G.code), { picks }); return; }
      const r = rpsWin(picks[me()], picks[other]);
      const winUid = r === 'draw' ? 'draw' : r === 'win' ? me() : other;
      const scores = { ...(d.scores || {}) };
      if (winUid !== 'draw') scores[winUid] = (scores[winUid] || 0) + 1;
      const done = scores[me()] >= 3 || scores[other] >= 3;
      const patch = { picks: {}, last: { a: picks[me()], b: picks[other], winner: winUid }, scores, round: (d.round || 1) + 1 };
      if (done) { patch.status = 'done'; patch.winner = winUid; }
      tx.update(gref(G.code), patch);
    });
  } catch (e) { fail(e); }
}
async function rpsRematch() {
  try {
    await runTransaction(db, async (tx) => {
      const d = (await tx.get(gref(G.code))).data();
      const sc = {}; d.players.forEach((p) => { sc[p] = 0; });
      tx.update(gref(G.code), { picks: {}, last: null, scores: sc, round: 1, status: 'playing', winner: '' });
    });
  } catch (e) { fail(e); }
}

/* ================= Quiz Battle ================= */
const QUIZ_BANK = [
  { q: 'What is the capital of France?', o: ['Lyon', 'Paris', 'Nice', 'Marseille'], a: 1 },
  { q: 'How many continents are there?', o: ['5', '6', '7', '8'], a: 2 },
  { q: 'Who wrote "Romeo and Juliet"?', o: ['Dickens', 'Shakespeare', 'Twain', 'Austen'], a: 1 },
  { q: 'What is the chemical symbol for gold?', o: ['Ag', 'Au', 'Gd', 'Go'], a: 1 },
  { q: 'How many minutes are in a full day?', o: ['1200', '1440', '2400', '3600'], a: 1 },
  { q: 'Which planet is known as the Red Planet?', o: ['Venus', 'Mars', 'Jupiter', 'Mercury'], a: 1 },
  { q: 'What is 15 percent of 200?', o: ['20', '25', '30', '35'], a: 2 },
  { q: 'Which is the largest ocean?', o: ['Atlantic', 'Indian', 'Pacific', 'Arctic'], a: 2 },
  { q: 'How many bones are in the human body?', o: ['186', '206', '226', '246'], a: 1 },
  { q: 'What is the square root of 144?', o: ['10', '11', '12', '14'], a: 2 },
  { q: 'Which gas do plants absorb?', o: ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Hydrogen'], a: 2 },
  { q: 'What is the currency of Japan?', o: ['Won', 'Yuan', 'Yen', 'Ringgit'], a: 2 },
  { q: 'How many days are in a leap year?', o: ['364', '365', '366', '367'], a: 2 },
  { q: 'Who painted the Mona Lisa?', o: ['Van Gogh', 'Picasso', 'Da Vinci', 'Monet'], a: 2 },
  { q: 'What is the hardest natural substance?', o: ['Gold', 'Iron', 'Diamond', 'Quartz'], a: 2 },
  { q: 'How many colours are in a rainbow?', o: ['5', '6', '7', '8'], a: 2 },
  { q: 'What is H2O commonly known as?', o: ['Salt', 'Water', 'Sugar', 'Oxygen'], a: 1 },
  { q: 'Which country has the most people?', o: ['India', 'USA', 'China', 'Indonesia'], a: 2 },
  { q: 'What is the largest mammal?', o: ['Elephant', 'Blue whale', 'Giraffe', 'Hippo'], a: 1 },
  { q: 'How many sides does a hexagon have?', o: ['5', '6', '7', '8'], a: 1 },
  { q: 'What is the freezing point of water in Celsius?', o: ['-10', '0', '10', '32'], a: 1 },
  { q: 'Who was the first person on the moon?', o: ['Buzz Aldrin', 'Neil Armstrong', 'Yuri Gagarin', 'John Glenn'], a: 1 },
  { q: 'What is the smallest prime number?', o: ['0', '1', '2', '3'], a: 2 },
  { q: 'Which organ pumps blood in the body?', o: ['Liver', 'Heart', 'Lungs', 'Kidney'], a: 1 },
  { q: 'How many strings does a standard guitar have?', o: ['4', '5', '6', '7'], a: 2 },
  { q: 'What is the capital of Japan?', o: ['Osaka', 'Kyoto', 'Tokyo', 'Nagoya'], a: 2 },
  { q: 'How many zeros are in one lakh?', o: ['3', '4', '5', '6'], a: 2 },
  { q: 'Which blood type is the universal donor?', o: ['AB+', 'O-', 'A+', 'B-'], a: 1 },
  { q: 'What is the speed of light?', o: ['300 km/s', '3000 km/s', '300000 km/s', '3000000 km/s'], a: 2 },
  { q: 'How many players are on the field per soccer team?', o: ['9', '10', '11', '12'], a: 2 },
  { q: 'Which metal is liquid at room temperature?', o: ['Sodium', 'Mercury', 'Lead', 'Tin'], a: 1 },
  { q: 'What is the largest desert on Earth?', o: ['Sahara', 'Gobi', 'Antarctic', 'Arabian'], a: 2 },
  { q: 'How many letters are in the English alphabet?', o: ['24', '25', '26', '27'], a: 2 },
  { q: 'Which sea creature has three hearts?', o: ['Dolphin', 'Octopus', 'Shark', 'Jellyfish'], a: 1 },
  { q: 'What is 7 x 8?', o: ['54', '56', '58', '60'], a: 1 },
  { q: 'Who invented the telephone?', o: ['Tesla', 'Edison', 'Bell', 'Franklin'], a: 2 },
  { q: 'How many centuries are in a millennium?', o: ['5', '10', '20', '100'], a: 1 },
  { q: 'What is the capital of India?', o: ['Mumbai', 'New Delhi', 'Bengaluru', 'Chennai'], a: 1 },
  { q: 'How many teeth does an adult human have?', o: ['28', '30', '32', '36'], a: 2 },
  { q: 'Which shape has no corners?', o: ['Square', 'Circle', 'Triangle', 'Rectangle'], a: 1 },
  { q: 'What is the hottest planet in the solar system?', o: ['Mercury', 'Venus', 'Mars', 'Jupiter'], a: 1 }
];
function quizPick(n) {
  const r = rng(Math.floor(Math.random() * 1e9)), idx = [...QUIZ_BANK.keys()].sort(() => r() - 0.5).slice(0, n);
  return idx.map((i) => QUIZ_BANK[i]);
}
function renderQuiz(body) {
  const d = G && G.data; if (!d) { body.innerHTML = emptyBox(t('loading')); return; }
  const [a, b] = d.players, q = (d.qs || [])[d.qi || 0];
  const myAns = (d.ans || {})[me()];
  const op = d.players.find((p) => p !== me());
  const opAns = (d.ans || {})[op];
  const reveal = d.last && d.last.qi === d.qi;
  body.innerHTML = `<div class="mono lbl">${t('gRoomCode')} <button class="codechip" data-act="gcopy" data-id="${G.code}">${G.code}</button></div>
<div class="gps">${d.players.map((u) => `<div class="gp">${avatarHTML(d.avs[u], 44)}<b>${esc(d.names[u])}</b><span class="mono">${(d.score || {})[u] || 0} pts${(d.ans || {})[u] !== undefined ? ' ✓' : ''}</span></div>`).join('')}</div>
<div class="quizhead"><span class="mono lbl">${t('gameQuestion')} ${(d.qi || 0) + 1}/${(d.qs || []).length}</span><span class="mono">${t('gScore')}: ${(d.score || {})[me()] || 0}</span></div>
<div class="mq sm">${esc(q ? q.q : '')}</div>
<div class="opts">${(q ? q.o : []).map((o, i) => {
    const chosen = myAns === i, right = reveal && q.a === i;
    const cls = reveal ? (right ? 'right' : (chosen ? 'wrong' : '')) : (chosen ? 'on' : '');
    return `<button class="btn soft qopt ${cls}" data-act="qans" data-v="${i}" ${myAns !== undefined || reveal ? 'disabled' : ''}>${esc(o)}</button>`;
  }).join('')}</div>
${reveal ? `<div class="lime2"><div class="mono lbl-d">${t('gResult')}</div><h2>${q.o[q.a]}</h2><p>${t('gameCorrect')} · ${t('gScore')}: ${(d.score || {})[a] || 0} – ${(d.score || {})[b] || 0}</p></div>
<button class="btn" data-act="qnext">${t('gameNextQuestion')}</button>` : `<div class="status mono">${myAns !== undefined ? t('gameWaitingOpponent') : t('gamePickAnswer')}</div>`}`;
}
async function qAns(i) {
  try {
    await runTransaction(db, async (tx) => {
      const d = (await tx.get(gref(G.code))).data();
      if (d.status !== 'playing' || (d.ans || {})[me()] !== undefined || d.last) return;
      const q = d.qs[d.qi || 0];
      const ans = { ...(d.ans || {}), [me()]: i };
      const score = { ...(d.score || {}) };
      if (i === q.a) score[me()] = (score[me()] || 0) + 10;
      const op = d.players.find((p) => p !== me());
      const patch = { ans, score };
      if (ans[op] !== undefined) patch.last = { qi: d.qi || 0, a: q.a };
      tx.update(gref(G.code), patch);
    });
  } catch (e) { fail(e); }
}
async function qNext() {
  try {
    await runTransaction(db, async (tx) => {
      const d = (await tx.get(gref(G.code))).data();
      if (!d.last || d.last.qi !== (d.qi || 0)) return;
      const ni = (d.qi || 0) + 1;
      if (ni >= (d.qs || []).length) {
        const [a, b] = d.players, sa = (d.score || {})[a] || 0, sb = (d.score || {})[b] || 0;
        tx.update(gref(G.code), { status: 'done', winner: sa === sb ? 'draw' : sa > sb ? a : b });
      } else tx.update(gref(G.code), { qi: ni, ans: {}, last: null });
    });
  } catch (e) { fail(e); }
}

/* ================= Memory Challenge (solo) ================= */
const MEM = { easy: [4, 'Easy'], med: [6, 'Medium'], hard: [9, 'Hard'] };
let MM = null;
export function openMemory() {
  MM = { diff: 'easy', seq: [], inp: 0, phase: 'idle', lvl: 0, lit: -1 };
  openSub(t('gMem'), renderMemory, '', () => { if (MM) { MM.dead = true; } MM = null; });
}
function renderMemory(body) {
  if (!MM) return;
  const n = MEM[MM.diff][0], best = bestOf('memory_' + MM.diff) || 0;
  const mates = S.members.filter((m) => m.gameBest && m.gameBest['memory_' + MM.diff]).sort((a, b) => b.gameBest['memory_' + MM.diff] - a.gameBest['memory_' + MM.diff]).slice(0, 4);
  body.innerHTML = `<div class="chips">${Object.entries(MEM).map(([k, v]) => `<button class="chip" data-act="mdiff" data-v="${k}" aria-pressed="${MM.diff === k}" ${MM.phase !== 'idle' ? 'disabled' : ''}>${v[1]}</button>`).join('')}</div>
<div class="status mono">${MM.phase === 'idle' ? `${t('gBest')}: ${best} · ${t('gMemSub')}` : MM.phase === 'show' ? t('gameLook') : MM.phase === 'in' ? `${t('gameRepeat')} (${MM.inp}/${MM.seq.length})` : t('gameOver')}</div>
<div class="mem m${n}">${Array.from({ length: n }, (_, i) => `<button class="mpad p${i % 9} ${MM.lit === i ? 'lit' : ''}" data-act="mpad" data-i="${i}" ${MM.phase !== 'in' ? 'disabled' : ''} aria-label="Pad ${i + 1}"></button>`).join('')}</div>
<div class="mono lbl">${t('gLevel')} ${MM.lvl}</div>${MM.phase === 'idle' || MM.phase === 'over' ? `<button class="btn" data-act="mstartm">${MM.phase === 'over' ? t('btnStart') : t('btnStart')}</button>` : ''}
${mates.length ? `<div class="mono lbl">${t('gameRoomBest')} · ${MEM[MM.diff][1]}</div>${mates.map((m) => `<div class="plrow"><b>${esc(m.name)}</b><em class="mono">${m.gameBest['memory_' + MM.diff]}</em></div>`).join('')}` : ''}`;
}
async function memRound() {
  if (!MM) return; const n = MEM[MM.diff][0];
  MM.seq.push(Math.floor(Math.random() * n)); MM.phase = 'show'; MM.inp = 0; MM.lvl = MM.seq.length; refreshSub();
  await new Promise((r) => setTimeout(r, 600));
  for (const i of [...MM.seq]) { if (!MM || MM.dead) return; MM.lit = i; refreshSub(); await new Promise((r) => setTimeout(r, 480)); if (!MM || MM.dead) return; MM.lit = -1; refreshSub(); await new Promise((r) => setTimeout(r, 220)); }
  if (MM && !MM.dead) { MM.phase = 'in'; refreshSub(); }
}
function memPad(i) {
  if (!MM || MM.phase !== 'in') return;
  if (MM.seq[MM.inp] !== i) {
    MM.phase = 'over'; const score = MM.seq.length - 1;
    saveBest('memory_' + MM.diff, score).then((ok) => { if (ok) toast(`${t('gBest')}: ${score}`); });
    if (score >= 3) awardXP(Math.min(15, score * 2), 'memory');
    MM.seq = []; refreshSub(); return;
  }
  MM.inp++; if (MM.inp >= MM.seq.length) setTimeout(memRound, 400);
  refreshSub();
}

/* ================= Daily Brain ================= */
let BR = null;
function brainQs(dateKey) {
  const seed = dateKey.split('-').reduce((a, x) => a * 31 + Number(x), 7), r = rng(seed), n = (a, b) => a + Math.floor(r() * (b - a + 1));
  const opts = (ans) => { const s = new Set([ans]); while (s.size < 4) s.add(ans + n(-9, 9) || ans + 11); return [...s].sort(() => r() - 0.5); };
  const qs = [];
  { const a = n(2, 20), d = n(2, 9), ans = a + 4 * d; qs.push({ q: `${a}, ${a + d}, ${a + 2 * d}, ${a + 3 * d}, ?`, ans, o: opts(ans) }); }
  { const a = n(2, 4), k = n(2, 3), ans = a * k ** 4; qs.push({ q: `${a}, ${a * k}, ${a * k ** 2}, ${a * k ** 3}, ?`, ans, o: opts(ans) }); }
  { const a = n(3, 12), b = n(3, 12), c = n(1, 30), ans = a * b + c; qs.push({ q: `${a} × ${b} + ${c} = ?`, ans, o: opts(ans) }); }
  { const k = n(3, 9), ms = [n(2, 9), n(10, 15), n(2, 15)].map((x) => x * k), odd = ms[0] + 1 + (k > 3 ? 0 : 1); const all = [...ms, odd].sort(() => r() - 0.5); qs.push({ q: `Kaun sa ${k} ka multiple nahi hai? ${all.join(', ')}`, ans: odd, o: all }); }
  { const a = n(20, 90), c = a + n(10, 70); qs.push({ q: `${a} + ? = ${c}`, ans: c - a, o: opts(c - a) }); }
  return qs;
}
export function openBrain() {
  const done = D.scores.find((s) => s.kind === 'brain' && s.date === todayKey());
  BR = { qs: brainQs(todayKey()), i: 0, score: 0, left: 20, done: done ? done.score : null };
  openSub(t('gBrain'), renderBrain, '', () => { if (BR) clearInterval(BR.t); BR = null; });
  if (!done) brainTimer();
}
function brainTimer() { clearInterval(BR.t); BR.left = 20; BR.t = setInterval(() => { if (!BR) return; BR.left--; if (BR.left <= 0) brainAnswer(null); else { const e = $('#br-bar'); if (e) e.innerHTML = bar(BR.left / 20 * 100, 8); } }, 1000); }
function renderBrain(body) {
  if (!BR) return;
  if (BR.done !== null) {
    const top = S.members.filter((m) => m.brain && m.brain.date === todayKey()).sort((a, b) => b.brain.score - a.brain.score);
    body.innerHTML = `<div class="lime2"><div class="mono lbl-d">${t('gameTodayScore')}</div><h2>${BR.done} / 150</h2><p>${t('gameNewTomorrow')}</p></div>${top.length ? top.map((m, i) => `<div class="row ${m.uid === me() ? 'me' : ''}"><div class="rk">${pad(i + 1)}</div>${avatarHTML(m.avatar, 36)}<div class="mid"><b>${esc(m.name)}</b></div><div class="pts">${m.brain.score}</div></div>`).join('') : ''}`;
    return;
  }
  const q = BR.qs[BR.i];
  body.innerHTML = `<div class="mono lbl">${t('gameQuestion')} ${BR.i + 1}/5 · ${BR.score} pts</div><div id="br-bar">${bar(BR.left / 20 * 100, 8)}</div><div class="mq sm">${esc(q.q)}</div>
<div class="opts">${q.o.map((o) => `<button class="btn soft" data-act="bans" data-v="${o}">${o}</button>`).join('')}</div>`;
}
function brainAnswer(v) {
  if (!BR || BR.done !== null) return;
  const q = BR.qs[BR.i];
  if (v !== null && Number(v) === q.ans) BR.score += 20 + BR.left;
  BR.i++;
  if (BR.i >= 5) {
    clearInterval(BR.t); BR.done = BR.score;
    add('scores', { kind: 'brain', date: todayKey(), score: BR.score });
    if (S.code) updateDoc(doc(db, 'rooms', S.code, 'members', me()), { brain: { date: todayKey(), score: BR.score } }).catch(() => {});
    awardXP(10, 'daily brain');
    saveBest('brain', BR.score);
  } else brainTimer();
  refreshSub();
}

/* ================= 2048 Merge (solo) ================= */
let MG = null;
const M4 = 4;
const mkTile = () => Math.random() < 0.9 ? 2 : 4;
export function openMerge() {
  MG = { g: Array.from({ length: M4 * M4 }, () => 0), score: 0, over: false, won: false, anim: 0 };
  addTile(MG); addTile(MG);
  openSub(t('gMerge'), renderMerge, '', () => { MG = null; });
  renderMerge($('#sub-body'));
}
function addTile(st) {
  const free = st.g.map((v, i) => v === 0 ? i : -1).filter((i) => i >= 0);
  if (!free.length) return;
  st.g[free[Math.floor(Math.random() * free.length)]] = mkTile();
}
function renderMerge(body) {
  if (!MG) return;
  const best = bestOf('merge') || 0;
  const cells = MG.g.map((v, i) => `<div class="mcell ${v ? 'v' + Math.min(v, 4096) : ''}">${v || ''}</div>`).join('');
  body.innerHTML = `<div class="mergeline"><span class="mono lbl">${t('gScore')}: ${MG.score}</span><span class="mono">${t('gBest')}: ${best}</span></div>
<div class="mgrid">${cells}</div>
<div class="mpad4">
  <button class="ibtn" data-act="mvu" data-v="up" aria-label="Up">▲</button>
  <div><button class="ibtn" data-act="mvu" data-v="left" aria-label="Left">◀</button><button class="ibtn" data-act="mvu" data-v="down" aria-label="Down">▼</button><button class="ibtn" data-act="mvu" data-v="right" aria-label="Right">▶</button></div>
</div>
${MG.over ? `<div class="lime2"><div class="mono lbl-d">${t('gameOver')}</div><h2>${MG.score}</h2><p>${t('gBest')}: ${best}</p></div><button class="btn" data-act="mnew">${t('gNewGame')}</button>` : ''}
${MG.won && !MG.over ? `<div class="lime2"><div class="mono lbl-d">2048!</div><h2>${t('gameYouWon')}</h2><p>${t('gameKeepGoing')}</p></div>` : ''}`;
}
function mergeMove(dir) {
  if (!MG || MG.over) return;
  const g = MG.g.slice(), N = M4;
  const line = (arr) => {
    const vals = arr.filter((v) => v);
    const out = [];
    for (let i = 0; i < vals.length; i++) {
      if (vals[i] === vals[i + 1]) { out.push(vals[i] * 2); MG.score += vals[i] * 2; i++; }
      else out.push(vals[i]);
    }
    while (out.length < N) out.push(0);
    return out;
  };
  let changed = false;
  const get = (r, c) => g[r * N + c];
  const set = (r, c, v) => { g[r * N + c] = v; };
  if (dir === 'left' || dir === 'right') {
    for (let r = 0; r < N; r++) {
      const row = Array.from({ length: N }, (_, c) => get(r, c));
      const res = dir === 'left' ? line(row) : line(row.reverse()).reverse();
      for (let c = 0; c < N; c++) if (get(r, c) !== res[c]) changed = true;
      for (let c = 0; c < N; c++) set(r, c, res[c]);
    }
  } else {
    for (let c = 0; c < N; c++) {
      const col = Array.from({ length: N }, (_, r) => get(r, c));
      const res = dir === 'up' ? line(col) : line(col.reverse()).reverse();
      for (let r = 0; r < N; r++) if (get(r, c) !== res[r]) changed = true;
      for (let r = 0; r < N; r++) set(r, c, res[r]);
    }
  }
  if (!changed) return;
  MG.g = g;
  const max = Math.max(...g);
  if (max >= 2048) MG.won = true;
  addTile(MG);
  if (!canMove(MG.g)) { MG.over = true; saveBest('merge', MG.score).then((ok) => { if (ok) toast(`${t('gBest')}: ${MG.score}`); }); awardXP(Math.min(30, Math.floor(MG.score / 100)), '2048'); }
  renderMerge($('#sub-body'));
}
function canMove(g) {
  const N = M4;
  for (let i = 0; i < N * N; i++) {
    if (!g[i]) return true;
    if (i % N !== N - 1 && g[i] === g[i + 1]) return true;
    if (i < N * (N - 1) && g[i] === g[i + N]) return true;
  }
  return false;
}

/* ================= Word Challenge (solo) ================= */
const WORD_BANK = ['planet', 'garden', 'market', 'school', 'friend', 'window', 'letter', 'coffee', 'mountain', 'river',
  'science', 'music', 'family', 'travel', 'summer', 'winter', 'morning', 'evening', 'bridge', 'garden',
  'teacher', 'doctor', 'pocket', 'ticket', 'silver', 'forest', 'rocket', 'purple', 'circle', 'puzzle',
  'wisdom', 'brave', 'planet', 'rocket', 'lantern', 'marble', 'castle', 'meadow', 'thunder', 'candle'];
let WD = null;
export function openWords() {
  const r = rng(Date.now() % 100000);
  const picks = [...WORD_BANK].sort(() => r() - 0.5).slice(0, 5);
  WD = { words: picks, i: 0, score: 0, left: 40, solved: false, t: null, lastOk: null };
  openSub(t('gWords'), renderWords, '', () => { if (WD) clearInterval(WD.t); WD = null; });
  wordsTimer();
}
function wordsTimer() {
  clearInterval(WD.t);
  WD.left = 40;
  WD.t = setInterval(() => {
    if (!WD) return;
    WD.left--;
    const e = $('#wd-bar'); if (e) e.innerHTML = bar(WD.left / 40 * 100, 8);
    if (WD.left <= 0) wordsNext();
  }, 1000);
}
function scramble(w) {
  const a = w.split(''), r = rng(w.length * 977 + w.charCodeAt(0));
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1));[a[i], a[j]] = [a[j], a[i]]; }
  const s = a.join(''); return s === w ? scramble(w) : s;
}
function renderWords(body) {
  if (!WD) return;
  const w = WD.words[WD.i];
  const best = bestOf('words') || 0;
  body.innerHTML = `<div class="mergeline"><span class="mono lbl">${t('gScore')}: ${WD.score}</span><span class="mono">${t('gBest')}: ${best}</span></div>
<div id="wd-bar">${bar(WD.left / 40 * 100, 8)}</div>
<div class="wdscram">${esc(scramble(w))}</div>
<div class="wdhint mono">${t('gameHint')}: ${w[0]} · ${w.length} ${t('gameLetters')}</div>
<form id="wd-f" class="plain" autocomplete="off"><input id="wd-in" class="codein mono" placeholder="${t('gAnswer')}" autocapitalize="off" spellcheck="false" aria-label="${t('gAnswer')}"><button class="btn" type="submit">${t('gSubmit')}</button></form>
${WD.lastOk !== null ? `<div class="wdres ${WD.lastOk ? 'ok' : 'no'}">${WD.lastOk ? t('gameCorrect') : t('gameWrong')}</div>` : ''}
<div class="mono lbl">${t('gameWord')} ${WD.i + 1}/${WD.words.length}</div>`;
  const f = $('#wd-f'); if (f) f.onsubmit = (e) => { e.preventDefault(); wordsAnswer(); };
  const i = $('#wd-in'); if (i) i.focus();
}
function wordsAnswer() {
  if (!WD) return;
  const inp = $('#wd-in'), v = (inp.value || '').trim().toLowerCase();
  if (!v) return;
  const w = WD.words[WD.i];
  const ok = v === w;
  WD.lastOk = ok;
  if (ok) { WD.score++; saveBest('words', WD.score); awardXP(3, 'word'); }
  inp.value = '';
  refreshSub();
  setTimeout(() => { if (!WD) return; WD.lastOk = null; wordsNext(); }, 900);
}
function wordsNext() {
  if (!WD) return;
  WD.i++;
  if (WD.i >= WD.words.length) {
    clearInterval(WD.t);
    refreshSub();
    const b = $('#sub-body');
    if (b) b.innerHTML = `<div class="lime2"><div class="mono lbl-d">${t('gResult')}</div><h2>${WD.score} / ${WD.words.length}</h2><p>${t('gBest')}: ${bestOf('words') || WD.score}</p></div><button class="btn" data-act="wdnew">${t('gNewGame')}</button>`;
    return;
  }
  wordsTimer(); refreshSub();
}

/* ================= Reflex Test (solo) ================= */
let RX = null;
export function openReflex() {
  RX = { phase: 'wait', rounds: [], round: 0, start: 0, t: null, last: null };
  openSub(t('gReflex'), renderReflex, '', () => { if (RX) clearTimeout(RX.t); RX = null; });
  reflexArm();
}
function reflexArm() {
  if (!RX) return;
  RX.phase = 'wait'; RX.start = Date.now();
  renderReflex($('#sub-body'));
  RX.t = setTimeout(() => { if (!RX) return; RX.phase = 'go'; RX.start = Date.now(); renderReflex($('#sub-body')); }, 1200 + Math.random() * 3200);
}
function renderReflex(body) {
  if (!RX) return;
  const best = bestOf('reflex') || 0;
  const avg = RX.rounds.length ? Math.round(RX.rounds.reduce((a, b) => a + b, 0) / RX.rounds.length) : 0;
  body.innerHTML = `<div class="mergeline"><span class="mono lbl">${t('gameRound')} ${Math.min(RX.round + 1, 5)}/5</span><span class="mono">${t('gBest')}: ${best ? best + ' ms' : '—'}</span></div>
<div class="reflex ${RX.phase}">
  <div class="rbox">
    ${RX.phase === 'wait' ? `<b>${t('gameWaitGreen')}</b><span class="mono">${t('gameDontTap')}</span>`
      : RX.phase === 'go' ? `<b>${t('gameTapNow')}</b><span class="mono">${t('gTapGreen')}</span>`
        : `<b>${RX.last} ms</b><span class="mono">${t('gameNextRound')}</span>`}
  </div>
</div>
${RX.rounds.length ? `<div class="mono lbl">${t('gameYourTimes')}</div><div class="plrow"><b>${RX.rounds.join(' ms · ')} ms</b><em class="mono">${t('gScore')} ${avg} ms</em></div>` : ''}
<div class="two"><button class="btn soft" data-act="rxnew">${t('gNewGame')}</button>${RX.phase === 'done' ? `<button class="btn" data-act="rxnext">${t('btnNext')}</button>` : ''}</div>`;
}
function reflexTap() {
  if (!RX) return;
  if (RX.phase === 'wait') { clearTimeout(RX.t); RX.phase = 'tooearly'; RX.last = 0; renderReflex($('#sub-body')); return; }
  if (RX.phase !== 'go') return;
  const ms = Date.now() - RX.start;
  RX.rounds.push(ms);
  saveBest('reflex', ms, true);
  RX.phase = 'done';
  RX.last = ms;
  if (RX.rounds.length >= 5) { RX.phase = 'final'; renderReflex($('#sub-body')); const avg = Math.round(RX.rounds.reduce((a, b) => a + b, 0) / RX.rounds.length); awardXP(10, 'reflex'); toast(`${t('gScore')}: ${avg} ms`); }
  else renderReflex($('#sub-body'));
}

/* ================= click handling ================= */
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, v = b.dataset.v;
  switch (a) {
    case 'gfilter': gFilter = v; const box = $('#cm-games'); if (box) box.innerHTML = gamesHTML(); break;
    case 'gopen':
      if (focusActive() && !confirm(t('gameFocusConfirm'))) return;
      if (v === 'ttt' || v === 'math' || v === 'rps' || v === 'quiz') lobby(v);
      else if (v === 'memory') openMemory();
      else if (v === 'brain') openBrain();
      else if (v === 'merge') openMerge();
      else if (v === 'words') openWords();
      else openReflex();
      break;
    case 'gcreate': createGame(v); break;
    case 'gcont': enter(v, b.dataset.id); break;
    case 'gcopy': copyText(b.dataset.id).then((ok) => toast(ok ? t('btnCopy') + ' ✓' : 'Code: ' + b.dataset.id)); break;
    case 'tttmove': tttMove(Number(b.dataset.i)); break;
    case 'tttrematch': tttRematch(); break;
    case 'mstart': mathStart(); break;
    case 'mrematch': mathRematch(); break;
    case 'rpspick': rpsPick(v); break;
    case 'rpsrematch': rpsRematch(); break;
    case 'qans': qAns(Number(v)); break;
    case 'qnext': qNext(); break;
    case 'mdiff': MM.diff = v; refreshSub(); break;
    case 'mstartm': MM.seq = []; MM.lvl = 0; memRound(); break;
    case 'mpad': memPad(Number(b.dataset.i)); break;
    case 'bans': brainAnswer(v); break;
    case 'mvu': mergeMove(v); break;
    case 'mnew': openMerge(); break;
    case 'wdnew': openWords(); break;
    case 'rxnew': openReflex(); break;
    case 'rxtap': reflexTap(); break;
  }
});

/* keyboard + swipe for 2048 */
document.addEventListener('keydown', (e) => {
  if (!MG) return;
  const map = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right' };
  const d = map[e.key]; if (!d) return;
  if (document.activeElement && /INPUT|TEXTAREA/.test(document.activeElement.tagName)) return;
  e.preventDefault(); mergeMove(d);
});
let tsx = 0, tsy = 0;
document.addEventListener('touchstart', (e) => { const t = e.touches[0]; tsx = t.clientX; tsy = t.clientY; }, { passive: true });
document.addEventListener('touchend', (e) => {
  if (!MG) return;
  const t = e.changedTouches[0], dx = t.clientX - tsx, dy = t.clientY - tsy;
  if (Math.abs(dx) < 30 && Math.abs(dy) < 30) return;
  mergeMove(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
}, { passive: true });
