/* Home, Tracker extras, Schedule, More page, mode chooser */
import {
  $, $$, esc, S, D, store, toast, ic, P, saveMe, openSub, refreshSub, formSheet, bar, emptyBox, dot, tr, levelOf, xpForLevel,
  todayKey, addDaysY, fmtD, fmtDW, rel, fmtMin, nowHHMM, isStudent, openOv, closeOv, daysBetween, fromYmd
} from './core.js';
import { avatarHTML } from './avatar.js';
import { scoreOn, habitsOn } from './insights.js';
import { habitsHTML, focusTarget, focusToday, taskGroups, openTasks, openFocus, taskForm, habitForm } from './tasks.js';
import { studyPageHTML, upcomingExams, totalProgress, openPlanner } from './study.js';
import { lifePageHTML, upcomingEvents, openCalendar, openEvents, openNotes, openSearch, eventForm } from './life.js';
import { openAnalytics, openSettings, openDayPlanner } from './insights.js';
import { openAvatarCreator } from './avatar.js';
import * as Music from './music.js';
import { sync as syncNotif, permState } from './notify.js';

const greet = () => { const h = new Date().getHours(); return h < 5 ? 'Raat jaag rahe ho' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 21 ? 'Good evening' : 'Shubh ratri'; };

/* ================= HOME ================= */
export function homeHTML() {
  const t0 = todayKey(), g = taskGroups(), h = habitsOn(t0), fm = focusToday(), tg = focusTarget(), sc = scoreOn(t0);
  const st = isStudent(), L = levelOf(S.me.xp || 0);
  const done = D.tasks.filter((t) => t.doneDate === t0).length, total = g.today.length + done;
  const next = [
    ...g.overdue.slice(0, 2).map((t) => ({ k: t.due + (t.dueTime || ''), html: `<div class="plrow" data-act="taskedit" data-id="${t.id}">${dot('#FF9A8A')}<span class="mono">${fmtD(t.due)}</span><b>${esc(t.title)}</b><em class="mono">overdue</em></div>` })),
    ...g.today.map((t) => ({ k: t0 + (t.dueTime || '99'), html: `<div class="plrow" data-act="taskedit" data-id="${t.id}">${dot('#C8F23A')}<span class="mono">${t.dueTime || 'aaj'}</span><b>${esc(t.title)}</b><em class="mono">task</em></div>` })),
    ...upcomingEvents(7).slice(0, 4).map(({ x, d }) => ({ k: d + (x.time || '99'), html: `<div class="plrow" data-act="evedit" data-id="${x.id}">${dot('#B7A6E0')}<span class="mono">${d === t0 ? (x.time || 'aaj') : fmtD(d)}</span><b>${esc(x.title)}</b><em class="mono">event</em></div>` })),
    ...upcomingExams().slice(0, 2).map((x) => ({ k: x.date + (x.start || ''), html: `<div class="plrow exam" data-act="examedit" data-id="${x.id}"><span class="mono">${x.date === t0 ? 'aaj' : fmtD(x.date)}</span><b>${esc(x.subject || x.name)}</b><em class="mono">exam · ${rel(x.date)}</em></div>` }))
  ].sort((a, b) => a.k.localeCompare(b.k)).slice(0, 6);
  const sch = [...(S.me.schedule || [])].filter((i) => i.on).sort((a, b) => a.time.localeCompare(b.time)), now = nowHHMM();
  const nx = sch.filter((i) => i.time >= now).slice(0, 3);
  const ex = upcomingExams()[0];
  const left = g.today.length + g.overdue.length;
  const hero = `<div class="herocard">
  <img class="heroimg" src="assets/art/hero-home.webp" alt="" width="760" height="1018" loading="lazy">
  <div class="heroin">
    <div class="mono lbl-d">${left ? `${left} kaam bache hain` : 'Sab kuch ho gaya'}</div>
    <h2>${left ? 'Chal raha hai!' : 'Shandar din!'}</h2>
    <p>${left ? `${g.today.length} aaj · ${g.overdue.length} bakaye` : 'Aaj ka score dekho aur rest karo.'}</p>
  </div>
</div>`;
  return `<div class="top2"><div><div class="sub-s">${greet()}</div><h1 class="hello">${esc(S.me.name)}</h1></div><button class="pill lvl" data-act="tab" data-v="4" aria-label="Level ${L}"><i></i>Lv ${L}</button></div>
${hero}
<div class="lime2 score"><div class="mono lbl-d">${tr('Aaj ka score').toUpperCase()}</div><div class="bignum dk"><b>${sc}</b><span>/100</span></div>
<div class="mrow"><div><b>${done}/${total || 0}</b><span class="mono">tasks</span></div><div><b>${h.done}/${h.sched}</b><span class="mono">habits</span></div><div><b>${fmtMin(fm)}</b><span class="mono">focus / ${fmtMin(tg)}</span></div></div></div>
<div class="mono lbl">${tr('Quick actions').toUpperCase()}</div>
<div class="qa"><button data-act="taskadd">${ic(P.plus, 18, 2)}${tr('Naya task')}</button><button data-act="homefocus">${ic(P.timer, 18, 2)}${tr('Focus')}</button><button data-act="habadd">${ic(P.flame, 18, 2)}Habit</button><button data-act="noteadd">${ic(P.note, 18, 2)}Note</button><button data-act="${st ? 'examadd' : 'evadd'}">${ic(P.calp, 18, 2)}${st ? 'Exam' : 'Event'}</button><button data-act="homeplan">${ic(P.spark, 18, 2)}Planner</button></div>
${st && ex ? `<div class="card-big exc" data-act="studyopen" data-v="datesheet"><div class="cal-h"><b>${esc(ex.subject || ex.name)}</b><span class="mono">${rel(ex.date)}</span></div>${bar(totalProgress(), 8)}<div class="bar-l mono"><span>syllabus ${totalProgress()}%</span><span>${fmtDW(ex.date)}</span></div></div>` : ''}
<div class="cal-h"><b>${tr('Aage kya hai')}</b></div>${next.length ? next.map((n) => n.html).join('') : `<div class="emptyart"><img src="assets/art/mascot-solo.webp" alt="" width="560" height="560" loading="lazy"><p>Aaj kuch pending nahi. Chill karo ya naya task add karo.</p></div>`}
${nx.length ? `<div class="cal-h"><b>${tr('Schedule')}</b><button class="link" data-act="openschedule">Poora dekho</button></div>${nx.map((i) => `<div class="plrow">${dot('#A2A496')}<span class="mono">${esc(i.time)}</span><b>${esc(i.title)}</b></div>`).join('')}` : `<button class="btn soft" data-act="openschedule">${ic(P.clock, 18, 2)}Daily schedule kholo</button>`}`;
}

/* ================= TRACKER extras ================= */
export function trackerExtraHTML() {
  return `<div class="cal-h"><b>${tr('Habits')}</b><button class="addbtn" data-act="habadd" aria-label="Habit add">${ic(P.plus, 20, 2)}</button></div>${habitsHTML(true)}`;
}

/* ================= SCHEDULE (purana routine, ab sub-screen) ================= */
export function openSchedule() { openSub('Schedule', renderSchedule, `<button class="addbtn" data-act="additem" aria-label="Routine me add karo">${ic(P.plus, 20, 2)}</button>`); }
export function renderSchedule(body) {
  if (!S.me || !body) return;
  const items = [...(S.me.schedule || [])].sort((a, b) => a.time.localeCompare(b.time));
  const now = nowHHMM(), nextIdx = items.findIndex((x) => x.time >= now), onCount = items.filter((i) => i.on).length;
  const denied = 'Notification' in window && Notification.permission === 'denied';
  const rows = items.map((it, i) => {
    const state = nextIdx === -1 || i < nextIdx ? 'done' : i === nextIdx ? 'next' : 'later';
    return `<div class="sr ${state}"><div class="st mono">${esc(it.time)}</div><div class="rail"><i class="dot"></i></div>
<div class="sc"><div class="sct"><b>${esc(it.title)}</b>${it.sub ? `<span>${esc(it.sub)}</span>` : ''}</div>
<button class="sw" role="switch" aria-checked="${!!it.on}" aria-label="Reminder: ${esc(it.title)}" data-act="toggleitem" data-id="${esc(it.id)}"><i></i></button>
<button class="xb" aria-label="Delete ${esc(it.title)}" data-act="delitem" data-id="${esc(it.id)}">${ic(P.x, 16, 2)}</button></div></div>`;
  }).join('');
  body.innerHTML = `<div class="mono lbl">DAILY ROUTINE · AAJ</div>
<div class="mcard"><div class="bi">${ic(P.bell, 22, 2)}</div><div class="tx"><b>Daily reminders</b><span>${denied ? 'Notification block hai, browser settings me allow karo' : `${items.length} mein se ${onCount} on`}</span></div>
<button class="sw" role="switch" aria-checked="${!!S.me.remindersOn}" aria-label="Daily reminders" data-act="togglemaster"><i></i></button></div>
<div class="list">${rows || '<div class="empty">Koi routine nahi. + dabao aur add karo.</div>'}</div>`;
}

/* ================= STUDY / LIFE tab ================= */
export const thirdTabHTML = () => (isStudent() ? studyPageHTML() : lifePageHTML());

/* ================= MORE ================= */
export function moreHTML() {
  const xp = S.me.xp || 0, L = levelOf(xp), lo = xpForLevel(L), hi = xpForLevel(L + 1), st = S.me.status || {};
  const tiles = [['calendar', 'Calendar', P.cal], ['tasks', 'Tasks', P.list], ['events', 'Events', P.calp], ['notes', 'Notes', P.note], ['focus', 'Focus', P.timer], ['schedule', 'Schedule', P.clock],
    ['music', 'Music', P.note], ['analytics', 'Analytics', P.chart], ['planner', 'Day timeline', P.spark], ['studyplanner', 'Study planner', P.book], ['search', 'Search', P.search], ['avatar', 'Avatar', P.smile], ['settings', 'Settings', P.gear], ['profile', 'Profile', P.user]];
  const ch = Music.currentChannel();
  const musicCard = `<button class="card-big musiccard" data-act="moreopen" data-v="music">
  ${Music.coverArt(ch, 72)}
  <div class="pfm"><b>${esc(ch.emoji)} ${esc(ch.name)}</b><span>${esc(ch.tag)}</span><span class="mono">${Music.isPlaying() ? '● chal raha hai' : 'paused'} · ${ch.bpm} BPM</span></div>
  <span class="you">OPEN</span></button>`;
  return `<div class="phead"><h1>${tr('More')}</h1></div>
<button class="card-big prof" data-act="profile"><div class="pfa">${avatarHTML(S.me.avatar, 64)}</div><div class="pfm"><b>${esc(S.me.name)}${st.emoji ? ' ' + esc(st.emoji) : ''}</b><span class="mono">${st.text ? esc(st.text) : '@' + esc(S.me.username || 'username-set-karo')}</span>${bar((xp - lo) / Math.max(1, hi - lo) * 100, 6)}<span class="mono">Level ${L} · ${xp} XP</span></div></button>
${musicCard}
<div class="tiles t3">${tiles.map(([k, l, p]) => `<button class="tile ic" data-act="moreopen" data-v="${k}">${ic(p, 24, 1.8)}<b>${tr(l)}</b></button>`).join('')}</div>
<div class="seg sm" role="group" aria-label="Mode">${[['student', 'Student mode'], ['adult', 'Adult mode']].map(([v, l]) => `<button type="button" data-act="setmode2" data-v="${v}" aria-pressed="${(S.me.mode || 'student') === v}">${l}</button>`).join('')}</div>`;
}

/* ================= mode chooser (pehli baar) ================= */
export function maybeAskMode() {
  if (S.me.mode) return;
  formSheet({
    title: 'Tum kaun ho?', saveLabel: 'Aage badho', values: { mode: 'student' },
    extraHtml: '<p class="sub">Student: exam, syllabus, study planner. Adult: events, bills, meetings. Baad me Settings me badal sakte ho.</p>',
    fields: [{ k: 'mode', l: 'Mode', t: 'chips', o: [['student', 'Student'], ['adult', 'Adult']] }],
    onSave: (f) => { saveMe({ mode: f.mode || 'student' }); window.dispatchEvent(new Event('nnn-mode')); }
  });
}

document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, v = b.dataset.v;
  switch (a) {
    case 'homefocus': openFocus(); break;
    case 'homeplan': openPlanner(); break;
    case 'openschedule': openSchedule(); break;
    case 'setmode2': saveMe({ mode: v }); window.dispatchEvent(new Event('nnn-mode')); break;
    case 'moreopen': ({
      calendar: openCalendar, tasks: () => openTasks(), events: openEvents, notes: openNotes, focus: openFocus, schedule: openSchedule,
      analytics: openAnalytics, planner: openDayPlanner, studyplanner: openPlanner, music: () => Music.openMusic(),
      search: openSearch, avatar: openAvatarCreator, settings: openSettings,
      profile: () => window.dispatchEvent(new Event('nnn-profile'))
    })[v](); break;
  }
});
