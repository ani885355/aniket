/* ============================================================
   i18n.js — language layer for Peanut.

   10 languages, har screen ka visible copy translate hota hai.
   Language login page par bhi badal sakte ho (globe button),
   aur Settings > Language me.

   Strings alag-alag files me hain (i18n/<lang>.js) taaki ek
   language ka kaam dusre se independent rahe.
   ============================================================ */
import en from './i18n/en.js';
import hi from './i18n/hi.js';
import bn from './i18n/bn.js';
import ta from './i18n/ta.js';
import te from './i18n/te.js';
import kn from './i18n/kn.js';
import ml from './i18n/ml.js';
import gu from './i18n/gu.js';
import pa from './i18n/pa.js';
import mr from './i18n/mr.js';

export const DICT = { en, hi, bn, ta, te, kn, ml, gu, pa, mr };

export const LANGS = [
  { id: 'en', native: 'English', name: 'English' },
  { id: 'hi', native: 'हिन्दी', name: 'Hindi' },
  { id: 'bn', native: 'বাংলা', name: 'Bengali' },
  { id: 'ta', native: 'தமிழ்', name: 'Tamil' },
  { id: 'te', native: 'తెలుగు', name: 'Telugu' },
  { id: 'kn', native: 'ಕನ್ನಡ', name: 'Kannada' },
  { id: 'ml', native: 'മലയാളം', name: 'Malayalam' },
  { id: 'gu', native: 'ગુજરાતી', name: 'Gujarati' },
  { id: 'pa', native: 'ਪੰਜਾਬੀ', name: 'Punjabi' },
  { id: 'mr', native: 'मराठी', name: 'Marathi' }
];

export const LANG_KEYS = Object.keys(en);

/* Purane keys (jo code me pehle se the) naye keys se map hote hain —
   taaki ek hi jagah badalne se poora app translate ho jaaye. */
export const ALIAS = {
  'Home': 'tabHome', 'Tracker': 'tabTracker', 'Study': 'tabStudy', 'Life': 'tabLife',
  'Community': 'tabCommunity', 'More': 'tabMore', 'Tasks': 'miscTasks', 'Calendar': 'miscCalendar',
  'Notes': 'miscNotes', 'Analytics': 'miscAnalytics', 'Settings': 'setTitle', 'Focus': 'stuFocus',
  'Syllabus': 'stuSyllabus', 'Datesheet': 'stuDatesheet', 'Planner': 'stuPlanner',
  'Revision': 'stuRevision', 'Events': 'miscEvents', 'Habits': 'miscHabits',
  'Today': 'miscToday', 'Upcoming': 'miscUpcoming', 'Overdue': 'miscOverdue', 'Done': 'miscDone',
  'Profile': 'pfTitle', 'Games': 'gameHub', 'Board': 'comBoard', 'Wall': 'comWall',
  'Save karo': 'btnSave', 'Cancel': 'btnCancel', 'Delete': 'btnDelete', 'Language': 'setLang',
  'Aaj ka score': 'homeScore', 'Quick actions': 'homeQuick', 'Aage kya hai': 'homeWhatsNext',
  'Search': 'miscSearch', 'Schedule': 'homeSchedule', 'Exams': 'miscExams',
  'Naya task': 'btnAdd', 'Streak': 'trkCheckin', 'Level': 'gLevel', 'Backup': 'setBackup'
};

/* ---------- current language ---------- */
let cur = 'en';
try { cur = localStorage.getItem('pn_lang') || detectLang(); } catch { cur = 'en'; }
if (!DICT[cur]) cur = 'en';

export function getLang() { return cur; }

export function detectLang() {
  const list = [navigator.language, ...(navigator.languages || [])].filter(Boolean);
  for (const l of list) {
    const base = String(l).toLowerCase().split('-')[0];
    if (DICT[base]) return base;
  }
  return 'en';
}

/* ---------- translate ---------- */
export function t(key, fallback) {
  const k = ALIAS[key] || key;
  const lang = DICT[cur] || DICT.en;
  if (lang && lang[k]) return lang[k];
  if (DICT.en && DICT.en[k]) return DICT.en[k];
  if (fallback) return fallback;
  return key;
}

/* ---------- switch ---------- */
export function setLang(id) {
  if (!DICT[id]) id = 'en';
  cur = id;
  try { localStorage.setItem('pn_lang', id); } catch { /* private mode */ }
  document.documentElement.lang = id;
  try { window.dispatchEvent(new Event('pn-lang')); } catch { /* ignore */ }
}

/* ---------- picker ---------- */
export function langPickerHTML(opts = {}) {
  const act = opts.act || 'setlang2';
  if (opts.compact) {
    return `<div class="chips scrollx">${LANGS.map((l) => `<button class="chip" data-act="${act}" data-v="${l.id}" aria-pressed="${cur === l.id}">${l.native}</button>`).join('')}</div>`;
  }
  return `<div class="langgrid">${LANGS.map((l) => `<button class="langopt" data-act="${act}" data-v="${l.id}" aria-pressed="${cur === l.id}"><b>${l.native}</b><span class="mono">${l.name}</span></button>`).join('')}</div>`;
}

/* ---------- apply on boot ---------- */
export function applyLang() {
  document.documentElement.lang = cur;
}
