/* Analytics + gamification, smart planner (rule-based), settings, backup/export, PIN lock */
import {
  $, $$, esc, S, D, store, toast, ic, P, add, upd, find, openSub, refreshSub, formSheet, bar, seg, emptyBox, dot, exportFile, pickFile,
  todayKey, addDaysY, fromYmd, ymd, fmtD, fmtDW, rel, fmtMin, pad, WD, daysBetween, saveMe, levelOf, xpForLevel, auth, db, doc, setDoc, saveMe as _s,
  nowHHMM, tr, popLayer
} from './core.js';
import { habitActive, habitStreak, focusTarget, focusToday, taskGroups, isOverdue } from './tasks.js';
import { totalProgress, subjectProgress, upcomingExams, chapterProgress } from './study.js';
import { upcomingEvents } from './life.js';
import * as N from './notify.js';

/* ================= stats ================= */
export function tasksDoneOn(d) { return D.tasks.filter((t) => (t.doneDate || (t.doneAt ? ymd(new Date(t.doneAt)) : '')) === d).length + D.tasks.filter((t) => t.lastDone === d && !t.done).length; }
export function focusOn(d) { return D.sessions.filter((s) => s.date === d && s.kind !== 'break').reduce((a, s) => a + (s.mins || 0), 0); }
export function habitsOn(d) {
  const hs = D.habits.filter((h) => !h.archived && habitActive(h, d) && !(h.skips || []).includes(d));
  return { sched: hs.length, done: hs.filter((h) => (h.log || []).includes(d)).length };
}
export function scoreOn(d) {
  const parts = [];
  const planned = D.tasks.filter((t) => t.due === d || t.doneDate === d).length, done = tasksDoneOn(d);
  if (planned || done) parts.push(Math.min(1, done / Math.max(planned, done)));
  const h = habitsOn(d); if (h.sched) parts.push(h.done / h.sched);
  const tg = focusTarget(); if (tg && (focusOn(d) > 0 || d === todayKey())) parts.push(Math.min(1, focusOn(d) / tg));
  return parts.length ? Math.round(parts.reduce((a, b) => a + b, 0) / parts.length * 100) : 0;
}
const range = (n) => Array.from({ length: n }, (_, i) => addDaysY(todayKey(), i - n + 1));
function bestRun(h) {
  const s = [...(h.log || [])].sort(); let best = 0, run = 0, prev = null;
  s.forEach((d) => { run = prev && daysBetween(prev, d) === 1 ? run + 1 : 1; best = Math.max(best, run); prev = d; });
  return best;
}
export function stats() {
  const tasksDone = D.tasks.filter((t) => t.done).length + D.tasks.reduce((a, t) => a + (t.doneCount || 0), 0);
  const focusMin = D.sessions.filter((s) => s.kind !== 'break').reduce((a, s) => a + (s.mins || 0), 0);
  const studyMin = D.sessions.filter((s) => s.kind !== 'break' && String(s.link || '').startsWith('subject:')).reduce((a, s) => a + (s.mins || 0), 0);
  const chapters = D.subjects.flatMap((s) => s.chapters || []);
  const m = S.members.find((x) => x.uid === S.user.uid);
  return {
    tasksDone, focusMin, studyMin, chaptersDone: chapters.filter((c) => chapterProgress(c) >= 1).length,
    streak: Math.max(0, ...D.habits.map(habitStreak)), bestStreak: Math.max(0, ...D.habits.map(bestRun)),
    checkins: m ? (m.checkins || []).length : 0, notes: D.notes.length, exams: D.exams.length, level: levelOf(S.me.xp || 0),
    syllabus: totalProgress(), wins: S.me.gameWins || 0,
    bestFocusDay: Math.max(0, ...range(60).map(focusOn)), bestTaskDay: Math.max(0, ...range(60).map(tasksDoneOn))
  };
}
export const BADGES = [
  ['🌱', 'Pehla kadam', 'Pehla task complete', (s) => s.tasksDone >= 1], ['✅', 'Task machine', '25 tasks complete', (s) => s.tasksDone >= 25],
  ['⏱️', 'Focus shuru', '60 min focus', (s) => s.focusMin >= 60], ['🧠', 'Deep worker', '10 ghante focus', (s) => s.focusMin >= 600],
  ['🔥', 'Week streak', 'Habit streak 7 din', (s) => s.bestStreak >= 7], ['💪', 'Month streak', 'Habit streak 30 din', (s) => s.bestStreak >= 30],
  ['🥜', 'Peanut warrior', '7 din ki streak', (s) => s.checkins >= 7], ['📚', 'Chapter hero', '5 chapters complete', (s) => s.chaptersDone >= 5],
  ['🎓', 'Syllabus 50%', 'Aadha syllabus', (s) => s.syllabus >= 50], ['📝', 'Note taker', '5 notes', (s) => s.notes >= 5],
  ['🗓️', 'Exam ready', 'Datesheet add ki', (s) => s.exams >= 1], ['🏆', 'Level 5', 'Level 5 tak pahunche', (s) => s.level >= 5], ['🎮', 'Game jeeta', 'Pehla multiplayer win', (s) => s.wins >= 1]
];
function chIdx(v, t) { return Math.min(1, v / t); }
function challenges() {
  const t0 = todayKey(), w = range(7);
  return [['Aaj', '3 tasks complete karo', Math.min(3, tasksDoneOn(t0)), 3], ['Aaj', '25 min focus', Math.min(25, focusOn(t0)), 25], ['Aaj', 'Saari habits poori', habitsOn(t0).done, Math.max(1, habitsOn(t0).sched)],
    ['Is hafte', '10 tasks complete', Math.min(10, w.reduce((a, d) => a + tasksDoneOn(d), 0)), 10], ['Is hafte', '3 ghante focus', Math.min(180, w.reduce((a, d) => a + focusOn(d), 0)), 180]];
}
const miniBars = (arr, labels, unit = '') => { const mx = Math.max(1, ...arr); return `<div class="wbars">${arr.map((v, i) => `<div class="wb" title="${labels[i]}: ${v}${unit}"><i style="height:${Math.round(v / mx * 100)}%"></i><span class="mono">${labels[i]}</span></div>`).join('')}</div>`; };

export function openAnalytics() { openSub('Analytics', renderAnalytics); }
let aRange = 'week';
function renderAnalytics(body) {
  const st = stats(), xp = S.me.xp || 0, L = st.level, lo = xpForLevel(L), hi = xpForLevel(L + 1);
  const days = range(aRange === 'week' ? 7 : 30), lab = days.map((d) => (aRange === 'week' ? WD[fromYmd(d).getDay()][0] : String(fromYmd(d).getDate())));
  const sc = days.map(scoreOn), tk = days.map(tasksDoneOn), fc = days.map(focusOn);
  const habAvg = Math.round(days.map((d) => { const h = habitsOn(d); return h.sched ? h.done / h.sched : null; }).filter((x) => x !== null).reduce((a, b, _, r) => a + b / r.length, 0) * 100);
  const planned = D.tasks.filter((t) => days.includes(t.due)).length, doneP = D.tasks.filter((t) => days.includes(t.due) && t.done).length;
  const subs = D.subjects.map((s) => `<div class="cal-h"><b>${esc(s.name)}</b><span class="mono">${subjectProgress(s)}%</span></div>${bar(subjectProgress(s), 6)}`).join('');
  const ex = upcomingExams()[0];
  body.innerHTML = `<div class="lime2"><div class="mono lbl-d">LEVEL ${L} · ${xp} XP</div><h2>Aaj ka score: ${scoreOn(todayKey())}</h2>${bar((xp - lo) / Math.max(1, hi - lo) * 100, 8)}<p>${hi - xp} XP aur, phir Level ${L + 1}</p></div>
${seg([['week', 'Weekly'], ['month', 'Monthly']], aRange, 'arange')}
<div class="card-big"><div class="cal-h"><b>Productivity score</b><span class="mono">avg ${Math.round(sc.reduce((a, b) => a + b, 0) / sc.length)}</span></div>${miniBars(sc, lab)}</div>
<div class="card-big"><div class="cal-h"><b>Focus</b><span class="mono">${fmtMin(fc.reduce((a, b) => a + b, 0))}</span></div>${miniBars(fc, lab, 'm')}<div class="bar-l mono"><span>study (subject-linked): ${fmtMin(st.studyMin)}</span><span>total: ${fmtMin(st.focusMin)}</span></div></div>
<div class="tiles"><div class="tile"><b>${planned ? Math.round(doneP / planned * 100) : 0}%</b><span class="mono">tasks done (${doneP}/${planned})</span></div><div class="tile"><b>${habAvg || 0}%</b><span class="mono">habit consistency</span></div>
<div class="tile"><b>${st.syllabus}%</b><span class="mono">syllabus complete</span></div><div class="tile"><b>${ex ? subjectProgress(D.subjects.find((s) => s.name.toLowerCase() === String(ex.subject).toLowerCase()) || { chapters: [] }) + '%' : '-'}</b><span class="mono">${ex ? esc(ex.subject) + ' prep' : 'exam prep'}</span></div></div>
${subs ? `<div class="card-big">${subs}</div>` : ''}
<div class="mono lbl">PERSONAL BESTS</div>
<div class="tiles"><div class="tile"><b>${st.bestStreak}</b><span class="mono">best habit streak</span></div><div class="tile"><b>${fmtMin(st.bestFocusDay)}</b><span class="mono">best focus day</span></div><div class="tile"><b>${st.bestTaskDay}</b><span class="mono">tasks in a day</span></div><div class="tile"><b>${st.tasksDone}</b><span class="mono">total tasks done</span></div></div>
<div class="mono lbl">CHALLENGES</div>${challenges().map(([k, t, v, g]) => `<div class="card-big"><div class="cal-h"><b>${t}</b><span class="mono">${k} · ${v}/${g}</span></div>${bar(v / g * 100, 8)}</div>`).join('')}
<div class="mono lbl">BADGES</div><div class="badges">${BADGES.map(([e, n, d, f]) => { const on = f(st); return `<div class="badge ${on ? 'on' : ''}"><span>${on ? e : '🔒'}</span><b>${n}</b><em class="mono">${d}</em></div>`; }).join('')}</div>
<button class="btn soft" data-act="weeklysum">${ic(P.spark, 18, 2)}Weekly summary</button>`;
}
function weeklySummary() {
  const days = range(7), tk = days.reduce((a, d) => a + tasksDoneOn(d), 0), fm = days.reduce((a, d) => a + focusOn(d), 0);
  const hp = days.map((d) => habitsOn(d)).reduce((a, h) => ({ s: a.s + h.sched, d: a.d + h.done }), { s: 0, d: 0 });
  const bestDay = days.map((d) => [d, scoreOn(d)]).sort((a, b) => b[1] - a[1])[0];
  const ex = upcomingExams()[0];
  const lines = [`Is hafte ${tk} tasks complete hue.`, `Focus: ${fmtMin(fm)}.`, hp.s ? `Habits: ${hp.d}/${hp.s} (${Math.round(hp.d / hp.s * 100)}%).` : 'Habits abhi set nahi hain.', bestDay && bestDay[1] ? `Sabse achha din: ${fmtDW(bestDay[0])} (score ${bestDay[1]}).` : '', ex ? `Agla exam: ${ex.subject || ex.name}, ${rel(ex.date)}.` : '', fm + tk === 0 ? 'Koi baat nahi, naya hafta naya start. Ek chhota task se shuru karo.' : 'Badhiya chal raha hai, isi rhythm me rehna.'].filter(Boolean);
  alert(lines.join('\n'));
}

/* ================= smart planner (rule-based, locally, koi cloud AI nahi) ================= */
const W = { high: 30, med: 15, low: 5 };
const toMin = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const fromMin = (m) => `${pad(Math.floor(m / 60) % 24)}:${pad(m % 60)}`;
const DAY_START = 7 * 60, DAY_END = 22 * 60;

export function buildDayPlan() {
  const t0 = todayKey(), busy = [], items = [];
  upcomingEvents(0).filter((u) => u.d === t0 && u.x.time).forEach(({ x }) => busy.push([toMin(x.time), toMin(x.time) + 60, x.title, 'fixed']));
  D.exams.filter((x) => x.date === t0 && x.start).forEach((x) => busy.push([toMin(x.start), x.end ? toMin(x.end) : toMin(x.start) + 180, 'Exam: ' + (x.subject || x.name), 'fixed']));
  D.tasks.filter((t) => !t.done && t.due === t0 && t.dueTime).forEach((t) => busy.push([toMin(t.dueTime), toMin(t.dueTime) + 30, t.title, 'task', t.id]));
  /* daily routine bhi busy time hai */
  (S.me.schedule || []).filter((i) => i.on).forEach((i) => busy.push([toMin(i.time), toMin(i.time) + 30, i.title, 'fixed']));
  busy.push([13 * 60, 13 * 60 + 45, 'Lunch break', 'break']);
  busy.push([18 * 60, 18 * 60 + 20, 'Chai break', 'break']);
  const cands = [];
  D.tasks.filter((t) => !t.done && (isOverdue(t) || t.due === t0) && !t.dueTime).forEach((t) => cands.push({ title: t.title, id: t.id, est: t.kind === 'project' ? 60 : 30, sc: (W[t.prio] || 15) + (t.due < t0 ? 10 + daysBetween(t.due, t0) * 2 : 8), type: 'task', moved: t.due < t0 }));
  upcomingExams().filter((x) => daysBetween(t0, x.date) <= 14).forEach((x) => {
    const s = D.subjects.find((q) => (q.name || '').toLowerCase() === String(x.subject || '').toLowerCase());
    const chs = s ? (s.chapters || []).filter((c) => chapterProgress(c) < 1).sort((a, b) => (a.prio === 'high' ? -1 : 0) - (b.prio === 'high' ? -1 : 0)) : [];
    const ch = chs[0] || null;
    cands.push({
      title: ch ? `Study: ${s.name} – ${ch.name}` : `Revise ${x.subject || x.name}`, est: 45,
      sc: 40 - daysBetween(t0, x.date) * 2, type: 'study',
      meta: { subject: x.subject || x.name, chapter: ch ? ch.name : '' }
    });
  });
  cands.sort((a, b) => b.sc - a.sc);
  /* Raat ho gayi to aaj ka din bhar gaya — plan agle subah se. */
  const now = new Date(), nowMin = now.getHours() * 60 + now.getMinutes();
  const lateDay = nowMin > DAY_END - 60;
  let cur = lateDay ? DAY_START : Math.max(DAY_START, Math.ceil(nowMin / 15) * 15);
  const end = lateDay ? 23 * 60 : DAY_END;
  let streak = 0;
  const placed = [...busy.map((b) => ({ s: b[0], e: b[1], title: b[2], type: b[3], id: b[4] }))];
  for (const c of cands.slice(0, 10)) {
    let ok = false;
    let guard = 0;
    while (cur + c.est <= end && guard++ < 200) {
      const hit = placed.find((p) => p.s < cur + c.est && p.e > cur);
      if (hit) { cur = Math.max(cur, hit.e); streak = 0; continue; }
      placed.push({ s: cur, e: cur + c.est, title: c.title, type: c.type, id: c.id, moved: c.moved, meta: c.meta }); cur += c.est; streak += c.est; ok = true;
      if (streak >= 50) { placed.push({ s: cur, e: cur + 10, title: 'Chhota break', type: 'break' }); cur += 10; streak = 0; }
      break;
    }
    if (!ok) break;
  }
  const sorted = placed.sort((a, b) => a.s - b.s).map((p) => ({ ...p, time: fromMin(p.s), end: fromMin(p.e) }));
  return lateDay ? sorted.map((p) => ({ ...p, tomorrow: true })) : sorted;
}
let PL = null;
export function openDayPlanner() {
  PL = buildDayPlan().map((p) => ({ ...p, on: p.type === 'task' || p.type === 'study' }));
  openSub('Smart planner', renderPlanner);
}
function renderPlanner(body) {
  const overdue = taskGroups().overdue;
  const late = PL.some((p) => p.tomorrow);
  body.innerHTML = `<div class="warnbox">Ye rule-based planner hai (internet/cloud AI nahi). Ye kuch bhi delete nahi karta, aur tumhari approval ke bina kuch badalta nahi.</div>
${late ? '<div class="card-big"><b>Raat ho gayi hai</b><p class="sub">Aaj ka plan khatam ho chuka hai — niche wala plan kal subah 7:00 se shuru hota hai.</p></div>' : ''}
${PL.length ? PL.map((p, i) => `<div class="plrow ${p.type}"><span class="mono">${p.time}–${p.end}</span><b>${esc(p.title)}</b>${p.type === 'task' || p.type === 'study' ? `<button class="tick sm" role="checkbox" aria-checked="${p.on}" data-act="pldayon" data-i="${i}">${p.on ? ic(P.check, 14, 3) : ''}</button>` : `<em class="mono">${p.type}</em>`}</div>`).join('') : emptyBox('Aaj ke liye kuch plan karne ko nahi. Tasks ya exam add karo.')}
<button class="btn" data-act="pldayapply">Chune hue ko aaj ke time pe lagao</button>
${overdue.length ? `<div class="mono lbl">BAKAYA · ${overdue.length}</div>${overdue.slice(0, 8).map((t) => `<div class="plrow"><b>${esc(t.title)}</b><em class="mono">${fmtD(t.due)}</em></div>`).join('')}<button class="btn soft" data-act="plresched">Bakaya tasks kal pe shift karo (confirm karke)</button>` : ''}
<button class="btn soft" data-act="plsplit">Bade task ko steps me todo</button>`;
}
function splitTask() {
  const big = D.tasks.filter((t) => !t.done && !(t.subs || []).length).slice(0, 20);
  if (!big.length) return toast('Todne layak task nahi mila');
  formSheet({ title: 'Task ko steps me todo', saveLabel: 'Steps jodo', values: { id: big[0].id }, fields: [{ k: 'id', l: 'Kaun sa task', t: 'select', o: big.map((t) => [t.id, t.title]) }],
    onSave: (f) => { const t = find('tasks', f.id); if (!t) return; const steps = ['Zaroori cheezein jama karo (10 min)', 'Pehla hissa karo (25 min)', 'Dusra hissa karo (25 min)', 'Check karke finish karo (10 min)']; upd('tasks', t.id, { subs: steps.map((s, i) => ({ id: 's' + i, t: s, d: false })) }); toast('4 steps jud gaye. Edit kar sakte ho'); } });
}

/* ================= settings ================= */
export function openSettings() { openSub('Settings', renderSettings); }
async function renderSettings(body) {
  const lang = store.get('nnn_lang', 'en'), a11 = store.json('nnn_a11y', {}), perm = await N.permState(), np = N.getPrefs(), pr = S.me.privacy || {}, hasPin = !!store.get('nnn_pin');
  const sw = (act, on, label, sub = '') => `<div class="mcard"><div class="tx"><b>${label}</b>${sub ? `<span>${sub}</span>` : ''}</div><button class="sw" role="switch" aria-checked="${!!on}" data-act="${act}"><i></i></button></div>`;
  const swk = (act, k, on, label) => `<div class="mcard"><div class="tx"><b>${label}</b></div><button class="sw" role="switch" aria-checked="${!!on}" data-act="${act}" data-v="${k}"><i></i></button></div>`;
  body.innerHTML = `<div class="mono lbl">MODE</div>${seg([['student', 'Student'], ['adult', 'Adult']], S.me.mode || 'student', 'setmode')}
<div class="mono lbl">${tr('Language').toUpperCase()}</div>${seg([['en', 'English'], ['hi', 'हिन्दी']], lang, 'setlang')}
<div class="mono lbl">ACCESSIBILITY</div>${swk('a11y', 'large', a11.large, 'Bada text')}${swk('a11y', 'contrast', a11.contrast, 'High contrast')}${swk('a11y', 'motion', a11.motion, 'Kam animation')}
<div class="mono lbl">PRIVACY &amp; LOCK</div>${sw('privonline', pr.online !== false, 'Online status dikhao', 'Room members ko dikhta hai')}
<div class="mcard"><div class="tx"><b>App lock (PIN)</b><span>${hasPin ? 'On, sirf is device pe' : 'Off'}</span></div><button class="btn soft sm" data-act="${hasPin ? 'pinoff' : 'pinset'}">${hasPin ? 'Hatao' : 'Set karo'}</button></div>
<div class="mono lbl">NOTIFICATIONS</div>
<div class="mcard"><div class="tx"><b>Permission: ${perm === 'granted' ? 'mili hui' : perm === 'denied' ? 'band' : perm === 'unsupported' ? 'unsupported' : 'maangi nahi'}</b><span>${N.NATIVE ? 'Android native reminders' : 'Browser (app khula ho tab)'}</span></div>${perm !== 'granted' && perm !== 'unsupported' ? '<button class="btn soft sm" data-act="notifask">Allow</button>' : ''}</div>
${N.NOTIF_KINDS.map(([k, l]) => swk('nprefs', k, np[k], l)).join('')}
<div class="two"><button class="btn soft" data-act="nhist">History</button><button class="btn soft" data-act="nup">Aane wale</button></div>
<div class="mono lbl">DATA</div>
<div class="two"><button class="btn soft" data-act="exp" data-v="json">${ic(P.down, 18, 2)}Backup (JSON)</button><button class="btn soft" data-act="restore">Restore</button></div>
<div class="two"><button class="btn soft" data-act="exp" data-v="csv">CSV export</button><button class="btn soft" data-act="exp" data-v="ics">Calendar (.ics)</button></div>
<button class="btn soft" data-act="exp" data-v="pdf">Report (PDF / print)</button>
<div class="mono lbl">HELP</div><div class="card-big help"><b>Madad</b><p>Reminders nahi aa rahe? Phone Settings → Apps → Peanut → Notifications on rakho, aur battery saver me Peanut ko "unrestricted" karo.</p><p>Data sync nahi ho raha? Internet check karo. Offline me jo likhoge wo net aate hi apne aap sync ho jayega.</p><p>PIN bhool gaye? Lock screen pe Logout dabao.</p></div>`;
}
const CSV_COLS = { tasks: ['title', 'kind', 'prio', 'due', 'dueTime', 'done', 'cat'], events: ['title', 'cat', 'date', 'time', 'loc', 'repeat'], exams: ['subject', 'name', 'date', 'start', 'end', 'loc'], sessions: ['date', 'mins', 'kind', 'label'], scores: ['subject', 'name', 'marks', 'total', 'date'], notes: ['title', 'kind', 'body'], habits: ['name', 'part', 'time'] };
function toCSV() {
  const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  return Object.entries(CSV_COLS).map(([c, cols]) => `# ${c}\n${cols.join(',')}\n${D[c].map((r) => cols.map((k) => q(r[k])).join(',')).join('\n')}`).join('\n\n');
}
function backupJSON() {
  const data = {}; Object.keys(D).forEach((c) => { data[c] = D[c].map((r) => { const { createdAt, ...rest } = r; return rest; }); });
  const { createdAt, ...me } = S.me;
  return JSON.stringify({ app: 'Peanut', v: 3, at: new Date().toISOString(), me: { schedule: me.schedule, study: me.study, avatars: me.avatars, mode: me.mode, focusTarget: me.focusTarget }, data }, null, 1);
}
async function restore() {
  const f = await pickFile('application/json,.json'); if (!f) return;
  try {
    const j = JSON.parse(await f.text()); if ((j.app !== 'Peanut' && j.app !== 'NNN') || !j.data) throw new Error('bad');
    let n = 0; const { setDoc: sd, doc: dd, db: dbx } = { setDoc, doc, db };
    for (const [c, rows] of Object.entries(j.data)) {
      if (!(c in D)) continue;
      for (const r of rows) {
        const { id, ...rest } = r; if (!id || D[c].some((x) => x.id === id)) continue; /* existing data kabhi overwrite nahi hota */
        sd(dd(dbx, 'users', S.user.uid, c, String(id).slice(0, 40)), JSON.parse(JSON.stringify(rest))).catch(() => {}); n++;
      }
    }
    toast(`${n} naye records restore hue (purana data waisa hi hai)`);
  } catch { toast('Ye Peanut backup file nahi lagti'); }
}
function printReport() {
  const t0 = todayKey(), st = stats();
  const root = $('#print-root');
  root.innerHTML = `<h1>Peanut report</h1><p>${fmtD(t0)} · Level ${st.level} · ${S.me.xp || 0} XP</p><h2>Summary</h2><ul><li>Tasks done: ${st.tasksDone}</li><li>Focus: ${fmtMin(st.focusMin)}</li><li>Syllabus: ${st.syllabus}%</li><li>Best habit streak: ${st.bestStreak}</li></ul>
<h2>Upcoming exams</h2><ul>${upcomingExams().map((x) => `<li>${fmtDW(x.date)} ${esc(x.subject || x.name)} ${x.start || ''}</li>`).join('') || '<li>-</li>'}</ul>
<h2>Pending tasks</h2><ul>${D.tasks.filter((t) => !t.done).map((t) => `<li>${esc(t.title)} ${t.due ? '(' + fmtD(t.due) + ')' : ''}</li>`).join('') || '<li>-</li>'}</ul>
<h2>Subjects</h2><ul>${D.subjects.map((s) => `<li>${esc(s.name)}: ${subjectProgress(s)}%</li>`).join('') || '<li>-</li>'}</ul>`;
  document.body.classList.add('printing');
  setTimeout(() => { try { window.print(); } catch { toast('Print is device pe nahi chala'); } setTimeout(() => document.body.classList.remove('printing'), 500); }, 100);
}

/* ---------- accessibility / language ---------- */
export function applyA11y() {
  const a = store.json('nnn_a11y', {}), r = document.documentElement;
  r.classList.toggle('a-large', !!a.large); r.classList.toggle('a-contrast', !!a.contrast); r.classList.toggle('a-calm', !!a.motion);
}

/* ---------- PIN lock ---------- */
const hashPin = async (pin) => {
  const salt = store.get('nnn_pinsalt') || (() => { const s = Math.random().toString(36).slice(2); store.set('nnn_pinsalt', s); return s; })();
  try { const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(salt + pin)); return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, '0')).join(''); } catch { return 'p' + btoa(salt + pin); }
};
let pinBuf = '', pinMode = 'check', pinFirst = '', pinFail = 0, pinLockedUntil = 0, hiddenAt = 0;
function paintLock(msg) {
  const el = $('#lock');
  el.innerHTML = `<div class="lockbox"><div class="bellbox">${ic(P.lock, 26, 2)}</div><h2>${pinMode === 'set' ? 'Naya PIN' : pinMode === 'confirm' ? 'PIN dobara daalo' : 'PIN daalo'}</h2><div class="mono sub">${esc(msg || '')}</div>
<div class="pdots">${[0, 1, 2, 3].map((i) => `<i class="${i < pinBuf.length ? 'on' : ''}"></i>`).join('')}</div>
<div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, '⌫'].map((k) => k === '' ? '<i></i>' : `<button data-act="pinkey" data-v="${k}" aria-label="${k}">${k}</button>`).join('')}</div>
${pinMode === 'check' ? '<button class="link" data-act="pinforgot">PIN bhool gaye? Logout</button>' : '<button class="link" data-act="pincancel">Cancel</button>'}</div>`;
}
export function lockIfNeeded() { if (store.get('nnn_pin') && S.user) { pinMode = 'check'; pinBuf = ''; paintLock(); $('#lock').classList.remove('hidden'); } }
document.addEventListener('visibilitychange', () => { if (document.hidden) hiddenAt = Date.now(); else if (hiddenAt && Date.now() - hiddenAt > 30000) lockIfNeeded(); });
async function pinKey(k) {
  if (Date.now() < pinLockedUntil) return paintLock('Thodi der baad try karo');
  if (k === '⌫') pinBuf = pinBuf.slice(0, -1); else if (pinBuf.length < 4) pinBuf += k;
  paintLock();
  if (pinBuf.length < 4) return;
  const h = await hashPin(pinBuf), entered = pinBuf; pinBuf = '';
  if (pinMode === 'check') {
    if (h === store.get('nnn_pin')) { pinFail = 0; $('#lock').classList.add('hidden'); }
    else { pinFail++; if (pinFail >= 5) { pinLockedUntil = Date.now() + 30000; pinFail = 0; paintLock('5 galat try, 30 sec ruko'); } else paintLock('Galat PIN'); }
  } else if (pinMode === 'set') { pinFirst = entered; pinMode = 'confirm'; paintLock(); }
  else if (pinMode === 'confirm') {
    if (entered === pinFirst) { store.set('nnn_pin', h); $('#lock').classList.add('hidden'); toast('App lock chalu'); refreshSub(); }
    else { pinMode = 'set'; paintLock('Match nahi hua, phir se'); }
  }
}

/* ================= click handling ================= */
document.addEventListener('click', async (e) => {
  const b = e.target.closest && e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, v = b.dataset.v, flip = () => b.getAttribute('aria-checked') !== 'true';
  switch (a) {
    case 'arange': aRange = v; refreshSub(); break;
    case 'weeklysum': weeklySummary(); break;
    case 'pldayon': PL[Number(b.dataset.i)].on = !PL[Number(b.dataset.i)].on; refreshSub(); break;
    case 'pldayapply': {
      const pick = PL.filter((p) => p.on && (p.type === 'task' || p.type === 'study'));
      if (!pick.length) return toast('Koi item select nahi');
      if (!confirm(`${pick.length} items ko aaj ke diye time pe set karein?`)) return;
      let made = 0;
      pick.forEach((p) => {
        if (p.type === 'task' && p.id) upd('tasks', p.id, { due: todayKey(), dueTime: p.time });
        else {
          const m = p.meta || {};
          add('tasks', { title: p.title, kind: 'study', prio: 'med', due: todayKey(), dueTime: p.time, repeat: 'none', rem: 10, done: false, subs: [], note: m.chapter || '' });
          made++;
        }
      });
      N.sync(); toast(made ? `Planner ka time lag gaya · ${made} naye session bane` : 'Planner ka time lag gaya'); break;
    }
    case 'plresched': {
      const od = taskGroups().overdue; if (!confirm(`${od.length} bakaya tasks kal pe shift karein? Koi task delete nahi hoga.`)) return;
      od.forEach((t) => upd('tasks', t.id, { due: addDaysY(todayKey(), 1) })); N.sync(); refreshSub(); break;
    }
    case 'plsplit': splitTask(); break;
    case 'setmode': saveMe({ mode: v }); window.dispatchEvent(new Event('nnn-mode')); refreshSub(); break;
    case 'setlang': store.set('nnn_lang', v); window.dispatchEvent(new Event('nnn-lang')); refreshSub(); break;
    case 'a11y': { const o = store.json('nnn_a11y', {}); o[v] = flip(); store.setJson('nnn_a11y', o); applyA11y(); refreshSub(); break; }
    case 'privonline': saveMe({ privacy: { ...(S.me.privacy || {}), online: flip() } }); refreshSub(); break;
    case 'nprefs': { N.setPrefs({ ...N.getPrefs(), [v]: flip() }); refreshSub(); break; }
    case 'notifask': { const r = await N.askPermission(); toast(r === 'granted' ? 'Notifications chalu' : 'Allow nahi hua'); N.sync(); refreshSub(); break; }
    case 'nhist': openSub('Notification history', (bd) => { const h = N.getHistory(); bd.innerHTML = (h.length ? h.map((x) => `<div class="plrow"><span class="mono">${new Date(x.ts).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span><b>${esc(x.title)}</b></div>`).join('') : emptyBox('Abhi koi notification history nahi.')) + (h.length ? '<button class="btn soft" data-act="nhclear">Clear karo</button>' : ''); }); break;
    case 'nhclear': N.clearHistory(); refreshSub(); break;
    case 'nup': openSub('Aane wale reminders', (bd) => { const u = N.upcomingReminders(); bd.innerHTML = u.length ? u.map((x) => `<div class="plrow"><span class="mono">${new Date(x.at).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</span><b>${esc(x.title)}</b><button class="chip sm" data-act="nsnooze" data-k="${esc(x.key)}" data-t="${esc(x.title)}">Snooze</button></div>`).join('') : emptyBox('Koi reminder scheduled nahi.'); }); break;
    case 'nsnooze': N.snooze({ key: b.dataset.k, title: b.dataset.t, body: 'Snoozed' }); break;
    case 'exp':
      if (v === 'json') exportFile('nnn-backup.json', 'application/json', backupJSON());
      else if (v === 'csv') exportFile('nnn-data.csv', 'text/csv', toCSV());
      else if (v === 'ics') (await import('./life.js')).exportICS();
      else printReport();
      break;
    case 'restore': restore(); break;
    case 'pinset': pinMode = 'set'; pinBuf = ''; paintLock(); $('#lock').classList.remove('hidden'); break;
    case 'pinoff': if (confirm('App lock hata dein?')) { store.set('nnn_pin', ''); try { localStorage.removeItem('nnn_pin'); } catch { /* ignore */ } refreshSub(); } break;
    case 'pinkey': pinKey(v); break;
    case 'pincancel': $('#lock').classList.add('hidden'); pinBuf = ''; break;
    case 'pinforgot': { try { localStorage.removeItem('nnn_pin'); } catch { /* ignore */ } $('#lock').classList.add('hidden'); window.dispatchEvent(new Event('nnn-logout')); break; }
  }
});
