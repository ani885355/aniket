/* Adult/life: events, universal calendar, notes + journal, global search, .ics export */
import {
  $, $$, esc, S, D, toast, ic, P, add, upd, del, find, openSub, refreshSub, formSheet, seg, emptyBox, dot, exportFile,
  todayKey, addDaysY, fromYmd, ymd, fmtD, fmtDW, fmtDY, rel, pad, WD, daysBetween, occurrences, addDays, dt
} from './core.js';
import { sync as syncNotif } from './notify.js';
import { taskForm } from './tasks.js';
import { examForm } from './study.js';

/* ================= EVENTS ================= */
export const EV_CATS = {
  birthday: ['Birthday', '#FF8FB1'], anniversary: ['Anniversary', '#F0A58A'], wedding: ['Wedding', '#E8B96F'], family: ['Family function', '#B7A6E0'],
  meeting: ['Meeting', '#8FB8DE'], appointment: ['Appointment', '#9AD1B5'], office: ['Office deadline', '#F2C94C'], bill: ['Bill payment', '#FF9A8A'],
  subscription: ['Subscription renewal', '#C8F23A'], travel: ['Travel', '#7FD1D1'], medical: ['Medical', '#E58F8F'], personal: ['Personal', '#A2A496']
};
const catColor = (c) => (EV_CATS[c] || EV_CATS.personal)[1];
const REMS = [['0', 'Event wale din'], ['1440', '1 din pehle'], ['4320', '3 din pehle'], ['10080', '1 hafta pehle'], ['43200', '1 mahina pehle']];
export function eventForm(id, preset = {}) {
  const e = id ? find('events', id) : null;
  formSheet({
    title: e ? 'Event edit' : 'Naya event', values: e ? { ...e, rem: (e.rem || []).map(String) } : { cat: 'personal', date: todayKey(), repeat: 'none', rem: ['0', '1440'], ...preset },
    fields: [
      { k: 'title', l: 'Title', req: 1, max: 60 },
      { k: 'cat', l: 'Category', t: 'select', o: Object.entries(EV_CATS).map(([k, v]) => [k, v[0]]) },
      { k: 'date', l: 'Date', t: 'date', req: 1 }, { k: 'time', l: 'Time', t: 'time' },
      { k: 'repeat', l: 'Repeat (birthday/anniversary me auto yearly)', t: 'select', o: [['none', 'Nahi'], ['daily', 'Roz'], ['weekly', 'Har hafte'], ['monthly', 'Har mahine'], ['yearly', 'Har saal']] },
      { k: 'loc', l: 'Location', max: 80 },
      { k: 'rem', l: 'Reminders', t: 'chips', multi: true, o: REMS },
      { k: 'remCustomDate', l: 'Custom reminder date', t: 'date' }, { k: 'remCustomTime', l: 'Custom reminder time', t: 'time' },
      { k: 'desc', l: 'Description', t: 'textarea', max: 400 }, { k: 'notes', l: 'Notes', t: 'textarea', max: 600 },
      { k: 'link', l: 'Attachment link', max: 200, ph: 'https://...' }
    ],
    onSave: (f) => {
      const data = { ...f, rem: (f.rem || []).map(Number) };
      if (['birthday', 'anniversary'].includes(data.cat) && data.repeat === 'none') data.repeat = 'yearly';
      if (e) upd('events', e.id, data); else add('events', data);
      syncNotif();
    },
    onDelete: e ? () => { del('events', e.id); syncNotif(); } : null
  });
}
function evRow(x, date) {
  const n = daysBetween(todayKey(), date);
  return `<div class="exrow" data-act="evedit" data-id="${x.id}"><div class="exd" style="--c:${catColor(x.cat)}"><b>${fromYmd(date).getDate()}</b><span class="mono">${fromYmd(date).toLocaleDateString('en-IN', { month: 'short' })}</span></div>
<div class="tmain"><b>${esc(x.title)}</b><div class="tmeta mono">${dot(catColor(x.cat))}${(EV_CATS[x.cat] || EV_CATS.personal)[0]}${x.time ? ' · ' + x.time : ''}${x.loc ? ' · ' + esc(x.loc) : ''}${x.repeat && x.repeat !== 'none' ? ' · ↻' : ''}</div></div>
<div class="cd ${n <= 1 ? 'hot' : ''}"><b>${n}</b><span class="mono">${n === 0 ? 'aaj' : 'din'}</span></div></div>`;
}
export function upcomingEvents(days = 30) {
  const t0 = todayKey(), to = addDaysY(t0, days), out = [];
  D.events.forEach((x) => occurrences(x, t0, to).forEach((d) => out.push({ x, d })));
  return out.sort((a, b) => (a.d + (a.x.time || '')).localeCompare(b.d + (b.x.time || '')));
}
export function openEvents() { openSub('Events', renderEvents, `<button class="addbtn" data-act="evadd" aria-label="Event add">${ic(P.plus, 20, 2)}</button>`); }
function renderEvents(body) {
  const up = upcomingEvents(60);
  body.innerHTML = `<div class="chips scrollx">${Object.entries(EV_CATS).map(([k, v]) => `<button class="chip" data-act="evadd" data-v="${k}">${v[0]}</button>`).join('')}</div>
<div class="mono lbl">AAGE 60 DIN · ${up.length}</div>${up.length ? up.map(({ x, d }) => evRow(x, d)).join('') : emptyBox('Koi event nahi. Birthday, bill, meeting ya appointment add karo.')}`;
}
export function lifePageHTML() {
  const up = upcomingEvents(30), t0 = todayKey();
  const today = up.filter((u) => u.d === t0), bills = up.filter((u) => ['bill', 'subscription'].includes(u.x.cat)).slice(0, 4), bd = up.filter((u) => ['birthday', 'anniversary'].includes(u.x.cat)).slice(0, 4);
  return `<div class="phead"><h1>Life</h1><button class="addbtn" data-act="evadd" aria-label="Event add">${ic(P.plus, 20, 2)}</button></div>
<div class="lime2"><div class="mono lbl-d">AAJ</div><h2>${today.length ? today.length + ' event' + (today.length > 1 ? 's' : '') : 'Aaj khaali din'}</h2><p>${today.length ? esc(today.map((u) => u.x.title).join(', ')) : 'Kuch add karna ho to + dabao.'}</p></div>
<div class="tiles">${[['events', 'Events', `${up.length} agle 30 din`], ['calendar', 'Calendar', 'Month / week / day'], ['tasks', 'Tasks', `${D.tasks.filter((t) => !t.done).length} pending`], ['notes', 'Notes', `${D.notes.length} notes`]].map(([k, l, s]) => `<button class="tile" data-act="lifeopen" data-v="${k}"><b>${l}</b><span class="mono">${s}</span></button>`).join('')}</div>
${bills.length ? `<div class="mono lbl">BILLS &amp; RENEWALS</div>${bills.map(({ x, d }) => evRow(x, d)).join('')}` : ''}
${bd.length ? `<div class="mono lbl">BIRTHDAYS &amp; ANNIVERSARIES</div>${bd.map(({ x, d }) => evRow(x, d)).join('')}` : ''}
<div class="mono lbl">UPCOMING</div>${up.length ? up.slice(0, 6).map(({ x, d }) => evRow(x, d)).join('') : emptyBox('Agle 30 din me kuch nahi.')}`;
}

/* ================= UNIVERSAL CALENDAR ================= */
const TYPE = { exam: ['Exams', '#FF9A8A'], task: ['Tasks', '#C8F23A'], study: ['Study', '#8FB8DE'], event: ['Events', '#B7A6E0'], routine: ['Routine', '#A2A496'] };
let cv = 'month', cAnchor = null, cFilter = 'all', cQ = '';
export function calItems(from, to) {
  const out = [];
  D.exams.filter((x) => x.date >= from && x.date <= to).forEach((x) => out.push({ date: x.date, time: x.start || '', title: 'Exam: ' + (x.subject || x.name), type: 'exam', color: TYPE.exam[1], ref: ['exam', x.id] }));
  D.tasks.filter((t) => t.due && t.due >= from && t.due <= to).forEach((t) => out.push({ date: t.due, time: t.dueTime || '', title: t.title, type: ['study', 'revision', 'homework', 'assignment', 'test'].includes(t.kind) ? 'study' : 'task', color: ['study', 'revision', 'homework', 'assignment', 'test'].includes(t.kind) ? TYPE.study[1] : TYPE.task[1], done: t.done, ref: ['task', t.id] }));
  D.events.forEach((x) => occurrences(x, from, to).forEach((d) => out.push({ date: d, time: x.time || '', title: x.title, type: 'event', color: catColor(x.cat), cat: x.cat, ref: ['event', x.id] })));
  if (S.me && S.me.schedule && from === to) (S.me.schedule || []).filter((i) => i.on).forEach((i) => out.push({ date: from, time: i.time, title: i.title, type: 'routine', color: TYPE.routine[1], ref: null }));
  return out.filter((i) => (cFilter === 'all' || i.type === cFilter) && (!cQ || i.title.toLowerCase().includes(cQ.toLowerCase()))).sort((a, b) => (a.date + (a.time || '99')).localeCompare(b.date + (b.time || '99')));
}
export function openCalendar() { cAnchor = cAnchor || todayKey(); cv = 'month'; openSub('Calendar', renderCalendar, `<button class="addbtn" data-act="evadd" aria-label="Event add">${ic(P.plus, 20, 2)}</button>`); }
const calRow = (i) => `<div class="plrow ${i.done ? 'done' : ''}" ${i.ref ? `data-act="calopen" data-t="${i.ref[0]}" data-id="${i.ref[1]}"` : ''}>${dot(i.color)}<span class="mono">${i.time || '--:--'}</span><b>${esc(i.title)}</b><em class="mono">${i.type}</em></div>`;
function renderCalendar(body) {
  const a = fromYmd(cAnchor), t0 = todayKey();
  let inner = '', title = '';
  if (cv === 'month') {
    const y = a.getFullYear(), m = a.getMonth(), first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate();
    title = a.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
    const all = calItems(`${y}-${pad(m + 1)}-01`, `${y}-${pad(m + 1)}-${pad(days)}`);
    let cells = '<i></i>'.repeat(first);
    for (let d = 1; d <= days; d++) {
      const ds = `${y}-${pad(m + 1)}-${pad(d)}`, its = all.filter((i) => i.date === ds);
      cells += `<button class="c cc ${ds === t0 ? 'today' : ''} ${ds === cAnchor ? 'sel' : ''}" data-act="calday" data-v="${ds}">${d}<span class="dots">${its.slice(0, 3).map((i) => `<i style="background:${i.color}"></i>`).join('')}</span></button>`;
    }
    inner = `<div class="grid7">${WD.map((w) => `<span class="mono lbl">${w[0]}</span>`).join('')}${cells}</div><div class="mono lbl">${fmtDW(cAnchor).toUpperCase()}</div>${calItems(cAnchor, cAnchor).map(calRow).join('') || '<div class="plrow empty-s mono">Is din kuch nahi</div>'}`;
  } else if (cv === 'week') {
    const s = addDays(a, -a.getDay()); title = `${fmtD(ymd(s))} – ${fmtD(ymd(addDays(s, 6)))}`;
    inner = Array.from({ length: 7 }, (_, i) => { const d = ymd(addDays(s, i)); return `<div class="mono lbl ${d === t0 ? 'nowl' : ''}">${fmtDW(d).toUpperCase()}</div>${calItems(d, d).map(calRow).join('') || '<div class="plrow empty-s mono">-</div>'}`; }).join('');
  } else if (cv === 'day') {
    title = fmtDY(cAnchor); inner = calItems(cAnchor, cAnchor).map(calRow).join('') || emptyBox('Is din kuch planned nahi.');
  } else {
    title = 'Agenda · agle 30 din';
    const items = calItems(t0, addDaysY(t0, 30)); let last = '';
    inner = items.length ? items.map((i) => { const h = i.date !== last ? `<div class="mono lbl">${i.date === t0 ? 'AAJ' : fmtDW(i.date).toUpperCase()}</div>` : ''; last = i.date; return h + calRow(i); }).join('') : emptyBox('Agle 30 din khaali.');
  }
  body.innerHTML = `${seg([['month', 'Month'], ['week', 'Week'], ['day', 'Day'], ['agenda', 'Agenda']], cv, 'calview')}
<div class="cal-h"><button class="ibtn" data-act="calnav" data-v="-1" aria-label="Pehle">${ic(P.back, 18, 2)}</button><b>${title}</b><button class="ibtn" data-act="calnav" data-v="1" aria-label="Aage">${ic(P.arrow, 18, 2)}</button></div>
<div class="chips scrollx"><button class="chip" data-act="calfilter" data-v="all" aria-pressed="${cFilter === 'all'}">All</button>${Object.entries(TYPE).map(([k, v]) => `<button class="chip" data-act="calfilter" data-v="${k}" aria-pressed="${cFilter === k}">${dot(v[1])}${v[0]}</button>`).join('')}</div>
<input class="emo-q" id="cal-q" placeholder="Calendar me khojo" value="${esc(cQ)}" autocomplete="off">${inner}`;
  const q = $('#cal-q'); q.onchange = () => { cQ = q.value.trim(); refreshSub(); };
}
function calNav(n) {
  const a = fromYmd(cAnchor);
  if (cv === 'month') cAnchor = ymd(new Date(a.getFullYear(), a.getMonth() + n, 1));
  else cAnchor = ymd(addDays(a, n * (cv === 'week' ? 7 : 1)));
  refreshSub();
}

/* ================= NOTES ================= */
const NKINDS = [['quick', 'Quick'], ['study', 'Study'], ['journal', 'Journal'], ['link', 'Links']];
let nKind = 'all', nQ = '';
export function openNotes() { nKind = 'all'; nQ = ''; openSub('Notes', renderNotes, `<button class="addbtn" data-act="noteadd" aria-label="Note add">${ic(P.plus, 20, 2)}</button>`); }
export function mdLite(t) {
  const lines = esc(t).split('\n'); let out = '', list = false;
  const inl = (s) => s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\*(.+?)\*/g, '<i>$1</i>').replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
  for (const l of lines) {
    if (/^\s*[-•]\s+/.test(l)) { if (!list) { out += '<ul>'; list = true; } out += `<li>${inl(l.replace(/^\s*[-•]\s+/, ''))}</li>`; }
    else { if (list) { out += '</ul>'; list = false; } out += l.startsWith('# ') ? `<h4>${inl(l.slice(2))}</h4>` : l.trim() ? `<p>${inl(l)}</p>` : ''; }
  }
  return out + (list ? '</ul>' : '');
}
function renderNotes(body) {
  let list = D.notes.filter((n) => (nKind === 'all' || n.kind === nKind) && (!nQ || (n.title + ' ' + n.body + ' ' + (n.tags || []).join(' ')).toLowerCase().includes(nQ.toLowerCase())));
  list.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || (b.updated || 0) - (a.updated || 0));
  body.innerHTML = `<input class="emo-q" id="note-q" placeholder="Notes khojo (title, text, tag)" value="${esc(nQ)}" autocomplete="off">
<div class="chips scrollx"><button class="chip" data-act="notekind" data-v="all" aria-pressed="${nKind === 'all'}">All</button>${NKINDS.map(([k, l]) => `<button class="chip" data-act="notekind" data-v="${k}" aria-pressed="${nKind === k}">${l}</button>`).join('')}</div>
${list.length ? list.map((n) => `<div class="note" data-act="noteopen" data-id="${n.id}">${n.pinned ? `<span class="pin">${ic(P.pin, 14, 2)}</span>` : ''}<b>${esc(n.title || 'Untitled')}</b><div class="tdesc">${esc((n.body || '').slice(0, 120))}</div><div class="tmeta mono">${(NKINDS.find((k) => k[0] === n.kind) || [0, 'Quick'])[1]}${(n.tags || []).map((t) => ' #' + esc(t)).join('')}${n.cat ? ' · ' + esc(n.cat) : ''}</div></div>`).join('') : emptyBox('Koi note nahi. Quick note, study note ya journal likho.')}`;
  const q = $('#note-q'); q.onchange = () => { nQ = q.value.trim(); refreshSub(); };
}
function noteForm(id, preset = {}) {
  const n = id ? find('notes', id) : null;
  formSheet({
    title: n ? 'Note edit' : 'Naya note', values: n ? { ...n, tags: (n.tags || []).join(', ') } : { kind: 'quick', ...preset },
    fields: [{ k: 'title', l: 'Title', max: 60 }, { k: 'kind', l: 'Type', t: 'chips', o: NKINDS },
      { k: 'body', l: 'Likho (**bold**, *italic*, - list, # heading)', t: 'textarea', rows: 7, max: 5000 },
      { k: 'tags', l: 'Tags (comma se)', max: 60 }, { k: 'cat', l: 'Category', max: 20 }, { k: 'url', l: 'Link / PDF ka link', max: 200 },
      { k: 'pinned', l: 'Pin karo', t: 'check' }],
    onSave: (f) => { const data = { ...f, kind: f.kind || 'quick', tags: String(f.tags || '').split(',').map((t) => t.trim().replace(/^#/, '')).filter(Boolean).slice(0, 6), updated: Date.now() }; if (n) upd('notes', n.id, data); else add('notes', data); },
    onDelete: n ? () => del('notes', n.id) : null
  });
}
function viewNote(id) {
  openSub('Note', (body) => {
    const n = find('notes', id); if (!n) { body.innerHTML = emptyBox('Note nahi mila'); return; }
    body.innerHTML = `<h2 class="sh-h">${esc(n.title || 'Untitled')}</h2><div class="tmeta mono">${(n.tags || []).map((t) => '#' + esc(t)).join(' ')}</div><div class="md">${mdLite(n.body || '')}</div>${/^https?:\/\//i.test(n.url || '') ? `<a class="btn soft" href="${esc(n.url)}" target="_blank" rel="noopener noreferrer">Link kholo</a>` : ''}`;
  }, `<button class="addbtn" data-act="noteedit" data-id="${id}" aria-label="Edit">${ic(P.edit, 18, 2)}</button>`);
}

/* ================= GLOBAL SEARCH ================= */
let gq = '';
export function openSearch() { gq = ''; openSub('Search', renderSearch); }
function renderSearch(body) {
  const q = gq.toLowerCase(), has = (s) => String(s || '').toLowerCase().includes(q);
  const res = !q ? [] : [
    ...D.tasks.filter((t) => has(t.title) || has(t.desc)).map((t) => ['Task', t.title, 'task', t.id]),
    ...D.notes.filter((n) => has(n.title) || has(n.body) || (n.tags || []).some(has)).map((n) => ['Note', n.title || 'Untitled', 'note', n.id]),
    ...D.events.filter((e) => has(e.title) || has(e.notes) || has(e.loc)).map((e) => ['Event', e.title, 'event', e.id]),
    ...D.exams.filter((x) => has(x.subject) || has(x.name)).map((x) => ['Exam', x.subject || x.name, 'exam', x.id]),
    ...D.subjects.flatMap((s) => [has(s.name) ? ['Subject', s.name, 'subject', s.id] : null, ...(s.chapters || []).filter((c) => has(c.name)).map((c) => ['Chapter', `${c.name} (${s.name})`, 'subject', s.id])].filter(Boolean))
  ].slice(0, 40);
  body.innerHTML = `<input class="emo-q" id="gs-q" placeholder="Task, note, event, exam, chapter..." value="${esc(gq)}" autocomplete="off">
${q ? (res.length ? res.map(([k, t, ty, id]) => `<div class="plrow" data-act="calopen" data-t="${ty}" data-id="${id}"><em class="mono">${k}</em><b>${esc(t)}</b></div>`).join('') : emptyBox('Kuch nahi mila.')) : emptyBox('Kuch likho aur khojo.')}`;
  const i = $('#gs-q'); i.oninput = () => { gq = i.value; const pos = i.selectionStart; renderSearch(body); const n = $('#gs-q'); n.focus(); n.setSelectionRange(pos, pos); };
  if (!q) setTimeout(() => $('#gs-q') && $('#gs-q').focus(), 60);
}
export function openRef(t, id) {
  if (t === 'task') taskForm(id); else if (t === 'event') eventForm(id); else if (t === 'exam') examForm(id); else if (t === 'note') viewNote(id);
  else if (t === 'subject') import('./study.js').then((m) => m.openStudyItem('syllabus'));
}

/* ================= ICS export ================= */
export function exportICS() {
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
  const dtv = (d, t) => d.replace(/-/g, '') + (t ? 'T' + t.replace(':', '') + '00' : '');
  const ev = [];
  D.events.forEach((x) => ev.push(['NNN-ev-' + x.id, x.title, x.date, x.time, x.loc, x.desc, { daily: 'DAILY', weekly: 'WEEKLY', monthly: 'MONTHLY', yearly: 'YEARLY' }[x.repeat], null]));
  D.exams.forEach((x) => ev.push(['NNN-ex-' + x.id, 'Exam: ' + (x.subject || x.name), x.date, x.start, x.loc, x.notes, null, x.end]));
  const f = (s) => String(s || '').replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/[,;]/g, (c) => '\\' + c);
  const txt = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Peanut//EN', ...ev.flatMap(([uid, title, d, t, loc, desc, rr, end]) => [
    'BEGIN:VEVENT', `UID:${uid}@nnn`, `DTSTAMP:${stamp}`, t ? `DTSTART:${dtv(d, t)}` : `DTSTART;VALUE=DATE:${dtv(d)}`, t && end ? `DTEND:${dtv(d, end)}` : '', `SUMMARY:${f(title)}`, loc ? `LOCATION:${f(loc)}` : '', desc ? `DESCRIPTION:${f(desc)}` : '', rr ? `RRULE:FREQ=${rr}` : '', 'END:VEVENT']), 'END:VCALENDAR'].filter(Boolean).join('\r\n');
  return exportFile('nnn-calendar.ics', 'text/calendar', txt);
}

/* ================= click handling ================= */
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v;
  switch (a) {
    case 'evadd': eventForm(null, v ? { cat: v } : {}); break;
    case 'evedit': eventForm(id); break;
    case 'lifeopen': ({ events: openEvents, calendar: openCalendar, notes: openNotes, tasks: () => import('./tasks.js').then((m) => m.openTasks()) })[v](); break;
    case 'calview': cv = v; refreshSub(); break;
    case 'calnav': calNav(Number(v)); break;
    case 'calday': cAnchor = v; refreshSub(); break;
    case 'calfilter': cFilter = v; refreshSub(); break;
    case 'calopen': openRef(b.dataset.t, id); break;
    case 'noteadd': noteForm(null); break;
    case 'noteedit': noteForm(id); break;
    case 'noteopen': viewNote(id); break;
    case 'notekind': nKind = v; refreshSub(); break;
  }
});
