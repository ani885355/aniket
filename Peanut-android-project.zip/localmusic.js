/* ============================================================
   localmusic.js — device se apne gaane.

   Audio blobs IndexedDB me store hote hain, isliye reload ke baad
   bhi gaane wahin rehte hain (localStorage me binary nahi ja sakta).
   Har track ko ek channel se jod sakte ho — us channel pe wahi
   gaana bajega.
   ============================================================ */
const DB_NAME = 'peanut-audio', STORE = 'tracks';
let dbP = null;

function openDB() {
  if (dbP) return dbP;
  dbP = new Promise((res, rej) => {
    if (!('indexedDB' in window)) return rej(new Error('no-idb'));
    const r = indexedDB.open(DB_NAME, 1);
    r.onupgradeneeded = () => { const d = r.result; if (!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE, { keyPath: 'id' }); };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  return dbP;
}
const tx = async (mode, fn) => {
  const db = await openDB();
  return new Promise((res, rej) => {
    const t = db.transaction(STORE, mode), s = t.objectStore(STORE);
    let out;
    try { out = fn(s); } catch (e) { rej(e); return; }
    t.oncomplete = () => res(out && out.result !== undefined ? out.result : out);
    t.onerror = () => rej(t.error);
  });
};

const parseName = (fileName) => {
  const base = fileName.replace(/\.[a-z0-9]+$/i, '');
  const m = base.match(/^(.+?)\s+-\s+(.+)$/);
  if (m) return { artist: m[1].trim(), title: m[2].trim() };
  return { artist: 'Local', title: base.trim() || 'Track' };
};

/* files: FileList | File[] */
export async function addFiles(files) {
  const list = [...files].filter((f) => f && (f.type.startsWith('audio/') || /\.(mp3|m4a|aac|wav|ogg|flac|opus|webm)$/i.test(f.name)));
  if (!list.length) return [];
  const added = [];
  for (const f of list) {
    const id = 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const { artist, title } = parseName(f.name);
    const rec = { id, name: title, artist, file: f.name, size: f.size, added: Date.now(), blob: f };
    await tx('readwrite', (s) => s.put(rec));
    added.push({ ...rec, blob: undefined });
  }
  return added;
}

export async function listTracks() {
  try {
    const all = await tx('readonly', (s) => s.getAll());
    return (all || []).sort((a, b) => b.added - a.added).map(({ blob, ...m }) => m);
  } catch { return []; }
}
export async function getBlob(id) {
  try {
    const r = await tx('readonly', (s) => s.get(id));
    return r && r.blob ? r.blob : null;
  } catch { return null; }
}
export async function removeTrack(id) {
  try { await tx('readwrite', (s) => s.delete(id)); return true; } catch { return false; }
}
export async function clearAll() {
  try { await tx('readwrite', (s) => s.clear()); return true; } catch { return false; }
}

/* ---------- playback ---------- */
let audioEl = null, curId = null, listeners = new Set();
export const onChange = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((f) => { try { f(curId); } catch (e) { console.warn(e); } });

export function current() { return curId; }
export function isPlaying() { return !!(audioEl && !audioEl.paused); }

export async function play(id) {
  const blob = await getBlob(id);
  if (!blob) return false;
  if (!audioEl) {
    audioEl = new Audio();
    audioEl.onended = () => { curId = null; emit(); };
    audioEl.onplay = emit; audioEl.onpause = emit;
  }
  if (audioEl.src) URL.revokeObjectURL(audioEl.src);
  audioEl.src = URL.createObjectURL(blob);
  curId = id;
  try { await audioEl.play(); } catch { /* autoplay block */ }
  emit();
  return true;
}
export function pause() { if (audioEl) audioEl.pause(); emit(); }
export function toggle(id) { if (curId === id && isPlaying()) { pause(); return false; } return play(id); }
export function stop() { if (audioEl) { audioEl.pause(); } curId = null; emit(); }
