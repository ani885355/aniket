/* ============================================================
   music.js — per-community music.

   Har room (community) ka apna channel hota hai. Room me jo
   bhi log hain, unke liye wahi channel chalta hai — aur alag
   alag rooms ka channel alag hota hai (room code se hash).

   Saara audio original WebAudio synthesis hai (koi copyrighted
   sample nahi), isliye offline bhi chalta hai aur app chhoti
   rehti hai. Bloomee (HemantKArya/BloomeeTunes, GPL-2.0) ke
   player flow se inspired: channel list, per-community mood,
   local files + custom stream URL support.

   Credit: Bloomee — https://github.com/HemantKArya/BloomeeTunes (GPL-2.0)
   ============================================================ */
import {
  $, $$, esc, S, D, store, toast, ic, P, openSub, refreshSub, clamp, saveMe, emptyBox, seg, heroArt, tr
} from './core.js';
import * as LM from './localmusic.js';
import * as OT from './opentune.js';

/* ---------- chord shapes (semitones from chord root) ---------- */
const CH = {
  maj: [0, 4, 7], min: [0, 3, 7], maj7: [0, 4, 7, 11], min7: [0, 3, 7, 10],
  dom7: [0, 4, 7, 10], sus2: [0, 2, 7], sus4: [0, 5, 7], add9: [0, 4, 7, 14],
  min9: [0, 3, 7, 10, 14], maj9: [0, 4, 7, 11, 14]
};

/* ---------- channels ---------- */
/* Do alag-alag sets — Hinglish aur English, dono independent:
   room ka channel kisi bhi set se ho sakta hai, aur local gaana
   kisi bhi channel me lagaya ja sakta hai. */
export const CHANNELS_HI = [
  {
    id: 'lofi', name: 'Lo-Fi Chill', emoji: '🥛', tag: 'Dusty chords, tape hiss, dheema-dheema groove',
    bpm: 78, root: 57, wave: 'triangle', cutoff: 1350, padVol: 0.16, spread: 0.5,
    chords: [[0, 'min9'], [7, 'maj7'], [3, 'min7'], [10, 'maj9']],
    drums: 'lofi', bass: 'soft', arp: { on: 1, div: 2, wave: 'sine', oct: 1, decay: 1.4, density: 0.34 },
    delay: 0.30, reverb: 0.30, colors: ['#E8B96F', '#7A5A33', '#2A2016']
  },
  {
    id: 'night', name: 'Midnight Drive', emoji: '🌙', tag: 'Neon bassline, khaali highway',
    bpm: 92, root: 50, wave: 'sawtooth', cutoff: 900, padVol: 0.11, spread: 0.9,
    chords: [[0, 'min'], [8, 'maj'], [3, 'maj'], [10, 'sus4']],
    drums: 'soft', bass: 'drive', arp: { on: 1, div: 4, wave: 'triangle', oct: 2, decay: 0.9, density: 0.5 },
    delay: 0.38, reverb: 0.36, colors: ['#5B4BA8', '#221C4A', '#0B0820']
  },
  {
    id: 'sunny', name: 'Sunny Side', emoji: '☀️', tag: 'Bright chords, khidki khuli',
    bpm: 104, root: 60, wave: 'triangle', cutoff: 2200, padVol: 0.13, spread: 0.6,
    chords: [[0, 'maj'], [9, 'min'], [5, 'maj'], [7, 'dom7']],
    drums: 'pop', bass: 'bounce', arp: { on: 1, div: 2, wave: 'triangle', oct: 2, decay: 0.7, density: 0.6 },
    delay: 0.22, reverb: 0.22, colors: ['#FFC15E', '#F0803C', '#5A2E12']
  },
  {
    id: 'rain', name: 'Rain Room', emoji: '🌧️', tag: 'Koi drums nahi, bas paani aur hawa',
    bpm: 58, root: 55, wave: 'sine', cutoff: 700, padVol: 0.18, spread: 0.3,
    chords: [[0, 'maj9'], [5, 'maj7'], [7, 'min9'], [3, 'add9']],
    drums: 'none', bass: 'none', arp: { on: 1, div: 8, wave: 'sine', oct: 1, decay: 2.6, density: 0.22 },
    delay: 0.44, reverb: 0.52, colors: ['#7FB0C4', '#33586B', '#101C22']
  },
  {
    id: 'pulse', name: 'Focus Pulse', emoji: '⚡', tag: 'Even beat, koi shock nahi, deep work',
    bpm: 120, root: 52, wave: 'sawtooth', cutoff: 1150, padVol: 0.10, spread: 0.7,
    chords: [[0, 'min7'], [0, 'min7'], [8, 'maj7'], [10, 'min7']],
    drums: 'four', bass: 'steady', arp: { on: 0, div: 0, wave: 'triangle', oct: 1, decay: 0.6, density: 0 },
    delay: 0.16, reverb: 0.14, colors: ['#C8F23A', '#4E7C2E', '#10130A']
  },
  {
    id: 'bloom', name: 'Bloom', emoji: '🌸', tag: 'Arpeggios jo phoolte hain',
    bpm: 100, root: 59, wave: 'triangle', cutoff: 1800, padVol: 0.11, spread: 0.8,
    chords: [[0, 'maj9'], [2, 'min9'], [4, 'maj7'], [7, 'dom7']],
    drums: 'tick', bass: 'pulse', arp: { on: 1, div: 1, wave: 'sine', oct: 2, decay: 1.0, density: 0.8 },
    delay: 0.36, reverb: 0.40, colors: ['#FF8FB1', '#B7A6E0', '#3A1030']
  },
  {
    id: 'zen', name: 'Zen Garden', emoji: '🎋', tag: 'Pentatonic pluck, sab kuch shaant',
    bpm: 68, root: 57, wave: 'sine', cutoff: 1500, padVol: 0.12, spread: 0.45,
    chords: [[0, 'min7'], [2, 'maj7'], [9, 'min7'], [7, 'sus2']],
    drums: 'none', bass: 'soft', arp: { on: 1, div: 2, wave: 'sine', oct: 2, decay: 2.0, density: 0.4 },
    delay: 0.42, reverb: 0.46, colors: ['#9AD1B5', '#4E7C6E', '#16281F']
  },
  {
    id: 'desi', name: 'Desi Lo-Fi', emoji: '🥁', tag: 'Tabla + sitar, desi swaad',
    bpm: 88, root: 56, wave: 'triangle', cutoff: 1600, padVol: 0.12, spread: 0.65,
    chords: [[0, 'min7'], [5, 'min7'], [7, 'maj7'], [10, 'dom7']],
    drums: 'tabla', bass: 'soft', arp: { on: 1, div: 1, wave: 'sine', oct: 2, decay: 0.8, density: 0.55 },
    delay: 0.26, reverb: 0.28, colors: ['#E8A33F', '#A8502A', '#2E160C']
  }
];

export const CHANNELS_EN = [
  {
    id: 'lofi-en', name: 'Lo-Fi Chill', emoji: '🥛', tag: 'Dusty chords, tape hiss and a slow sway',
    bpm: 76, root: 57, wave: 'triangle', cutoff: 1300, padVol: 0.16, spread: 0.5,
    chords: [[0, 'maj9'], [5, 'maj7'], [9, 'min7'], [7, 'dom7']],
    drums: 'lofi', bass: 'soft', arp: { on: 1, div: 2, wave: 'sine', oct: 1, decay: 1.4, density: 0.30 },
    delay: 0.30, reverb: 0.30, colors: ['#E8B96F', '#7A5A33', '#2A2016']
  },
  {
    id: 'night-en', name: 'Neon Nights', emoji: '🌃', tag: 'A synthwave bassline on an empty highway',
    bpm: 94, root: 50, wave: 'sawtooth', cutoff: 950, padVol: 0.11, spread: 0.9,
    chords: [[0, 'min'], [3, 'maj'], [8, 'maj'], [10, 'sus4']],
    drums: 'soft', bass: 'drive', arp: { on: 1, div: 4, wave: 'triangle', oct: 2, decay: 0.9, density: 0.48 },
    delay: 0.38, reverb: 0.36, colors: ['#5B4BA8', '#221C4A', '#0B0820']
  },
  {
    id: 'sunny-en', name: 'Golden Hour', emoji: '🌅', tag: 'Bright major chords with the windows down',
    bpm: 108, root: 60, wave: 'triangle', cutoff: 2250, padVol: 0.13, spread: 0.6,
    chords: [[0, 'maj'], [7, 'maj'], [9, 'min'], [5, 'dom7']],
    drums: 'pop', bass: 'bounce', arp: { on: 1, div: 2, wave: 'triangle', oct: 2, decay: 0.7, density: 0.58 },
    delay: 0.22, reverb: 0.22, colors: ['#FFC15E', '#F0803C', '#5A2E12']
  },
  {
    id: 'rain-en', name: 'Rainy Window', emoji: '🌧️', tag: 'No drums, just rain and soft moving air',
    bpm: 56, root: 55, wave: 'sine', cutoff: 720, padVol: 0.18, spread: 0.3,
    chords: [[0, 'maj9'], [5, 'min7'], [7, 'maj9'], [3, 'add9']],
    drums: 'none', bass: 'none', arp: { on: 1, div: 8, wave: 'sine', oct: 1, decay: 2.6, density: 0.20 },
    delay: 0.44, reverb: 0.52, colors: ['#7FB0C4', '#33586B', '#101C22']
  },
  {
    id: 'pulse-en', name: 'Deep Focus', emoji: '🎯', tag: 'A steady four-on-the-floor for long sessions',
    bpm: 124, root: 52, wave: 'sawtooth', cutoff: 1180, padVol: 0.10, spread: 0.7,
    chords: [[0, 'min7'], [8, 'maj7'], [0, 'min7'], [10, 'maj7']],
    drums: 'four', bass: 'steady', arp: { on: 0, div: 0, wave: 'triangle', oct: 1, decay: 0.6, density: 0 },
    delay: 0.16, reverb: 0.14, colors: ['#C8F23A', '#4E7C2E', '#10130A']
  },
  {
    id: 'bloom-en', name: 'Bloom', emoji: '🌸', tag: 'Arpeggios that open up like flowers',
    bpm: 102, root: 59, wave: 'triangle', cutoff: 1850, padVol: 0.11, spread: 0.8,
    chords: [[0, 'maj9'], [4, 'maj7'], [2, 'min9'], [7, 'dom7']],
    drums: 'tick', bass: 'pulse', arp: { on: 1, div: 1, wave: 'sine', oct: 2, decay: 1.0, density: 0.78 },
    delay: 0.36, reverb: 0.40, colors: ['#FF8FB1', '#B7A6E0', '#3A1030']
  },
  {
    id: 'zen-en', name: 'Quiet Garden', emoji: '🎋', tag: 'Pentatonic plucks and nothing rushed',
    bpm: 66, root: 57, wave: 'sine', cutoff: 1550, padVol: 0.12, spread: 0.45,
    chords: [[0, 'maj7'], [2, 'min7'], [9, 'maj7'], [7, 'sus2']],
    drums: 'none', bass: 'soft', arp: { on: 1, div: 2, wave: 'sine', oct: 2, decay: 2.0, density: 0.38 },
    delay: 0.42, reverb: 0.46, colors: ['#9AD1B5', '#4E7C6E', '#16281F']
  },
  {
    id: 'desi-en', name: 'Desi Beats', emoji: '🥁', tag: 'Tabla grooves and warm sitar melodies',
    bpm: 90, root: 56, wave: 'triangle', cutoff: 1650, padVol: 0.12, spread: 0.65,
    chords: [[0, 'min7'], [7, 'min7'], [5, 'maj7'], [10, 'dom7']],
    drums: 'tabla', bass: 'soft', arp: { on: 1, div: 1, wave: 'sine', oct: 2, decay: 0.8, density: 0.52 },
    delay: 0.26, reverb: 0.28, colors: ['#E8A33F', '#A8502A', '#2E160C']
  }
];

export const CHANNELS = [...CHANNELS_HI, ...CHANNELS_EN];
export const channelById = (id) => CHANNELS.find((c) => c.id === id) || CHANNELS[0];

/* ---------- drum patterns (16-step) ---------- */
const DRUMS = {
  none: { k: [], s: [], h: [] },
  soft: { k: [0, 10], s: [4, 12], h: [2, 6, 10, 14] },
  pop: { k: [0, 8], s: [4, 12], h: [2, 6, 10, 14] },
  four: { k: [0, 4, 8, 12], s: [4, 12], h: [2, 6, 10, 14] },
  tick: { k: [0, 7, 10], s: [4, 12], h: [0, 2, 4, 6, 8, 10, 12, 14] },
  tabla: { k: [0, 4, 8, 12], s: [6, 14], h: [2, 3, 6, 7, 10, 11, 14, 15] }
};
const BASS_PAT = {
  soft: [0, 6, 8, 14], bounce: [0, 4, 8, 12], drive: [0, 3, 6, 8, 11, 14],
  steady: [0, 4, 8, 12], pulse: [0, 3, 6, 8, 11, 14], none: []
};

/* ---------- room code -> channel (deterministic) ---------- */
export function channelForRoom(code) {
  if (!code) return 'lofi';
  let h = 0;
  for (let i = 0; i < code.length; i++) h = (h * 31 + code.charCodeAt(i)) >>> 0;
  return CHANNELS[h % CHANNELS.length].id;
}

/* ---------- procedural cover art (SVG) ---------- */
export function coverArt(ch, size = 92) {
  const [c1, c2, c3] = ch.colors;
  const uid = 'cv' + ch.id;
  let dots = '';
  for (let i = 0; i < 14; i++) {
    const x = (i * 37) % 100, y = (i * 61) % 100, r = 3 + ((i * 13) % 9);
    dots += `<circle cx="${x}" cy="${y}" r="${r}" fill="#fff" opacity="${0.04 + (i % 4) * 0.02}"/>`;
  }
  return `<svg class="cover" viewBox="0 0 100 100" width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
<defs><radialGradient id="${uid}" cx="0.32" cy="0.26" r="0.95">
<stop offset="0" stop-color="${c1}"/><stop offset="0.55" stop-color="${c2}"/><stop offset="1" stop-color="${c3}"/>
</radialGradient></defs>
<rect width="100" height="100" rx="18" fill="url(#${uid})"/>${dots}
<g transform="translate(50 52)" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity="0.62">
<path d="M-16 6 v-9"/><path d="M-6 10 v-18"/><path d="M4 8 v-12"/><path d="M14 10 v-6"/>
</g></svg>`;
}

/* ============================================================
   Audio engine
   ============================================================ */
const LOOKAHEAD = 0.14, TICK_MS = 25, STEPS = 64;
const mf = (m) => 440 * Math.pow(2, (m - 69) / 12);

const Engine = (() => {
  let ctx = null, master = null, comp = null, delay = null, delayFb = null, delayOut = null,
    verb = null, verbOut = null, analyser = null, noiseBuf = null;
  let timer = null, step = 0, nextTime = 0, ch = channelById('lofi'), playing = false;
  let volume = 0.75, rand = mulberry(1234), melody = [];

  function mulberry(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const noise = () => (rand() * 2 - 1);

  function ensure() {
    if (ctx) return true;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.knee.value = 22; comp.ratio.value = 8;
    comp.attack.value = 0.004; comp.release.value = 0.22;
    master = ctx.createGain(); master.gain.value = 0;
    analyser = ctx.createAnalyser(); analyser.fftSize = 256; analyser.smoothingTimeConstant = 0.78;

    /* echo */
    delay = ctx.createDelay(1.5); delay.delayTime.value = ch.delay;
    delayFb = ctx.createGain(); delayFb.gain.value = 0.34;
    delayOut = ctx.createGain(); delayOut.gain.value = 0.5;
    delay.connect(delayFb); delayFb.connect(delay); delay.connect(delayOut); delayOut.connect(master);

    /* reverb (generated impulse) */
    verb = ctx.createConvolver(); verb.buffer = impulse(2.6, 2.4);
    verbOut = ctx.createGain(); verbOut.gain.value = 0.5;
    verb.connect(verbOut); verbOut.connect(master);

    master.connect(comp); comp.connect(analyser); analyser.connect(ctx.destination);

    /* noise buffer for drums */
    noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const nd = noiseBuf.getChannelData(0);
    for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
    return true;
  }
  function impulse(dur, decay) {
    const len = Math.floor(ctx.sampleRate * dur);
    const buf = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = buf.getChannelData(c);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay);
    }
    return buf;
  }

  /* --- voices --- */
  function env(g, t, a, d, peak) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
  }
  function tone(freq, t, dur, type, vol, dest, detune = 0) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.value = freq; o.detune.value = detune;
    env(g, t, Math.min(0.05, dur * 0.15), dur, vol);
    o.connect(g); g.connect(dest || master);
    o.start(t); o.stop(t + dur + 0.08);
  }
  function pluck(freq, t, dur, type, vol, sendDelay = 0.5, sendVerb = 0.3) {
    const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
    o.type = type; o.frequency.value = freq;
    f.type = 'lowpass'; f.frequency.setValueAtTime(Math.min(9000, freq * 9), t);
    f.frequency.exponentialRampToValueAtTime(Math.max(220, freq * 1.6), t + dur);
    env(g, t, 0.008, dur, vol);
    o.connect(f); f.connect(g); g.connect(master);
    if (sendDelay > 0) { const s = ctx.createGain(); s.gain.value = sendDelay; g.connect(s); s.connect(delay); }
    if (sendVerb > 0) { const s = ctx.createGain(); s.gain.value = sendVerb; g.connect(s); s.connect(verb); }
    o.start(t); o.stop(t + dur + 0.1);
  }
  function kick(t, vol = 0.85) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine';
    o.frequency.setValueAtTime(135, t);
    o.frequency.exponentialRampToValueAtTime(42, t + 0.13);
    env(g, t, 0.004, 0.28, vol);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.4);
  }
  function snare(t, vol = 0.32) {
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 1500;
    const g = ctx.createGain(); env(g, t, 0.003, 0.17, vol);
    s.connect(f); f.connect(g); g.connect(master);
    const sg = ctx.createGain(); sg.gain.value = 0.25; g.connect(sg); sg.connect(verb);
    s.start(t); s.stop(t + 0.3);
  }
  function hat(t, vol = 0.14, open = false) {
    const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const f = ctx.createBiquadFilter(); f.type = 'highpass'; f.frequency.value = 7000;
    const g = ctx.createGain(); env(g, t, 0.002, open ? 0.2 : 0.045, vol);
    s.connect(f); f.connect(g); g.connect(master); s.start(t); s.stop(t + 0.3);
  }
  function tabla(t, kind) {
    if (kind === 's') { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'triangle'; o.frequency.setValueAtTime(320, t); o.frequency.exponentialRampToValueAtTime(190, t + 0.12); env(g, t, 0.003, 0.16, 0.26); o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.3); return; }
    if (kind === 'k') { kick(t, 0.6); return; }
    hat(t, 0.11, kind === 'o');
  }

  /* --- arrangement --- */
  function chordAt(bar) {
    const c = ch.chords[bar % ch.chords.length];
    return CH[c[1]] || CH.min;
  }
  function barRoot(bar) {
    const c = ch.chords[bar % ch.chords.length];
    return ch.root + c[0];
  }
  function scaleNote(base, deg) {
    const sc = [0, 2, 3, 5, 7, 8, 10, 12, 14, 15, 17, 19];
    const o = sc[((deg % sc.length) + sc.length) % sc.length];
    const oct = Math.floor(deg / sc.length) * 12;
    return base + o + oct;
  }

  function scheduleStep(s, t) {
    const bar = Math.floor(s / 16), inBar = s % 16;
    const semi = 60 / ch.bpm / 4;
    const root = barRoot(bar), notes = chordAt(bar);

    /* pad — new chord each bar */
    if (inBar === 0) {
      const sp = ch.spread;
      notes.forEach((n, i) => {
        const f = mf(root + n + 12);
        const det = (i - (notes.length - 1) / 2) * 5 * sp;
        const g = ctx.createGain(); g.gain.value = 0;
        const filt = ctx.createBiquadFilter(); filt.type = 'lowpass';
        filt.frequency.setValueAtTime(ch.cutoff * 0.55, t);
        filt.frequency.linearRampToValueAtTime(ch.cutoff, t + semi * 8);
        filt.frequency.linearRampToValueAtTime(ch.cutoff * 0.6, t + semi * 16);
        g.gain.setValueAtTime(0.0001, t);
        g.gain.linearRampToValueAtTime(ch.padVol, t + semi * 2);
        g.gain.linearRampToValueAtTime(ch.padVol * 0.8, t + semi * 15);
        g.gain.linearRampToValueAtTime(0.0001, t + semi * 16.4);
        const o = ctx.createOscillator(); o.type = ch.wave; o.frequency.value = f; o.detune.value = det;
        o.connect(filt); filt.connect(g); g.connect(master);
        const sd = ctx.createGain(); sd.gain.value = 0.28; g.connect(sd); sd.connect(delay);
        const sv = ctx.createGain(); sv.gain.value = 0.4; g.connect(sv); sv.connect(verb);
        o.start(t); o.stop(t + semi * 17);
      });
      /* bass note */
      const bp = BASS_PAT[ch.bass] || [];
      if (bp.length && inBar === 0) {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = ch.bass === 'drive' ? 'sawtooth' : 'sine';
        o.frequency.value = mf(root - 12);
        env(g, t, 0.01, semi * 6, ch.bass === 'drive' ? 0.2 : 0.26);
        const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 420;
        o.connect(f); f.connect(g); g.connect(master);
        o.start(t); o.stop(t + semi * 8);
      }
    }
    /* bass pattern */
    if (ch.bass !== 'none') {
      const bp = BASS_PAT[ch.bass] || [];
      if (bp.includes(inBar) && inBar !== 0) {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.type = ch.bass === 'drive' ? 'sawtooth' : 'sine';
        o.frequency.value = mf(root - 12 + (ch.bass === 'bounce' && inBar % 3 === 0 ? 7 : 0));
        env(g, t, 0.008, semi * 2.6, ch.bass === 'drive' ? 0.18 : 0.22);
        const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 520;
        o.connect(f); f.connect(g); g.connect(master);
        o.start(t); o.stop(t + semi * 4);
      }
    }
    /* drums */
    const dp = DRUMS[ch.drums] || DRUMS.none;
    if (dp.k.includes(inBar)) kick(t, ch.drums === 'four' ? 0.8 : 0.62);
    if (dp.s.includes(inBar)) {
      if (ch.drums === 'tabla') tabla(t, 's');
      else snare(t, ch.drums === 'four' ? 0.3 : 0.22);
    }
    if (dp.h.includes(inBar)) {
      if (ch.drums === 'tabla') tabla(t, inBar % 4 === 1 ? 'o' : 'h');
      else hat(t, ch.drums === 'four' ? 0.12 : 0.08);
    }
    /* arp / melody */
    const ar = ch.arp;
    if (ar && ar.on && inBar % ar.div === 0 && rand() < ar.density) {
      if (!melody.length) melody = [0, 2, 4, 2, 6, 4, 2, 0];
      const mv = melody[Math.floor(rand() * melody.length)];
      const deg = mv + (rand() < 0.3 ? 2 : 0);
      const f = mf(scaleNote(root, deg) + 12 * ar.oct);
      pluck(f, t, ar.decay, ar.wave, 0.13, 0.55, 0.35);
    }
  }

  function scheduler() {
    if (!ctx) return;
    const spb = 60 / ch.bpm / 4;
    while (nextTime < ctx.currentTime + LOOKAHEAD) {
      try { scheduleStep(step, nextTime); } catch (e) { /* keep the loop alive */ }
      nextTime += spb; step = (step + 1) % STEPS;
    }
  }

  return {
    get ctx() { return ctx; },
    get analyser() { return analyser; },
    get playing() { return playing; },
    get channel() { return ch; },
    setChannel(c) {
      ch = c;
      if (!ctx) return;
      delay.delayTime.setTargetAtTime(c.delay, ctx.currentTime, 0.15);
      verbOut.gain.setTargetAtTime(c.reverb, ctx.currentTime, 0.2);
    },
    start() {
      if (!ensure()) return false;
      if (ctx.state === 'suspended') ctx.resume();
      step = 0; nextTime = ctx.currentTime + 0.08;
      if (!timer) timer = setInterval(scheduler, TICK_MS);
      playing = true;
      master.gain.cancelScheduledValues(ctx.currentTime);
      master.gain.setValueAtTime(0.0001, ctx.currentTime);
      master.gain.linearRampToValueAtTime(volume, ctx.currentTime + 1.1);
      return true;
    },
    stop() {
      playing = false;
      if (timer) { clearInterval(timer); timer = null; }
      if (ctx && master) {
        master.gain.cancelScheduledValues(ctx.currentTime);
        master.gain.setValueAtTime(master.gain.value, ctx.currentTime);
        master.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 0.45);
      }
    },
    setVolume(v) {
      volume = clamp(v, 0, 1);
      if (ctx && playing) master.gain.setTargetAtTime(volume, ctx.currentTime, 0.08);
      store.set('pn_music_vol', String(volume));
    },
    getVolume() { return volume; }
  };
})();

/* ============================================================
   Module API
   ============================================================ */
let roomCode = null, roomCh = null, localOverride = null, rafId = null;
let localTracks = {};         /* channelId -> [{title, src}] */
let streamUrl = null;         /* custom stream for the current room */
const listeners = new Set();
const notify = () => listeners.forEach((f) => { try { f(); } catch (e) { console.warn(e); } });

/* local open-source files: music/manifest.json */
export async function loadLocalTracks() {
  try {
    const r = await fetch('music/manifest.json', { cache: 'no-cache' });
    if (!r.ok) return;
    const j = await r.json();
    if (j && typeof j === 'object') localTracks = j;
  } catch { /* no manifest, synth-only */ }
}

export function currentChannel() {
  const id = localOverride || roomCh || channelForRoom(roomCode);
  return channelById(id);
}
export function isPlaying() { return Engine.playing; }
export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }

export function setRoom(code, chId) {
  roomCode = code || null;
  roomCh = chId || (code ? channelForRoom(code) : null);
  if (!localOverride) Engine.setChannel(currentChannel());
  notify();
}
export function setLocalOverride(chId) {
  localOverride = chId || null;
  Engine.setChannel(currentChannel());
  notify();
}
export function toggle() {
  if (Engine.playing) { Engine.stop(); notify(); return false; }
  const ok = Engine.start();
  if (ok) Engine.setChannel(currentChannel());
  notify();
  return ok;
}
export function stop() {
  Engine.stop();
  notify();
}
export function nextChannel() {
  const list = CHANNELS;
  const i = list.findIndex((c) => c.id === currentChannel().id);
  const nx = list[(i + 1) % list.length];
  setLocalOverride(nx.id);
  if (Engine.playing) { Engine.stop(); Engine.start(); }
  notify();
  return nx;
}
export function playChannel(chId) {
  setLocalOverride(chId);
  if (!Engine.playing) Engine.start();
  notify();
}
export function setVolume(v) { Engine.setVolume(v); notify(); }
export function getVolume() { return Engine.getVolume(); }

/* room owner can set the community channel */
export function setRoomChannel(chId) {
  roomCh = chId;
  if (!localOverride) Engine.setChannel(channelById(chId));
  notify();
}

/* ============================================================
   Music screen
   ============================================================ */
let screenView = 'channels';
let lmTracks = [];          /* device se aaye gaane */
let lmChannel = {};         /* trackId -> channel id (jo channel me lagega) */
let otResults = [], otQuery = '', otBusy = false, otErr = '', otView = 'search';

export function openMusic() {
  screenView = 'channels';
  openSub(tr('musTitle'), renderMusic, `<button class="addbtn" data-act="musicclose" aria-label="${tr('btnClose')}">${ic(P.x, 18, 2)}</button>`);
  loadLocal();
}

/* local tracks load */
async function loadLocal() {
  lmTracks = await LM.listTracks();
  try { lmChannel = store.json('pn_lm_channel', {}); } catch { lmChannel = {}; }
  const el = $('#lm-list'); if (el) el.innerHTML = lmListHTML();
}
function lmListHTML() {
  if (!lmTracks.length) return `<div class="empty">${tr('musLocalEmpty')}</div>`;
  return lmTracks.map((t) => {
    const cur = LM.current() === t.id && LM.isPlaying();
    const ch = lmChannel[t.id];
    return `<div class="plrow ${cur ? 'on' : ''}">
    <button class="tick sm" data-act="lmplay" data-id="${t.id}" aria-label="Play ${esc(t.name)}">${cur ? ic(P.pause, 14, 3) : ic(P.play, 14, 2)}</button>
    <b>${esc(t.name)}</b><em class="mono">${esc(t.artist)}</em>
    <button class="chip sm" data-act="lmch" data-id="${t.id}">${ch ? esc(channelById(ch).emoji + ' ' + esc(channelById(ch).id.toUpperCase())) : tr('musLocalChannel')}</button>
    <button class="xb" data-act="lmdel" data-id="${t.id}" aria-label="Delete">${ic(P.x, 14, 2)}</button></div>`;
  }).join('');
}

/* local file picker */
async function pickLocalFiles() {
  const inp = $('#lm-file');
  if (!inp) return;
  inp.value = '';
  inp.click();
}

function openTuneSection() {
  const tr_ = OT.currentTrack();
  const inst = OT.getInstance();
  const pos = OT.position(), dur = OT.duration();
  const fmt = (x) => `${Math.floor(x / 60)}:${String(Math.floor(x % 60)).padStart(2, '0')}`;
  const controls = `<div class="otctl">
    <button class="ibtn" data-act="otplay" aria-label="${OT.isPlaying() ? tr('musPause') : tr('musPlay')}">${ic(OT.isPlaying() ? P.pause : P.play, 18, 2)}</button>
    <div class="otmeta"><b>${tr_ ? esc(tr_.title) : tr('musSearch')}</b><span class="mono">${tr_ ? esc(tr_.artist || '') : 'OpenTune'}</span></div>
    <span class="mono otpos">${fmt(pos)} / ${fmt(dur)}</span>
  </div>
  <input type="range" id="ot-seek" class="rng" min="0" max="${Math.max(1, dur || 1)}" step="0.5" value="${pos}" aria-label="Seek" ${tr_ ? '' : 'disabled'}>
  <div class="chips scrollx">
    <button class="chip" data-act="otskip" aria-pressed="${OT.getSilenceSkip()}">${tr('musSilenceSkip')}</button>
    <button class="chip" data-act="otnorm" aria-pressed="${OT.getNormalize()}">${tr('musNormalize')}</button>
    <button class="chip" data-act="ottempo" data-v="${OT.getTempo() < 1 ? '1' : OT.getTempo() > 1 ? '0.5' : '1.25'}">${tr('musTempo')} ${OT.getTempo().toFixed(2)}×</button>
    <button class="chip" data-act="otpitch" aria-pressed="${OT.getPitchPreserve()}">${tr('musPitch')}</button>
  </div>`;
  const server = `<div class="otinst"><span class="mono">${tr('musInstance')}: <b>${esc(inst || '—')}</b></span>
    <button class="chip sm" data-act="otinst">${tr('btnEdit')}</button></div>`;
  const results = otView === 'library' ? libraryHTML() : (otResults.length ? otResultsHTML() :
    `<div class="empty">${otBusy ? tr('loading') : (otErr ? otErr : tr('musSearch'))}</div>`);
  return `<div class="mono lbl">${tr('musOpenTune').toUpperCase()}</div>
<div class="card-big otcard">
  <div class="otrow">
    <input id="ot-q" class="otinput" placeholder="${tr('musSearchPh')}" value="${esc(otQuery)}" autocomplete="off" enterkeyhint="search" aria-label="${tr('musSearch')}">
    <button class="btn sm" data-act="otsearch">${tr('musSearch')}</button>
  </div>
  <p class="sub">${tr('musOpenTuneTag')}</p>
  <p class="sub otcredit">${tr('musOpenTuneCredit')}</p>
  ${controls}
  ${server}
</div>
<div class="seg sm" role="group">
  <button type="button" data-act="otview" data-v="search" aria-pressed="${otView === 'search'}">${tr('musSearch')}</button>
  <button type="button" data-act="otview" data-v="library" aria-pressed="${otView === 'library'}">${tr('musLibrary')}</button>
</div>
${results}`;
}
function otResultsHTML() {
  return `<div class="rows2">${otResults.map((t, i) => `<div class="plrow">
    <button class="tick sm" data-act="otplayone" data-i="${i}" aria-label="Play ${esc(t.title)}">${ic(P.play, 13, 2)}</button>
    <b>${esc(t.title)}</b><em class="mono">${esc(t.artist || '')}</em>
    <span class="mono otpos">${esc(t.duration || '')}</span>
    <button class="xb" data-act="otsave" data-i="${i}" aria-label="Save">${ic(OT.isSaved(t.id) ? P.check : P.plus, 14, 2)}</button>
  </div>`).join('')}</div>`;
}
function libraryHTML() {
  const lib = OT.library();
  const pls = OT.playlists();
  return `<div class="mono lbl">${tr('musLibrary')}</div>
${lib.length ? `<div class="rows2">${lib.map((t, i) => `<div class="plrow">
  <button class="tick sm" data-act="otplayone" data-i="${i}" aria-label="Play ${esc(t.title)}">${ic(P.play, 13, 2)}</button>
  <b>${esc(t.title)}</b><em class="mono">${esc(t.artist || '')}</em>
  <button class="xb" data-act="otunsave" data-id="${esc(t.id)}" aria-label="Remove">${ic(P.x, 14, 2)}</button>
</div>`).join('')}</div>` : `<div class="empty">${tr('musNoResults')}</div>`}
${pls.length ? `<div class="mono lbl">PLAYLISTS</div><div class="rows2">${pls.map((p) => `<div class="plrow"><b>${esc(p.name)}</b><em class="mono">${p.tracks.length}</em></div>`).join('')}</div>` : ''}`;
}

function vizHTML() {
  return `<div class="viz"><canvas id="viz" width="640" height="200"></canvas><div class="viz-eq" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></div>`;
}

function renderMusic(body) {
  const ch = currentChannel(), vol = getVolume(), on = isPlaying();
  const owner = !!(S.room && S.room.owner === S.user?.uid);
  const local = lmTracks || [];
  body.innerHTML = `
<div class="musichead">
  <div class="coverwrap">${coverArt(ch, 108)}<span class="coverlbl mono">${esc(ch.emoji)} ${esc(ch.id.toUpperCase())}</span></div>
  <div class="musemeta">
    <div class="mono lbl">${S.code ? (localOverride ? tr('musMyChoice') : tr('musCommunity')) : tr('musPersonal')}</div>
    <h2 class="mtitle">${esc(ch.name)}</h2>
    <p class="msub">${esc(ch.tag)}</p>
    <div class="musectl">
      <button class="playbtn" data-act="musicplay" aria-pressed="${on}" aria-label="${on ? tr('musPause') : tr('musPlay')}">${ic(on ? P.pause : P.play, 24, 2)}</button>
      <button class="ibtn" data-act="musicnext" aria-label="${tr('musNext')}">${ic(P.next, 18, 1.9)}</button>
      <button class="ibtn" data-act="musicshuffle" aria-label="${tr('musShuffle')}">${ic(P.dice, 18, 1.9)}</button>
    </div>
  </div>
</div>
${vizHTML()}
${heroArt('assets/art/hero-music.webp', tr('musCommunity'), tr('musHeroTitle'), tr('musHeroText'))}
<div class="volrow">
  <button class="ibtn sm" data-act="musicvol" data-v="-1" aria-label="Volume kam">${ic(P.arrow, 16, 2)}</button>
  <input type="range" id="mvol" min="0" max="100" value="${Math.round(vol * 100)}" aria-label="${tr('musVolume')}">
  <button class="ibtn sm" data-act="musicvol" data-v="1" aria-label="Volume badha">${ic(P.arrow, 16, 2)}</button>
  <span class="mono volv">${Math.round(vol * 100)}%</span>
</div>
${openTuneSection()}
<div class="mono lbl">${tr('musLocal')}</div>
<div class="card-big">
  <button class="btn soft" data-act="lmadd">${ic(P.plus, 18, 2)}${tr('musLocalAdd')}</button>
  <p class="sub">${tr('musLocalHint')}</p>
</div>
<div id="lm-list" class="rows2">${lmListHTML()}</div>
<div class="mono lbl">${tr('musChHi').toUpperCase()}</div>
<div class="chgrid" id="chg-hi">${CHANNELS_HI.map((c) => `<button class="chcard ${c.id === ch.id ? 'on' : ''}" data-act="musicch" data-v="${c.id}" aria-pressed="${c.id === ch.id}">
  ${coverArt(c, 72)}<b>${esc(c.emoji)} ${esc(c.name)}</b><span class="mono">${esc(c.tag)}</span><span class="gtags"><i class="gtag">${c.bpm} BPM</i></span></button>`).join('')}</div>
<div class="mono lbl">${tr('musChEn').toUpperCase()}</div>
<div class="chgrid" id="chg-en">${CHANNELS_EN.map((c) => `<button class="chcard ${c.id === ch.id ? 'on' : ''}" data-act="musicch" data-v="${c.id}" aria-pressed="${c.id === ch.id}">
  ${coverArt(c, 72)}<b>${esc(c.emoji)} ${esc(c.name)}</b><span class="mono">${esc(c.tag)}</span><span class="gtags"><i class="gtag">${c.bpm} BPM</i></span></button>`).join('')}</div>
${S.code ? `<div class="mono lbl">${tr('musCommunity')}</div>
<div class="card-big">
  <div class="cal-h"><b>${esc(S.code)}</b><span class="mono">${owner ? 'owner' : 'member'}</span></div>
  <p class="sub">${tr('musRoomText')}</p>
  <div class="mono lbl">${tr('musChHi')}</div>
  <div class="chips scrollx">${CHANNELS_HI.map((c) => `<button class="chip ${c.id === (S.room.music || {}).ch ? 'on' : ''}" data-act="musicroomch" data-v="${c.id}" ${owner ? '' : 'disabled'} aria-pressed="${c.id === (S.room.music || {}).ch}">${esc(c.emoji)} ${esc(c.name)}</button>`).join('')}</div>
  <div class="mono lbl">${tr('musChEn')}</div>
  <div class="chips scrollx">${CHANNELS_EN.map((c) => `<button class="chip ${c.id === (S.room.music || {}).ch ? 'on' : ''}" data-act="musicroomch" data-v="${c.id}" ${owner ? '' : 'disabled'} aria-pressed="${c.id === (S.room.music || {}).ch}">${esc(c.emoji)} ${esc(c.name)}</button>`).join('')}</div>
  ${owner ? '<button class="btn soft sm" data-act="musicauto">' + tr('musAuto') + '</button>' : ''}
  ${localOverride ? '<button class="btn soft sm" data-act="musiclocalclear">' + tr('musClearChoice') + '</button>' : ''}
</div>` : `<div class="card-big"><p class="sub">${tr('musNoRoom')}</p></div>`}
<div class="mono lbl">${tr('musCredits')}</div>
<div class="card-big credits">
  <p><b>Music engine:</b> ${tr('musEngineNote')}</p>
  <p><b>Inspiration:</b> <a href="https://github.com/HemantKArya/BloomeeTunes" target="_blank" rel="noopener">Bloomee</a> — ${tr('musCreditsNote')}</p>
  <p><b>OpenTune:</b> <a href="https://github.com/Arturo254/OpenTune" target="_blank" rel="noopener">Arturo254 / OpenTune</a> (GPL-3.0) — ${tr('musOpenTuneCredit')}</p>
  <p><b>${tr('musLocal')}:</b> <code>music/manifest.json</code></p>
</div>`;
  drawViz();
  const mv = $('#mvol');
  if (mv) mv.oninput = () => { setVolume(Number(mv.value) / 100); const lbl = body.querySelector('.volv'); if (lbl) lbl.textContent = mv.value + '%'; };
  $('#viz') && startViz();
}

function drawViz() {
  const cv = $('#viz');
  if (!cv) return;
  const ctx2 = cv.getContext('2d');
  const an = Engine.analyser;
  const W = cv.width, H = cv.height;
  const data = an ? new Uint8Array(an.frequencyBinCount) : null;
  let raf;
  const tick = () => {
    ctx2.clearRect(0, 0, W, H);
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--ac').trim() || '#C8F23A';
    if (an && data) {
      an.getByteFrequencyData(data);
      const bars = 40, step = Math.floor(data.length / bars);
      for (let i = 0; i < bars; i++) {
        let v = 0;
        for (let j = 0; j < step; j++) v = Math.max(v, data[i * step + j]);
        const h = (v / 255) * H * 0.92;
        const x = (i / bars) * W;
        const w = W / bars - 3;
        const g = ctx2.createLinearGradient(0, H, 0, H - h);
        g.addColorStop(0, accent + '44'); g.addColorStop(1, accent);
        ctx2.fillStyle = g;
        ctx2.beginPath(); ctx2.roundRect(x, H - h, w, h, 4); ctx2.fill();
      }
    } else {
      ctx2.fillStyle = accent + '55';
      for (let i = 0; i < 40; i++) {
        const h = (Math.sin(Date.now() / 260 + i * 0.42) * 0.5 + 0.5) * H * 0.55;
        ctx2.beginPath(); ctx2.roundRect((i / 40) * W, H - h, W / 40 - 3, h, 4); ctx2.fill();
      }
    }
    raf = requestAnimationFrame(tick);
  };
  cancelAnimationFrame(rafId); rafId = raf; tick();
}
function startViz() { drawViz(); }

export function stopViz() { if (rafId) { cancelAnimationFrame(rafId); rafId = null; } }

/* ============================================================
   click handling
   ============================================================ */
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]');
  if (!b) return;
  const a = b.dataset.act, v = b.dataset.v;
  switch (a) {
    case 'musicplay': {
      const ok = toggle();
      if (!ok) toast('Is browser me audio nahi chalta');
      refreshSub(true);
      break;
    }
    case 'musicnext': nextChannel(); refreshSub(true); break;
    case 'musicshuffle': {
      const c = CHANNELS[Math.floor(Math.random() * CHANNELS.length)];
      playChannel(c.id); refreshSub(true); break;
    }
    case 'musicch': playChannel(v); refreshSub(true); break;
    case 'musicvol': setVolume(clamp(getVolume() + (Number(v) > 0 ? 0.1 : -0.1), 0, 1)); refreshSub(true); break;
    case 'musicroomch': {
      if (!S.code) break;
      if (!(S.room && S.room.owner === S.user?.uid)) return toast('Sirf room owner channel badal sakta hai');
      setRoomChannel(v);
      if (typeof setRoomMusicDoc === 'function') setRoomMusicDoc(v);
      toast('Room channel: ' + channelById(v).name);
      refreshSub(true);
      break;
    }
    case 'musicauto': {
      if (!S.code) break;
      const auto = channelForRoom(S.code);
      setRoomChannel(auto);
      if (typeof setRoomMusicDoc === 'function') setRoomMusicDoc(auto);
      toast('Auto channel: ' + channelById(auto).name);
      refreshSub(true);
      break;
    }
    case 'musiclocalclear': setLocalOverride(null); refreshSub(true); break;
    /* ---------- local music ---------- */
    case 'lmadd': pickLocalFiles(); break;
    case 'lmplay': { const id = b.dataset.id; LM.toggle(id).then(() => refreshSub(true)); break; }
    case 'lmdel': { LM.removeTrack(b.dataset.id).then(() => loadLocal().then(() => refreshSub(true))); break; }
    case 'lmch': {
      const id = b.dataset.id;
      lmChannel[id] = lmChannel[id] ? '' : currentChannel().id;
      store.setJson('pn_lm_channel', lmChannel);
      refreshSub(true); break;
    }
    /* ---------- OpenTune ---------- */
    /* ---------- OpenTune ---------- */
    case 'otsearch': {
      const q = ($('#ot-q') ? $('#ot-q').value : '').trim();
      if (!q) return toast(tr('musSearch'));
      otQuery = q; otBusy = true; otErr = ''; otView = 'search'; refreshSub(true);
      OT.probe().catch(() => {})
        .then(() => OT.search(q))
        .then((r) => { otResults = r; otBusy = false; if (!r.length) otErr = tr('musNoResults'); refreshSub(true); })
        .catch(() => { otBusy = false; otErr = tr('musNoInstance'); refreshSub(true); });
      break;
    }
    case 'otview': otView = b.dataset.v; refreshSub(true); break;
    case 'otplayone': {
      const i = Number(b.dataset.i);
      const t = otView === 'library' ? OT.library()[i] : otResults[i];
      if (!t) break;
      OT.play(t).then(() => refreshSub(true)).catch(() => { otErr = tr('musNoInstance'); refreshSub(true); });
      break;
    }
    case 'otplay': OT.toggle().then(() => refreshSub(true)); break;
    case 'otsave': { const t = otResults[Number(b.dataset.i)]; if (t) { OT.saveTrack(t); toast(tr('musLibrary') + ' ✓'); refreshSub(true); } break; }
    case 'otunsave': OT.removeTrack(b.dataset.id); refreshSub(true); break;
    case 'otskip': OT.setSilenceSkip(!OT.getSilenceSkip()); refreshSub(true); break;
    case 'otnorm': OT.setNormalize(!OT.getNormalize()); refreshSub(true); break;
    case 'ottempo': OT.setTempo(Number(b.dataset.v) || 1); refreshSub(true); break;
    case 'otpitch': OT.setPitch(!OT.getPitchPreserve()); refreshSub(true); break;
    case 'otinst': {
      const cur = OT.getInstance() || '';
      const v = (prompt(tr('musInstance') + ' URL', cur) || '').trim();
      if (v) { OT.setInstance(v); toast(tr('btnSave')); refreshSub(true); }
      break;
    }
    case 'musicclose': { const back = document.querySelector('[data-act=subback]'); back && back.click(); break; }
  }
});

/* device se gaane add karne wala input */
document.addEventListener('change', (e) => {
  if (e.target.id !== 'lm-file') return;
  const files = e.target.files;
  if (!files || !files.length) return;
  LM.addFiles(files).then((added) => {
    toast(added.length ? `${added.length} gaane add ho gaye` : 'Koi audio file nahi mili');
    loadLocal().then(() => refreshSub(true));
  });
});

/* OpenTune server auto-detect ho jaaye to UI refresh */
export async function opentuneReady() {
  const i = await OT.probe();
  if (i) refreshSub(true);
  return i;
}

/* room music doc writer — app.js se inject hota hai (Firebase dependency cycle se bachne ke liye) */
let setRoomMusicDoc = null;
export function bindRoomMusic(fn) { setRoomMusicDoc = fn; }

/* debug/testing hook */
if (typeof window !== 'undefined') {
  window.__pnAudio = { get ctx() { return Engine.ctx; }, get playing() { return Engine.playing; }, get channel() { return Engine.channel.id; } };
}
