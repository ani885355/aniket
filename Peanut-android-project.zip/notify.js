/* Reminders: ek hi jagah se saare reminders bante hain (routine, habits, tasks, events, exams, focus, snooze).
   Native (Capacitor LocalNotifications) pe schedule hote hain, browser me tab khula ho tab chalte hain. */
import { S, D, store, toast, DAY, ymd, dt, fromYmd, addDays, daysBetween, todayKey, occurrences, pad, nowHHMM, fmtD } from './core.js';

function getLN() {
  try {
    const cap = window.Capacitor;
    if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return null;
    if (cap.Plugins && cap.Plugins.LocalNotifications) return cap.Plugins.LocalNotifications;
    if (typeof cap.registerPlugin === 'function') return cap.registerPlugin('LocalNotifications');
  } catch (e) { console.warn('LocalNotifications bridge', e); }
  return null;
}
const LN = getLN();
export const NATIVE = !!LN;

export async function permState() {
  try {
    if (NATIVE) { const r = await LN.checkPermissions(); return String(r.display).startsWith('prompt') ? 'default' : r.display; }
    if (!('Notification' in window)) return 'unsupported';
    return Notification.permission;
  } catch { return 'unsupported'; }
}
export async function askPermission() {
  if (NATIVE) { try { return (await LN.requestPermissions()).display; } catch { return 'denied'; } }
  if (!('Notification' in window)) { toast('Is browser me notifications nahi chalte'); return 'unsupported'; }
  try { return await Notification.requestPermission(); } catch { return 'denied'; }
}

export const nid = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) | 0; return (Math.abs(h) % 2000000000) + 1; };

/* ---------- preferences ---------- */
const KINDS = [['routine', 'Daily routine'], ['habit', 'Habits'], ['task', 'Tasks & homework'], ['event', 'Events & birthdays'], ['exam', 'Exams'], ['focus', 'Focus timer']];
export const NOTIF_KINDS = KINDS;
export const getPrefs = () => ({ routine: true, habit: true, task: true, event: true, exam: true, focus: true, ...store.json('nnn_np', {}) });
export const setPrefs = (p) => { store.setJson('nnn_np', p); sync(); };

/* ---------- reminder builder ---------- */
export function buildReminders(horizonDays = 60, past = false) {
  const out = [], now = Date.now(), lo = past ? now - 300000 : now + 3000, limit = now + horizonDays * DAY, prefs = getPrefs();
  const seen = new Set();
  const once = (kind, key, title, body, at) => {
    if (!prefs[kind] || seen.has(key) || !(at > lo && at < limit)) return;
    seen.add(key); out.push({ kind, key, title, body, at });
  };
  const daily = (kind, key, title, body, time, days) => {
    if (!prefs[kind] || !time || seen.has(key)) return;
    seen.add(key); out.push({ kind, key, title, body, daily: time, days: days && days.length ? days : null });
  };
  if (!S.me) return out;
  (S.me.schedule || []).filter((i) => i.on && S.me.remindersOn).forEach((i) => daily('routine', 'sch:' + i.id, i.title, i.sub || 'Peanut reminder', i.time));
  D.habits.filter((h) => h.time && h.remind !== false && !h.archived).forEach((h) =>
    daily('habit', 'hab:' + h.id, (h.emoji || '') + ' ' + h.name, 'Aaj ki aadat ka time', h.time, (h.days || []).map(Number)));
  const t0 = todayKey();
  D.tasks.filter((t) => !t.done && t.due && t.rem !== -1).forEach((t) => {
    const at = dt(t.due, t.dueTime || '09:00') - (Number(t.rem) || 0) * 60000;
    once('task', `task:${t.id}`, t.title, t.dueTime ? `Due ${t.dueTime}` : 'Aaj due hai', at);
  });
  const to = ymd(addDays(new Date(), horizonDays));
  D.events.forEach((e) => {
    const rems = Array.isArray(e.rem) ? e.rem.map(Number) : [0];
    const time = e.time || '09:00';
    occurrences(e, t0, to).forEach((d) => rems.forEach((m) =>
      once('event', `ev:${e.id}:${d}:${m}`, e.title, m === 0 ? `Aaj ${e.time || ''} ${e.loc ? '@ ' + e.loc : ''}`.trim() : `${m >= 1440 ? Math.round(m / 1440) + ' din' : m + ' min'} baad: ${e.title}`, dt(d, time) - m * 60000)));
    if (e.remCustomDate) once('event', `ev:${e.id}:custom`, e.title, 'Custom reminder', dt(e.remCustomDate, e.remCustomTime || '09:00'));
  });
  D.exams.filter((x) => x.date >= t0).forEach((x) => {
    const sub = x.subject || x.name || 'Exam';
    once('exam', `ex:${x.id}:eve`, `Kal exam: ${sub}`, 'Aaj raat jaldi so jao, admit card/stationery ready rakho', dt(ymd(addDays(fromYmd(x.date), -1)), '20:00'));
    once('exam', `ex:${x.id}:2h`, `Exam shuru hone wala hai: ${sub}`, x.loc ? 'Venue: ' + x.loc : 'Best of luck!', dt(x.date, x.start || '09:00') - 2 * 3600e3);
    const left = daysBetween(t0, x.date);
    for (let n = Math.min(left, 14); n >= 1; n--) {
      const d = ymd(addDays(fromYmd(x.date), -n));
      once('exam', `ex:${x.id}:prep:${d}`, `${sub}: ${n} din baaki`, 'Aaj thoda revision kar lo', dt(d, '07:30'));
    }
  });
  const fs = store.json('nnn_focus', null);
  if (fs && fs.mode === 'run' && fs.end > now) once('focus', 'focus:end', 'Focus session poora!', fs.kind === 'focus' ? 'Ab chhota break lo' : 'Break khatam, wapas focus pe', fs.end);
  (store.json('nnn_snooze', []) || []).forEach((s) => { if (s.at > now) { seen.add(s.key); out.push({ kind: 'snooze', ...s }); } });
  return out;
}

/* ---------- native schedule ---------- */
let syncT, lastList = [];
export function sync() { clearTimeout(syncT); syncT = setTimeout(doSync, 1500); }
async function doSync() {
  const list = buildReminders();
  lastList = list;
  store.setJson('nnn_sched', list.filter((r) => r.at).map(({ key, title, body, at }) => ({ key, title, body, at })).slice(0, 300));
  if (!NATIVE) return;
  try {
    await cancelNative();
    if ((await permState()) !== 'granted') return;
    await ensureActions();
    const ones = list.filter((r) => r.at).sort((a, b) => a.at - b.at).slice(0, 110);
    const notifs = [];
    list.filter((r) => r.daily).forEach((r) => {
      const [h, m] = r.daily.split(':').map(Number);
      if (r.days) r.days.forEach((d) => notifs.push({ id: nid(r.key + ':' + d), title: r.title, body: r.body, actionTypeId: 'PEANUT_ACT', extra: { key: r.key }, schedule: { on: { weekday: d + 1, hour: h, minute: m }, allowWhileIdle: true } }));
      else notifs.push({ id: nid(r.key), title: r.title, body: r.body, actionTypeId: 'PEANUT_ACT', extra: { key: r.key }, schedule: { on: { hour: h, minute: m }, allowWhileIdle: true } });
    });
    ones.forEach((r) => notifs.push({ id: nid(r.key), title: r.title, body: r.body, actionTypeId: 'PEANUT_ACT', extra: { key: r.key }, schedule: { at: new Date(r.at), allowWhileIdle: true } }));
    /* ids unique rakhte hain taaki duplicate notification na bane */
    const uniq = new Map(); notifs.forEach((n) => uniq.set(n.id, n));
    if (uniq.size) await LN.schedule({ notifications: [...uniq.values()] });
  } catch (e) { console.warn('native schedule', e); }
}
export async function cancelNative() {
  if (!NATIVE) return;
  try {
    const p = await LN.getPending();
    if (p.notifications && p.notifications.length) await LN.cancel({ notifications: p.notifications.map((n) => ({ id: n.id })) });
  } catch (e) { console.warn('native cancel', e); }
}
let actionsDone = false;
async function ensureActions() {
  if (actionsDone) return; actionsDone = true;
  try {
    await LN.registerActionTypes({ types: [
      { id: 'PEANUT_ACT', actions: [{ id: 'snooze', title: 'Snooze 10 min' }, { id: 'done', title: 'Done' }] },
      { id: 'NNN_ACT', actions: [{ id: 'snooze', title: 'Snooze 10 min' }, { id: 'done', title: 'Done' }] }
    ] });
    if (LN.addListener) {
      LN.addListener('localNotificationActionPerformed', (ev) => {
        const n = ev.notification || {}, key = n.extra && n.extra.key;
        if (ev.actionId === 'snooze') snooze({ key: key || 'x' + n.id, title: n.title, body: n.body });
        else if (ev.actionId === 'done' && key) window.dispatchEvent(new CustomEvent('nnn-done', { detail: key }));
      });
      LN.addListener('localNotificationReceived', (n) => log({ key: n.extra && n.extra.key, title: n.title, body: n.body }));
    }
  } catch (e) { console.warn('actions', e); }
}

/* ---------- snooze + history ---------- */
export function snooze(r, mins = 10) {
  const list = (store.json('nnn_snooze', []) || []).filter((s) => s.at > Date.now() && s.key !== 'snz:' + r.key);
  list.push({ key: 'snz:' + r.key, title: r.title, body: r.body, at: Date.now() + mins * 60000 });
  store.setJson('nnn_snooze', list);
  toast(`${mins} min baad yaad dilaunga`);
  sync();
}
export const getHistory = () => store.json('nnn_nhist', []);
export function log(r) {
  const h = getHistory();
  h.unshift({ key: r.key || '', title: r.title, body: r.body || '', ts: r.ts || Date.now() });
  store.setJson('nnn_nhist', h.slice(0, 100));
}
export function clearHistory() { store.setJson('nnn_nhist', []); }

/* App khulne par: jo one-off reminders beech me fire ho chuke unhe history me daalo */
export function catchUpHistory() {
  const last = Number(store.get('nnn_hcheck', '0')) || Date.now() - DAY;
  const now = Date.now();
  const have = new Set(getHistory().map((h) => h.key + '@' + Math.floor(h.ts / 60000)));
  (store.json('nnn_sched', []) || []).filter((r) => r.at > last && r.at <= now).forEach((r) => {
    if (!have.has(r.key + '@' + Math.floor(r.at / 60000))) log({ ...r, ts: r.at });
  });
  store.set('nnn_hcheck', String(now));
}

/* ---------- browser fallback ---------- */
async function showNote(title, body, key) {
  const opt = { body, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png', tag: 'nnn-' + (key || title) };
  try { const reg = await navigator.serviceWorker?.getRegistration(); if (reg) { await reg.showNotification(title, opt); return; } } catch { /* fall through */ }
  try { new Notification(title, opt); } catch { /* ignore */ }
}
export function tick() {
  if (!S.me || NATIVE || !('Notification' in window) || Notification.permission !== 'granted') return;
  const now = new Date(), hhmm = nowHHMM(), dkey = now.toDateString(), nowMs = now.getTime();
  let fired = store.json('nnn_fired2', {});
  if (fired.d !== dkey) fired = { d: dkey, ids: [] };
  const list = buildReminders(2, true);
  for (const r of list) {
    const due = r.daily ? (r.daily === hhmm && (!r.days || r.days.includes(now.getDay()))) : (r.at <= nowMs && nowMs - r.at < 300000);
    const id = r.key + (r.daily ? '' : '@' + r.at);
    if (!due || fired.ids.includes(id)) continue;
    fired.ids.push(id);
    showNote(r.title, r.body, r.key);
    log(r);
  }
  store.setJson('nnn_fired2', fired);
}
/* one-off reminders ki list tick ke liye alag se: buildReminders sirf future dikhata hai, isliye browser me 'at' ko thoda peeche tak lena padta hai */
export function startTicker() {
  setInterval(tick, 20000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { tick(); catchUpHistory(); } });
}
export const upcomingReminders = () => (lastList.length ? lastList : buildReminders()).filter((r) => r.at).sort((a, b) => a.at - b.at).slice(0, 12);
