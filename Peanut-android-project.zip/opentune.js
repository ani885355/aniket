/* ============================================================
   opentune.js — OpenTune for the web.

   OpenTune (https://github.com/Arturo254/OpenTune) — Arturo254 ka
   open-source YouTube Music client (Kotlin + Compose + Material 3,
   GPL-3.0). Web build me hum usi ko Piped / Invidious (dono open-source
   YouTube frontends) ke through chalate hain: search, direct streams,
   ad-free, no login.

   OpenTune ke features jo yahan match hote hain:
     - Ad-free playback (direct audio stream)
     - Background playback (MediaSession + lock screen controls)
     - Advanced search (songs, artists, albums)
     - Library management (saved tracks, local playlists)
     - Offline mode (local files — localmusic.js)
     - Silence skipping
     - Audio normalization
     - Tempo & pitch control
   ============================================================ */
import { store, toast } from './core.js';

export const OPENTUNE_CREDIT = 'OpenTune';
export const OPENTUNE_URL = 'https://github.com/Arturo254/OpenTune';
export const OPENTUNE_LICENSE = 'GPL-3.0';

/* ---------- open-source instances ---------- */
const PIPED = [
  'https://pipedapi.kavin.rocks',
  'https://pipedapi.adminforge.de',
  'https://pipedapi.reallyaweso.me',
  'https://pipedapi.leptons.xyz',
  'https://pipedapi.r4fo.com',
  'https://pipedapi.drgns.space',
  'https://pipedapi.privacy.com.de',
  'https://pipedapi.smnz.de',
  'https://piped-api.lunar.icu',
  'https://pipedapi.orangenet.cc'
];
const INVIDIOUS = [
  'https://inv.nadeko.net',
  'https://yewtu.be',
  'https://invidious.nerdvpn.de',
  'https://invidious.privacyredirect.com',
  'https://id.420129.xyz',
  'https://invidious.jing.rocks',
  'https://invidious.fdn.fr'
];

const INST_KEY = 'pn_ot_instance';
let inst = store.get(INST_KEY, '');
let instKind = store.get('pn_ot_kind', 'piped');
const listeners = new Set();
export const onChange = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
const emit = () => listeners.forEach((f) => { try { f(); } catch (e) { console.warn(e); } });

export const getInstance = () => inst;
export const setInstance = (url) => {
  inst = String(url || '').replace(/\/+$/, '');
  instKind = /invidious/i.test(inst) ? 'invidious' : 'piped';
  store.set(INST_KEY, inst); store.set('pn_ot_kind', instKind);
  emit();
};
export const instanceList = () => (instKind === 'invidious' ? INVIDIOUS : PIPED);
export const instanceKind = () => instKind;

async function ping(base, ms = 4500) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    const r = await fetch(base + '/trending', { signal: ctl.signal });
    return r.ok || r.status === 404;   /* koi bhi reachable server */
  } catch { return false; }
  finally { clearTimeout(t); }
}

/* Ek kaam karta hua server dhoondho (user ka set kiya hua pehle). */
export async function probe(force = false) {
  if (inst && !force) return inst;
  const custom = store.get('pn_ot_custom', '');
  const cands = [];
  if (custom) cands.push(custom.replace(/\/+$/, ''));
  if (inst) cands.push(inst);
  cands.push(...PIPED);
  for (const c of cands) {
    if (!c) continue;
    if (await ping(c)) { setInstance(c); return c; }
  }
  return '';
}

/* ---------- search ---------- */
const dur = (s) => {
  s = Math.max(0, Math.floor(s || 0));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

export async function search(q, type = 'video') {
  const base = inst || await probe();
  if (!base) throw new Error('no-instance');
  const enc = encodeURIComponent(q);
  try {
    if (instKind === 'invidious') {
      const r = await fetch(`${base}/api/v1/search?q=${enc}&type=video`);
      if (!r.ok) throw new Error('http ' + r.status);
      const j = await r.json();
      return (j || []).slice(0, 25).map((v) => ({
        id: v.videoId, title: v.title, artist: v.author, duration: dur(v.lengthSeconds),
        dur: v.lengthSeconds, thumb: (v.videoThumbnails && v.videoThumbnails[0] && v.videoThumbnails[0].url) || '',
        source: 'youtube'
      }));
    }
    const r = await fetch(`${base}/search?q=${enc}&filter=videos`);
    if (!r.ok) throw new Error('http ' + r.status);
    const j = await r.json();
    return (j.items || []).slice(0, 25).map((v) => ({
      id: (v.url || '').split('?v=')[1] || '', title: v.title, artist: v.uploaderName || '',
      duration: dur(v.duration), dur: v.duration, thumb: v.thumbnailUrl || '', source: 'youtube'
    })).filter((x) => x.id);
  } catch (e) { throw new Error('search-failed'); }
}

/* ---------- streams ---------- */
export async function streams(id) {
  const base = inst || await probe();
  if (!base) throw new Error('no-instance');
  try {
    if (instKind === 'invidious') {
      const r = await fetch(`${base}/api/v1/videos/${id}`);
      if (!r.ok) throw new Error('http');
      const j = await r.json();
      const a = (j.formatStreams || []).filter((f) => (f.type || '').includes('audio') && f.url)
        .sort((x, y) => (y.itag || 0) - (x.itag || 0))[0];
      if (!a) throw new Error('no-audio');
      return {
        url: a.url, title: j.title, artist: j.author, dur: j.lengthSeconds,
        thumb: (j.videoThumbnails && j.videoThumbnails[0] && j.videoThumbnails[0].url) || '',
        id, source: 'youtube'
      };
    }
    const r = await fetch(`${base}/streams/${id}`);
    if (!r.ok) throw new Error('http');
    const j = await r.json();
    const a = (j.audioStreams || []).filter((s) => s.url).sort((x, y) => (y.bitrate || 0) - (x.bitrate || 0))[0];
    if (!a) throw new Error('no-audio');
    return {
      url: a.url, title: j.title, artist: j.uploader || '', dur: j.duration,
      thumb: j.thumbnailUrl || '', id, source: 'youtube'
    };
  } catch (e) { throw new Error('stream-failed'); }
}

/* ============================================================
   Player — <audio> + WebAudio chain
   ============================================================ */
let el = null, ctx = null, srcNode = null, analyser = null, gate = null, comp = null, master = null;
let ready = false, playing = false;
let tempo = 1, pitchPreserve = true, normalize = false, silenceSkip = false;
let silenceTimer = null, silentFor = 0, lastCheck = 0;

export const getAnalyser = () => analyser;
export const isPlaying = () => playing;
export const getTempo = () => tempo;
export const getPitchPreserve = () => pitchPreserve;
export const getNormalize = () => normalize;
export const getSilenceSkip = () => silenceSkip;
export const position = () => (el ? el.currentTime : 0);
export const duration = () => (el ? (el.duration || 0) : 0);
export const currentTrack = () => (el ? el.__track || null : null);

function ensureCtx() {
  if (ctx) return true;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return false;
  try {
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 1;
    analyser = ctx.createAnalyser(); analyser.fftSize = 256; analyser.smoothingTimeConstant = 0.78;
    gate = ctx.createGain(); gate.gain.value = 1;
    comp = ctx.createDynamicsCompressor();
    comp.threshold.value = normalize ? -22 : -14; comp.knee.value = 20; comp.ratio.value = normalize ? 8 : 3;
    master.connect(analyser); analyser.connect(ctx.destination);
  } catch (e) { ctx = null; return false; }
  return true;
}

/* element -> graph. Cross-origin streams ke liye graph fail ho sakta hai,
   tab audio seedha bajta hai (analyser sirf visual ke liye fallback). */
function wire(el2) {
  if (!ensureCtx()) return;
  try {
    if (!srcNode) {
      srcNode = ctx.createMediaElementSource(el2);
      srcNode.connect(gate); gate.connect(comp); comp.connect(master);
    }
  } catch (e) { srcNode = null; }
}

export async function play(item) {
  if (!el) {
    el = new Audio();
    el.crossOrigin = 'anonymous';
    el.preload = 'none';
    el.addEventListener('ended', () => { playing = false; stopSilenceWatch(); emit(); });
    el.addEventListener('play', () => { playing = true; emit(); });
    el.addEventListener('pause', () => { playing = false; emit(); });
    el.addEventListener('timeupdate', () => { emit(); });
    el.addEventListener('error', () => { playing = false; emit(); });
  }
  let s = item;
  if (!s.url) {
    s = await streams(item.id);
    s.id = item.id;
  }
  el.__track = s;
  el.src = s.url;
  el.playbackRate = tempo;
  el.preservesPitch = pitchPreserve;
  wire(el);
  if (ctx && ctx.state === 'suspended') { try { await ctx.resume(); } catch (e) { /* ignore */ } }
  try { await el.play(); } catch (e) { toast('Playback nahi hua — check network'); }
  playing = true;
  updateMediaSession(s);
  startSilenceWatch();
  emit();
  return true;
}
export async function toggle() {
  if (!el) return false;
  if (el.paused) { try { await el.play(); playing = true; } catch (e) { return false; } }
  else { el.pause(); playing = false; }
  emit();
  return true;
}
export function pause() { if (el) { el.pause(); playing = false; } emit(); }
export function resume() { if (el) { el.play().catch(() => {}); playing = true; } emit(); }
export function seek(t) { if (el) el.currentTime = Math.max(0, t); emit(); }
export function stop() { if (el) { el.pause(); el.src = ''; } playing = false; stopSilenceWatch(); emit(); }

export function setTempo(r) {
  tempo = Math.max(0.5, Math.min(2, Number(r) || 1));
  if (el) { el.playbackRate = tempo; el.preservesPitch = pitchPreserve; }
  emit();
}
export function setPitch(p) {
  pitchPreserve = !!p;
  if (el) el.preservesPitch = pitchPreserve;
  emit();
}
export function setNormalize(v) {
  normalize = !!v;
  if (comp) { comp.threshold.value = normalize ? -22 : -14; comp.ratio.value = normalize ? 8 : 3; }
  emit();
}

/* ---------- silence skipping ---------- */
function startSilenceWatch() {
  stopSilenceWatch();
  if (!silenceSkip) return;
  lastCheck = performance.now();
  silentFor = 0;
  silenceTimer = setInterval(() => {
    if (!el || el.paused || !analyser) return;
    const buf = new Uint8Array(analyser.fftSize);
    analyser.getByteTimeDomainData(buf);
    let sum = 0;
    for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
    const rms = Math.sqrt(sum / buf.length);
    const now = performance.now();
    const dt = (now - lastCheck) / 1000; lastCheck = now;
    if (rms < 0.012) {
      silentFor += dt;
      if (silentFor > 0.45 && el.currentTime < (el.duration || 0) - 1) {
        el.currentTime = Math.min(el.duration || 0, el.currentTime + 1.2);
        silentFor = 0;
      }
    } else silentFor = 0;
  }, 220);
}
function stopSilenceWatch() { if (silenceTimer) { clearInterval(silenceTimer); silenceTimer = null; } }
export function setSilenceSkip(v) { silenceSkip = !!v; if (v) startSilenceWatch(); else stopSilenceWatch(); emit(); }

/* ---------- MediaSession (background / lock screen) ---------- */
function updateMediaSession(t) {
  if (!('mediaSession' in navigator) || !t) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: t.title || 'Peanut',
      artist: t.artist || '',
      album: 'OpenTune',
      artwork: t.thumb ? [{ src: t.thumb, sizes: '512x512', type: 'image/jpeg' }] : []
    });
    navigator.mediaSession.setActionHandler('play', () => resume());
    navigator.mediaSession.setActionHandler('pause', () => pause());
    navigator.mediaSession.setActionHandler('seekbackward', () => seek(position() - 10));
    navigator.mediaSession.setActionHandler('seekforward', () => seek(position() + 10));
  } catch (e) { /* ignore */ }
}

/* ============================================================
   Library — local saved tracks + playlists
   ============================================================ */
const LIB_KEY = 'pn_ot_lib';
const PL_KEY = 'pn_ot_pl';
export const library = () => store.json(LIB_KEY, []);
export const playlists = () => store.json(PL_KEY, []);

export function saveTrack(t) {
  const lib = library();
  if (lib.some((x) => x.id === t.id)) return false;
  lib.unshift({ id: t.id, title: t.title, artist: t.artist, dur: t.dur, thumb: t.thumb, added: Date.now() });
  store.setJson(LIB_KEY, lib.slice(0, 200));
  emit();
  return true;
}
export function removeTrack(id) {
  store.setJson(LIB_KEY, library().filter((x) => x.id !== id));
  emit();
}
export const isSaved = (id) => library().some((x) => x.id === id);

export function createPlaylist(name) {
  const pl = playlists();
  const p = { id: 'pl' + Date.now().toString(36), name: String(name || 'Playlist').slice(0, 40), tracks: [], created: Date.now() };
  pl.unshift(p); store.setJson(PL_KEY, pl); emit();
  return p;
}
export function addToPlaylist(pid, track) {
  const pl = playlists().map((p) => (p.id === pid && !p.tracks.some((t) => t.id === track.id))
    ? { ...p, tracks: [track, ...p.tracks] } : p);
  store.setJson(PL_KEY, pl); emit();
}
export function removePlaylist(pid) {
  store.setJson(PL_KEY, playlists().filter((p) => p.id !== pid)); emit();
}
