/* Datesheet text -> exam rows. Pure function (DOM-free) taaki test ho sake.
   Har row me flags: ambig (dd/mm vs mm/dd), yearGuess. UI hamesha user se confirm karwata hai. */
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, sept: 9, oct: 10, nov: 11, dec: 12 };
const DAYS_RE = /\b(mon|tue|tues|wed|thu|thur|thurs|fri|sat|sun)(day|sday|nesday|rsday|urday)?\b\.?/ig;
const INSTR_RE = /(instruction|carry|bring|admit card|report|reporting|not allowed|mobile|calculator|minutes before|id card|note:|please)/i;
const pad = (n) => String(n).padStart(2, '0');

function yearFix(y, today) {
  if (y == null) return null;
  if (y < 100) y += 2000;
  return y;
}
export function parseDateIn(line, today = new Date()) {
  let m, d, mo, y, ambig = false, yearGuess = false, span = null;
  /* 12/11/2026, 12-11-26, 12.11.2026 */
  if ((m = line.match(/\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b/))) {
    d = +m[1]; mo = +m[2]; y = yearFix(+m[3]); span = m[0];
    if (mo > 12 && d <= 12) { [d, mo] = [mo, d]; } else if (d <= 12 && mo <= 12 && d !== mo) ambig = true;
  } else if ((m = line.match(/\b(\d{1,2})(?:st|nd|rd|th)?[\s\-]+(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?,?(?:[\s\-]+(\d{2,4}))?\b/i))) {
    d = +m[1]; mo = MONTHS[m[2].toLowerCase()]; y = yearFix(m[3] ? +m[3] : null); span = m[0];
  } else if ((m = line.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s+(\d{2,4}))?\b/i))) {
    mo = MONTHS[m[1].toLowerCase()]; d = +m[2]; y = yearFix(m[3] ? +m[3] : null); span = m[0];
  } else return null;
  if (!(d >= 1 && d <= 31 && mo >= 1 && mo <= 12)) return null;
  if (y == null) {
    y = today.getFullYear(); yearGuess = true;
    const cand = new Date(y, mo - 1, d);
    if (cand < new Date(today.getFullYear(), today.getMonth(), today.getDate() - 60)) y += 1;
  }
  const chk = new Date(y, mo - 1, d);
  if (chk.getMonth() !== mo - 1) return null;
  return { date: `${y}-${pad(mo)}-${pad(d)}`, ambig, yearGuess, span };
}
function to24(h, mi, ap) {
  h = +h; mi = +(mi || 0);
  if (ap) { ap = ap.toLowerCase(); if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0; }
  if (h > 23 || mi > 59) return null;
  return `${pad(h)}:${pad(mi)}`;
}
export function parseTimesIn(line) {
  const re = /(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?\s*(?:-|–|—|to|till|until)\s*(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?/i;
  const clean = (x) => (x ? x.replace(/\./g, '').toLowerCase() : x);
  let m = line.match(re);
  if (m && (m[2] || m[3] || m[5] || m[6])) {
    const ap2 = clean(m[6]), ap1 = clean(m[3]) || ap2;
    let s = to24(m[1], m[2], ap1), e = to24(m[4], m[5], ap2);
    if (s && e && e <= s && !ap1 && !ap2) { const [eh, em] = e.split(':').map(Number); if (eh < 12) e = to24(eh + 12, em); }
    if (s && e) return { start: s, end: e, span: m[0] };
  }
  m = line.match(/\b(\d{1,2})[:.](\d{2})\s*(am|pm)?\b/i);
  if (m) { const s = to24(m[1], m[2], m[3]); if (s) return { start: s, end: '', span: m[0] }; }
  m = line.match(/\b(\d{1,2})\s*(am|pm)\b/i);
  if (m) { const s = to24(m[1], 0, m[2]); if (s) return { start: s, end: '', span: m[0] }; }
  return null;
}
export function parseDatesheet(text, today = new Date()) {
  const lines = String(text || '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const rows = [], notes = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const dd = parseDateIn(line, today);
    if (!dd) { if (INSTR_RE.test(line) && line.length > 12) notes.push(line); continue; }
    /* tareekh wali line me time na ho to agli line se lo */
    let tm = parseTimesIn(line.replace(dd.span, ' '));
    let rest = line.replace(dd.span, ' ');
    if (tm) rest = rest.replace(tm.span, ' ');
    else if (lines[i + 1] && !parseDateIn(lines[i + 1], today)) { const t2 = parseTimesIn(lines[i + 1]); if (t2 && lines[i + 1].replace(t2.span, '').replace(/[^A-Za-z]/g, '').length < 6) { tm = t2; i++; } }
    rest = rest.replace(DAYS_RE, ' ').replace(/[|:;,_()\[\]]+/g, ' ').replace(/^\W*\d{1,2}\s+(?=[A-Za-z])/, '').replace(/\s+/g, ' ').replace(/^[\s\-–—.]+|[\s\-–—.]+$/g, '').trim();
    let subject = rest;
    if (subject.length < 2 && lines[i - 1] && !parseDateIn(lines[i - 1], today)) subject = lines[i - 1].replace(/[^\w\s&.\-]/g, '').trim();
    if (subject.length < 2 && lines[i + 1] && !parseDateIn(lines[i + 1], today) && !INSTR_RE.test(lines[i + 1])) subject = lines[i + 1].replace(/[^\w\s&.\-]/g, '').trim();
    rows.push({ subject: subject.slice(0, 50), date: dd.date, start: tm ? tm.start : '', end: tm ? tm.end : '', ambig: dd.ambig, yearGuess: dd.yearGuess, src: line });
  }
  return { rows, notes: notes.slice(0, 6) };
}

/* Syllabus text -> chapter names (numbering hata ke) */
export function parseChapters(text) {
  const seen = new Set();
  return String(text || '').split(/\r?\n/).map((l) => l.replace(/^\s*(chapter|ch|unit|lesson|topic)?\s*[\d.]+\s*[:.)\-–]?\s*/i, '').replace(/^[\-•*·]\s*/, '').replace(/\s+/g, ' ').trim())
    .filter((l) => l.length >= 3 && l.length <= 70 && /[A-Za-zऀ-ॿ]/.test(l))
    .filter((l) => { const k = l.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; }).slice(0, 60);
}
