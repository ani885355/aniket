/* Student mode: syllabus, datesheet (+ smart import), planner, revision, test scores */
import {
  $, $$, esc, S, D, toast, ic, P, add, upd, del, find, openSub, refreshSub, formSheet, awardXP, bar, seg, emptyBox, dot,
  todayKey, addDaysY, fromYmd, ymd, fmtD, fmtDW, rel, pad, uid8, WD, daysBetween, saveMe, pickFile, loadScript, dt, occurrences, heroArt
} from './core.js';
import { sync as syncNotif } from './notify.js';
import { parseDatesheet, parseChapters } from './parse.js';
import { openTasks, KINDS } from './tasks.js';

const COLORS = ['#C8F23A', '#8FB8DE', '#F0A58A', '#B7A6E0', '#E8B96F', '#9AD1B5', '#FF8FB1', '#F2C94C'];
const ST = { pending: ['Pending', 0], ongoing: ['Ongoing', 0.5], completed: ['Done', 1] };
const NEXT = { pending: 'ongoing', ongoing: 'completed', completed: 'pending' };

/* ---------- progress ---------- */
export function chapterProgress(c) {
  if (c.topics && c.topics.length) return c.topics.filter((t) => t.d).length / c.topics.length;
  return (ST[c.status] || ST.pending)[1];
}
export function subjectProgress(s) {
  const ch = s.chapters || []; if (!ch.length) return 0;
  return Math.round(ch.reduce((a, c) => a + chapterProgress(c), 0) / ch.length * 100);
}
export function totalProgress() {
  const all = D.subjects.flatMap((s) => s.chapters || []); if (!all.length) return 0;
  return Math.round(all.reduce((a, c) => a + chapterProgress(c), 0) / all.length * 100);
}
export const pendingChapters = () => D.subjects.flatMap((s) => (s.chapters || []).filter((c) => c.status !== 'completed' && chapterProgress(c) < 1).map((c) => ({ s, c })));
export const upcomingExams = () => D.exams.filter((x) => x.date >= todayKey()).sort((a, b) => (a.date + (a.start || '')).localeCompare(b.date + (b.start || '')));

/* ---------- OCR / text extraction (CDN se, internet chahiye) ---------- */
async function extractText(file) {
  toast('File padh raha hoon, thoda ruko...');
  if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
    await loadScript('https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js');
    const pdfjs = window.pdfjsLib; pdfjs.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    const pdf = await pdfjs.getDocument({ data: await file.arrayBuffer() }).promise;
    let out = '';
    for (let p = 1; p <= Math.min(pdf.numPages, 4); p++) {
      const page = await pdf.getPage(p), tc = await page.getTextContent(), rows = new Map();
      tc.items.forEach((it) => { const y = Math.round(it.transform[5] / 4); rows.set(y, (rows.get(y) || []).concat([[it.transform[4], it.str]])); });
      [...rows.entries()].sort((a, b) => b[0] - a[0]).forEach(([, r]) => { out += r.sort((a, b) => a[0] - b[0]).map((x) => x[1]).join(' ') + '\n'; });
      if (out.replace(/\s/g, '').length < 20) { /* scanned PDF: canvas pe render karke OCR */
        const vp = page.getViewport({ scale: 2 }), cv = document.createElement('canvas'); cv.width = vp.width; cv.height = vp.height;
        await page.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
        out += await ocr(cv);
      }
    }
    return out;
  }
  return ocr(file);
}
async function ocr(src) {
  await loadScript('https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js');
  const r = await window.Tesseract.recognize(src, 'eng');
  return r.data.text || '';
}

/* ================= SYLLABUS ================= */
export function openSyllabus() {
  openSub('Syllabus', renderSyllabus, `<button class="addbtn" data-act="subjadd" aria-label="Subject add karo">${ic(P.plus, 20, 2)}</button>`);
}
function renderSyllabus(body) {
  const st = S.me.study || {}, tp = totalProgress();
  const unfinished = pendingChapters().length;
  body.innerHTML = `<div class="card-big"><div class="cal-h"><b>Total syllabus</b><button class="link" data-act="studyprof">${esc([st.cls, st.board, st.course].filter(Boolean).join(' · ') || 'Class / board set karo')}</button></div>
<div class="bignum"><b>${tp}</b><span>%</span></div>${bar(tp, 10)}<div class="bar-l mono"><span>${unfinished} chapter baaki</span><span>${D.subjects.length} subjects</span></div></div>
${D.subjects.length ? D.subjects.map((s, i) => {
    const ch = s.chapters || [], pg = subjectProgress(s), done = ch.filter((c) => chapterProgress(c) >= 1).length;
    return `<button class="subj" data-act="subjopen" data-id="${s.id}"><span class="sbar" style="background:${s.color || COLORS[i % 8]}"></span><div><b>${esc(s.name)}</b><span class="mono">${done}/${ch.length} chapters</span>${bar(pg, 6)}</div><em class="mono">${pg}%</em></button>`;
  }).join('') : emptyBox('Pehla subject add karo (Maths, Science...). Phir chapters daalo ya syllabus ki photo/PDF se import karo.')}`;
}
function studyProfForm() {
  const st = S.me.study || {};
  formSheet({
    title: 'Class, board aur course', values: st, fields: [
      { k: 'cls', l: 'Class / year', max: 20, ph: 'Class 10 / B.Tech 2nd year' },
      { k: 'board', l: 'Board / university', max: 30, ph: 'CBSE, ICSE, State, DU...' },
      { k: 'course', l: 'Course / stream', max: 30, ph: 'Science, Commerce...' },
      { k: 'year', l: 'Academic year', max: 12, ph: '2026-27' }],
    onSave: (f) => saveMe({ study: f })
  });
}
function subjectForm(id) {
  const s = id ? find('subjects', id) : null;
  formSheet({
    title: s ? 'Subject edit' : 'Naya subject', values: s || {}, fields: [{ k: 'name', l: 'Subject', req: 1, max: 30, ph: 'Mathematics' }],
    onSave: (f) => { if (s) upd('subjects', s.id, { name: f.name }); else add('subjects', { name: f.name, color: COLORS[D.subjects.length % 8], chapters: [] }); },
    onDelete: s ? () => { del('subjects', s.id); } : null
  });
}
let curSub = null, curCh = null, topicFocus = false;
function openSubject(id) {
  curSub = id;
  openSub(find('subjects', id).name, renderSubject, `<button class="addbtn" data-act="chapadd" aria-label="Chapter add">${ic(P.plus, 20, 2)}</button><button class="addbtn" data-act="subjedit" data-id="${id}" aria-label="Edit">${ic(P.edit, 18, 2)}</button>`);
}
const sortCh = (a, b) => ({ high: 0, med: 1, low: 2 }[a.prio || 'med'] - { high: 0, med: 1, low: 2 }[b.prio || 'med']);
function renderSubject(body) {
  const s = find('subjects', curSub); if (!s) { body.innerHTML = emptyBox('Subject nahi mila'); return; }
  const ch = s.chapters || [], pg = subjectProgress(s);
  body.innerHTML = `<div class="card-big"><div class="cal-h"><b>Progress</b><span class="mono">${pg}%</span></div>${bar(pg, 10)}</div>
<div class="two"><button class="btn soft" data-act="chapbulk">${ic(P.list, 18, 2)}Kai chapters ek saath</button><button class="btn soft" data-act="chapimport">${ic(P.camera, 18, 2)}Photo / PDF se</button></div>
${ch.length ? ch.map((c) => {
    const p = Math.round(chapterProgress(c) * 100), late = c.deadline && c.deadline < todayKey() && c.status !== 'completed';
    return `<div class="chrow"><button class="stt ${c.status || 'pending'}" data-act="chapcycle" data-cid="${c.id}" aria-label="Status badlo">${(ST[c.status] || ST.pending)[0]}</button>
<div class="tmain" data-act="chapopen" data-cid="${c.id}"><b>${esc(c.name)}</b><div class="tmeta mono">${dot(c.prio === 'high' ? '#FF9A8A' : c.prio === 'low' ? '#8FD19E' : '#F2C94C')}${c.prio || 'med'}${c.deadline ? ` · ${late ? '<u>' : ''}${fmtD(c.deadline)}${late ? '</u>' : ''}` : ''}${c.weak ? ' · weak' : ''} · ${p}%</div></div></div>`;
  }).join('') : emptyBox('Chapters nahi hain. + dabao ya photo/PDF se import karo.')}`;
}
function saveChapters(sid, fn) {
  const s = find('subjects', sid); if (!s) return;
  const chapters = fn([...(s.chapters || [])]);
  /* local turant dikhe (snapshot aane se pehle) */
  s.chapters = chapters; upd('subjects', sid, { chapters }); refreshSub(true);
}
function chapterForm(cid) {
  const s = find('subjects', curSub), c = cid ? (s.chapters || []).find((x) => x.id === cid) : null;
  formSheet({
    title: c ? 'Chapter edit' : 'Naya chapter', values: c || { prio: 'med', status: 'pending' },
    fields: [{ k: 'name', l: 'Chapter', req: 1, max: 70 }, { k: 'prio', l: 'Priority', t: 'chips', o: [['low', 'Low'], ['med', 'Medium'], ['high', 'High']] },
      { k: 'status', l: 'Status', t: 'chips', o: [['pending', 'Pending'], ['ongoing', 'Ongoing'], ['completed', 'Done']] }, { k: 'deadline', l: 'Deadline', t: 'date' }],
    onSave: (f) => saveChapters(curSub, (arr) => (c ? arr.map((x) => (x.id === c.id ? { ...x, ...f } : x)) : [...arr, { id: uid8(), topics: [], rev: [false, false, false], weak: false, imp: '', ...f }])),
    onDelete: c ? () => saveChapters(curSub, (arr) => arr.filter((x) => x.id !== c.id)) : null
  });
}
function bulkForm(prefill = '') {
  formSheet({
    title: 'Chapters add karo', saveLabel: 'Add karo', values: { txt: prefill },
    fields: [{ k: 'txt', l: 'Har line ek chapter', t: 'textarea', rows: 8, max: 3000, ph: 'Real Numbers\nPolynomials\nTriangles' }],
    onSave: (f) => {
      const names = parseChapters(f.txt); if (!names.length) return toast('Koi chapter nahi mila');
      saveChapters(curSub, (arr) => { const have = new Set(arr.map((c) => c.name.toLowerCase())); return [...arr, ...names.filter((n) => !have.has(n.toLowerCase())).map((name) => ({ id: uid8(), name, status: 'pending', prio: 'med', topics: [], rev: [false, false, false], weak: false, imp: '' }))]; });
      toast(`${names.length} chapters add hue`);
    }
  });
}
async function importChapters() {
  const f = await pickFile('image/*,application/pdf'); if (!f) return;
  try { const t = await extractText(f); bulkForm(parseChapters(t).join('\n')); toast('Check karke edit kar lo, phir Add karo'); }
  catch (e) { console.warn(e); toast('File padh nahi paya. Internet check karo ya chapters type karo'); bulkForm(''); }
}
function openChapter(cid) {
  curCh = cid; const c = (find('subjects', curSub).chapters || []).find((x) => x.id === cid);
  openSub(c.name, renderChapter, `<button class="addbtn" data-act="chapedit" data-cid="${cid}" aria-label="Edit">${ic(P.edit, 18, 2)}</button>`);
}
function renderChapter(body) {
  const s = find('subjects', curSub), c = s && (s.chapters || []).find((x) => x.id === curCh);
  if (!c) { body.innerHTML = emptyBox('Chapter nahi mila'); return; }
  const tp = c.topics || [], rev = c.rev || [false, false, false];
  body.innerHTML = `<div class="chips">${Object.entries(ST).map(([k, v]) => `<button class="chip" data-act="chapset" data-v="${k}" aria-pressed="${(c.status || 'pending') === k}">${v[0]}</button>`).join('')}</div>
<div class="mono lbl">TOPICS · ${tp.filter((t) => t.d).length}/${tp.length}</div>
${tp.map((t) => `<div class="chrow"><button class="tick" role="checkbox" aria-checked="${!!t.d}" data-act="topictoggle" data-tid="${t.id}" aria-label="${esc(t.t)}">${t.d ? ic(P.check, 18, 3) : ''}</button><div class="tmain"><b>${esc(t.t)}</b></div><button class="xb" data-act="topicdel" data-tid="${t.id}" aria-label="Delete">${ic(P.x, 14, 2)}</button></div>`).join('')}
<form class="inl" data-act="none" id="topic-form"><input id="topic-in" maxlength="60" placeholder="Naya topic likho" autocomplete="off"><button class="send" type="submit" aria-label="Add">${ic(P.plus, 20, 2.2)}</button></form>
<div class="mono lbl">REVISION</div><div class="chips">${['First', 'Second', 'Final'].map((n, i) => `<button class="chip" data-act="revtoggle" data-i="${i}" aria-pressed="${!!rev[i]}">${n}</button>`).join('')}
<button class="chip" data-act="weaktoggle" aria-pressed="${!!c.weak}">Weak topic</button></div>
<button class="btn soft" data-act="revtask">${ic(P.bell, 18, 2)}Revision task banao (kal)</button>
<div class="field"><label class="mono lbl" for="imp-in">IMPORTANT QUESTIONS</label><textarea id="imp-in" rows="4" maxlength="1500" placeholder="Yaad rakhne wale sawaal">${esc(c.imp || '')}</textarea></div>`;
  $('#topic-form').onsubmit = (e) => {
    e.preventDefault(); const v = $('#topic-in').value.trim(); if (!v) return;
    topicFocus = true;
    patchChapter((x) => { x.topics = [...(x.topics || []), { id: uid8(), t: v, d: false }]; autoStatus(x); });
  };
  if (topicFocus) { topicFocus = false; $('#topic-in').focus(); }
  $('#imp-in').onchange = () => patchChapter((x) => { x.imp = $('#imp-in').value.trim(); });
}
function autoStatus(c) { const t = c.topics || []; if (!t.length) return; const d = t.filter((x) => x.d).length; c.status = d === t.length ? 'completed' : d > 0 ? 'ongoing' : 'pending'; }
function patchChapter(fn) {
  const wasDone = ((find('subjects', curSub).chapters || []).find((x) => x.id === curCh) || {}).status === 'completed';
  saveChapters(curSub, (arr) => arr.map((x) => { if (x.id !== curCh) return x; const y = { ...x }; fn(y); return y; }));
  const now = ((find('subjects', curSub).chapters || []).find((x) => x.id === curCh) || {}).status === 'completed';
  if (now && !wasDone) awardXP(20, 'chapter complete');
}

/* ================= DATESHEET ================= */
let dsView = 'list', dsMonth = null;
export function openDatesheet() {
  dsMonth = dsMonth || todayKey().slice(0, 7);
  openSub('Datesheet', renderDatesheet, `<button class="addbtn" data-act="examimport" aria-label="Import">${ic(P.camera, 18, 2)}</button><button class="addbtn" data-act="examadd" aria-label="Exam add">${ic(P.plus, 20, 2)}</button>`);
}
const examRow = (x) => {
  const n = daysBetween(todayKey(), x.date);
  return `<div class="exrow" data-act="examedit" data-id="${x.id}"><div class="exd"><b>${fromYmd(x.date).getDate()}</b><span class="mono">${fromYmd(x.date).toLocaleDateString('en-IN', { month: 'short' })}</span></div>
<div class="tmain"><b>${esc(x.subject || x.name)}</b><div class="tmeta mono">${esc(x.name && x.subject ? x.name + ' · ' : '')}${x.start || ''}${x.end ? '–' + x.end : ''}${x.loc ? ' · ' + esc(x.loc) : ''}</div>${x.notes ? `<div class="tdesc">${esc(x.notes)}</div>` : ''}</div>
<div class="cd ${n < 0 ? 'past' : n <= 3 ? 'hot' : ''}"><b>${n < 0 ? '✓' : n}</b><span class="mono">${n < 0 ? 'ho gaya' : n === 0 ? 'aaj' : 'din'}</span></div></div>`;
};
function renderDatesheet(body) {
  const ex = [...D.exams].sort((a, b) => (a.date + (a.start || '')).localeCompare(b.date + (b.start || '')));
  let inner;
  if (dsView === 'list') {
    const up = ex.filter((x) => x.date >= todayKey()), past = ex.filter((x) => x.date < todayKey());
    inner = (up.length ? up.map(examRow).join('') : emptyBox('Koi upcoming exam nahi. + dabao ya datesheet import karo.')) + (past.length ? `<div class="mono lbl">HO CHUKE</div>${past.reverse().map(examRow).join('')}` : '');
  } else {
    const [y, m] = dsMonth.split('-').map(Number), first = new Date(y, m - 1, 1).getDay(), days = new Date(y, m, 0).getDate();
    let cells = '<i></i>'.repeat(first);
    for (let d = 1; d <= days; d++) { const ds = `${y}-${pad(m)}-${pad(d)}`, has = ex.filter((x) => x.date === ds); cells += `<button class="c ${has.length ? 'done' : ''} ${ds === todayKey() ? 'today' : ''}" data-act="examday" data-v="${ds}">${d}</button>`; }
    const inMonth = ex.filter((x) => x.date.startsWith(dsMonth));
    inner = `<div class="card-big cal"><div class="cal-h"><button class="ibtn" data-act="dsmonth" data-v="-1" aria-label="Pichla mahina">${ic(P.back, 18, 2)}</button><b>${new Date(y, m - 1, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}</b><button class="ibtn" data-act="dsmonth" data-v="1" aria-label="Agla mahina">${ic(P.arrow, 18, 2)}</button></div>
<div class="grid7">${WD.map((w) => `<span class="mono lbl">${w[0]}</span>`).join('')}${cells}</div></div>${inMonth.map(examRow).join('')}`;
  }
  body.innerHTML = seg([['list', 'List'], ['cal', 'Calendar']], dsView, 'dsview') + inner;
}
export function examForm(id, preset = {}) {
  const x = id ? find('exams', id) : null;
  formSheet({
    title: x ? 'Exam edit' : 'Exam add karo', values: x || preset,
    fields: [{ k: 'name', l: 'Exam ka naam', max: 40, ph: 'Half yearly / Unit test' }, { k: 'subject', l: 'Subject', req: 1, max: 40 },
      { k: 'date', l: 'Date', t: 'date', req: 1 }, { k: 'start', l: 'Start time', t: 'time' }, { k: 'end', l: 'End time', t: 'time' },
      { k: 'loc', l: 'Location / room', max: 60 }, { k: 'notes', l: 'Instructions', t: 'textarea', max: 400 }],
    onSave: (f) => { if (x) upd('exams', x.id, f); else add('exams', f); syncNotif(); },
    onDelete: x ? () => { del('exams', x.id); syncNotif(); } : null
  });
}
/* ----- smart import ----- */
let IMP = null;
async function importDatesheet(textOverride) {
  let text = textOverride;
  if (text == null) {
    const f = await pickFile('image/*,application/pdf'); if (!f) return;
    try { text = await extractText(f); } catch (e) { console.warn(e); toast('Auto-read nahi hua. Text paste kar do.'); return pasteDatesheet(); }
  }
  const r = parseDatesheet(text);
  if (!r.rows.length) { toast('Koi date nahi mili. Text paste karke dekho.'); return pasteDatesheet(text); }
  IMP = { rows: r.rows.map((x) => ({ ...x, on: true })), notes: r.notes.join(' '), text };
  openSub('Datesheet check karo', renderImport);
}
function pasteDatesheet(pre = '') {
  formSheet({ title: 'Datesheet text paste karo', saveLabel: 'Padho', values: { t: pre }, fields: [{ k: 't', l: 'Text', t: 'textarea', rows: 8, max: 5000, ph: '12/12/2026 Maths 10:00-13:00' }], onSave: (f) => importDatesheet(f.t) });
}
function renderImport(body) {
  body.innerHTML = `<div class="warnbox">Ye auto-read hai, galtiyan ho sakti hain. Har date check karke hi save karo.</div>
${IMP.rows.map((r, i) => `<div class="improw ${r.on ? '' : 'off'}"><div class="imphead"><button class="tick" role="checkbox" aria-checked="${r.on}" data-act="impon" data-i="${i}">${r.on ? ic(P.check, 18, 3) : ''}</button><input data-imp="subject" data-i="${i}" value="${esc(r.subject)}" aria-label="Subject" maxlength="50"></div>
<div class="imp3"><input type="date" data-imp="date" data-i="${i}" value="${r.date}" aria-label="Date"><input type="time" data-imp="start" data-i="${i}" value="${r.start}" aria-label="Start"><input type="time" data-imp="end" data-i="${i}" value="${r.end}" aria-label="End"></div>
${r.ambig ? '<div class="flag mono">Date dd/mm maani gayi, check karo</div>' : ''}${r.yearGuess ? '<div class="flag mono">Saal andaaze se laga, check karo</div>' : ''}<div class="src mono">${esc(r.src)}</div></div>`).join('')}
${IMP.notes ? `<div class="field"><label class="mono lbl" for="imp-notes">INSTRUCTIONS (sabhi exams me jodein)</label><textarea id="imp-notes" rows="3" maxlength="400">${esc(IMP.notes)}</textarea></div>` : ''}
<button class="btn" data-act="impsave">Selected exams save karo</button>`;
}
document.addEventListener('input', (e) => {
  const el = e.target; if (!IMP || !el.dataset || !el.dataset.imp) return;
  IMP.rows[Number(el.dataset.i)][el.dataset.imp] = el.value;
});

/* ================= REVISION ================= */
export function openRevision() { openSub('Revision manager', renderRevision); }
function renderRevision(body) {
  const rows = D.subjects.flatMap((s) => (s.chapters || []).map((c) => ({ s, c })));
  const weak = rows.filter((r) => r.c.weak), due = rows.filter((r) => r.c.status === 'completed' && !(r.c.rev || []).every(Boolean)), imp = rows.filter((r) => r.c.imp);
  const line = (r, i) => `<div class="chrow"><div class="tmain" data-act="revopen" data-sid="${r.s.id}" data-cid="${r.c.id}"><b>${esc(r.c.name)}</b><div class="tmeta mono">${esc(r.s.name)}</div></div>${['1', '2', 'F'].map((n, k) => `<button class="chip sm" data-act="revq" data-sid="${r.s.id}" data-cid="${r.c.id}" data-i="${k}" aria-pressed="${!!(r.c.rev || [])[k]}">${n}</button>`).join('')}</div>`;
  body.innerHTML = `<div class="mono lbl">REVISION DUE · ${due.length}</div>${due.length ? due.map(line).join('') : emptyBox('Complete hue chapters ki revision yahan aayegi.')}
<div class="mono lbl">WEAK TOPICS · ${weak.length}</div>${weak.length ? weak.map(line).join('') : emptyBox('Kuch weak mark nahi kiya.')}
<div class="mono lbl">IMPORTANT QUESTIONS</div>${imp.length ? imp.map((r) => `<div class="card-big"><b>${esc(r.c.name)}</b> <span class="mono">${esc(r.s.name)}</span><div class="tdesc pre">${esc(r.c.imp)}</div></div>`).join('') : emptyBox('Chapter ke andar important questions likho.')}`;
}

/* ================= SCORES ================= */
export function openScores() { openSub('Test scores', renderScores, `<button class="addbtn" data-act="scoreadd" aria-label="Score add">${ic(P.plus, 20, 2)}</button>`); }
const tests = () => D.scores.filter((s) => s.kind !== 'brain' && s.total);
function renderScores(body) {
  const list = [...tests()].sort((a, b) => b.date.localeCompare(a.date));
  const by = {}; list.forEach((s) => { (by[s.subject] = by[s.subject] || []).push(s); });
  body.innerHTML = `${Object.entries(by).map(([k, v]) => { const avg = Math.round(v.reduce((a, s) => a + s.marks / s.total * 100, 0) / v.length); return `<div class="card-big"><div class="cal-h"><b>${esc(k)}</b><span class="mono">avg ${avg}%</span></div>${bar(avg, 8)}</div>`; }).join('')}
<div class="mono lbl">HISTORY</div>${list.length ? list.map((s) => `<div class="exrow" data-act="scoreedit" data-id="${s.id}"><div class="exd"><b>${Math.round(s.marks / s.total * 100)}</b><span class="mono">%</span></div><div class="tmain"><b>${esc(s.name || s.subject)}</b><div class="tmeta mono">${esc(s.subject)} · ${s.marks}/${s.total} · ${fmtD(s.date)}</div></div></div>`).join('') : emptyBox('Test ke marks add karo, progress dikhegi.')}`;
}
function scoreForm(id) {
  const x = id ? find('scores', id) : null;
  formSheet({
    title: x ? 'Score edit' : 'Test score', values: x || { date: todayKey() },
    fields: [{ k: 'subject', l: 'Subject', req: 1, max: 40 }, { k: 'name', l: 'Test ka naam', max: 40 }, { k: 'marks', l: 'Marks mile', t: 'number', req: 1, min: 0 }, { k: 'total', l: 'Total marks', t: 'number', req: 1, min: 1 }, { k: 'date', l: 'Date', t: 'date', req: 1 }],
    onSave: (f) => { if (x) upd('scores', x.id, f); else add('scores', f); },
    onDelete: x ? () => del('scores', x.id) : null
  });
}

/* ================= PLANNER =================
   Pehle planner sirf STUDY_KINDS dikhata tha, isliye default 'task'
   wale saare tasks invisible the — planner khaali lagta tha.
   Ab: har task type dikhta hai, backlog alag, aur smart plan
   din ke hisaab se spread karke sessions banata hai.            */
let plView = 'today';
export function openPlanner() { openSub('Study planner', renderPlanner, `<button class="addbtn" data-act="taskadd" aria-label="Session add">${ic(P.plus, 20, 2)}</button>`); }

const KIND_C = {
  homework: '#8FB8DE', assignment: '#B7A6E0', project: '#E8B96F', backlog: '#A2A496',
  study: '#C8F23A', revision: '#9AD1B5', test: '#FF8FB1', task: '#C8F23A'
};
const kindLabel = (k) => k || 'task';
const prioC = (p) => ({ high: '#FF9A8A', med: '#F2C94C', low: '#8FD19E' }[p] || '#C8F23A');

function taskRow(t) {
  const done = !!t.done;
  return `<div class="plrow ${done ? 'done' : ''}">
  <button class="tick sm" role="checkbox" aria-checked="${done}" data-act="taskdone" data-id="${t.id}" aria-label="${esc(t.title)} done">${done ? ic(P.check, 14, 3) : ''}</button>
  <span class="mono">${t.dueTime || '—'}</span>
  <b data-act="taskedit" data-id="${t.id}">${esc(t.title)}</b>
  <em class="mono">${kindLabel(t.kind)}</em></div>`;
}

/* ek din ka poora schedule: exam + event + task (SAARE types) */
function dayItems(d) {
  const t0 = todayKey(), rows = [];
  D.exams.filter((x) => x.date === d).forEach((x) => rows.push({
    time: x.start || '00:00',
    html: `<div class="plrow exam" data-act="examedit" data-id="${x.id}"><span class="mono">${x.start || ''}</span><b>Exam: ${esc(x.subject || x.name)}</b><em class="mono">${rel(x.date)}</em></div>`
  }));
  D.events.filter((e) => occurrences(e, d, d).length).forEach((e) => rows.push({
    time: e.time || '23:59',
    html: `<div class="plrow ev" data-act="evedit" data-id="${e.id}"><span class="mono">${e.time || '—'}</span><b>${esc(e.title)}</b><em class="mono">event</em></div>`
  }));
  D.tasks.filter((t) => t.due === d && (!t.done || d === t0)).forEach((t) => rows.push({
    time: t.dueTime || '99:99',
    html: taskRow(t)
  }));
  return rows.sort((a, b) => a.time.localeCompare(b.time)).map((x) => x.html).join('');
}

/* backlog: date nahi di ya overdue */
function backlogTasks() {
  const t0 = todayKey();
  return D.tasks.filter((t) => !t.done && (!t.due || t.due < t0))
    .sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999'));
}

function plannerStats() {
  const t0 = todayKey();
  const todays = D.tasks.filter((t) => t.due === t0);
  const done = todays.filter((t) => t.done).length;
  const mins = D.sessions.filter((s) => s.date === t0 && s.kind !== 'break').reduce((a, s) => a + (s.mins || 0), 0);
  return { total: todays.length, done, mins, left: todays.length - done };
}

function renderPlanner(body) {
  const t0 = todayKey();
  const st = plannerStats();
  const nUp = upcomingExams()[0];
  const days = plView === 'today' ? [t0]
    : plView === 'tomorrow' ? [addDaysY(t0, 1)]
      : Array.from({ length: 7 }, (_, i) => addDaysY(t0, i));
  const bl = backlogTasks();
  const head = `<div class="plsum">
  <div class="pls"><b>${st.left}</b><span class="mono">bacha</span></div>
  <div class="pls"><b>${st.done}/${st.total || 0}</b><span class="mono">done</span></div>
  <div class="pls"><b>${Math.round(st.mins)}m</b><span class="mono">focus</span></div>
  <div class="pls"><b>${bl.length}</b><span class="mono">backlog</span></div>
</div>`;
  const examCard = nUp ? `<button class="card-big exc" data-act="studyopen" data-v="datesheet"><div class="cal-h"><b>${esc(nUp.subject || nUp.name)}</b><span class="mono">${rel(nUp.date)}</span></div><div class="mono lbl">AGLA EXAM · ${fmtDW(nUp.date)}</div></button>` : '';
  const body1 = plView === 'backlog'
    ? `<div class="mono lbl">DATE NAHI DI / OVERDUE</div>
${bl.length ? bl.map((t) => `<div class="plrow"><button class="tick sm" role="checkbox" aria-checked="false" data-act="taskdone" data-id="${t.id}">${''}</button><span class="mono">${t.due ? fmtD(t.due) : '—'}</span><b data-act="taskedit" data-id="${t.id}">${esc(t.title)}</b><em class="mono">${kindLabel(t.kind)}</em>
<button class="chip sm" data-act="plandue" data-id="${t.id}" data-v="${t0}">aaj</button><button class="chip sm" data-act="plandue" data-id="${t.id}" data-v="${addDaysY(t0, 1)}">kal</button></div>`).join('')
      : emptyBox('Backlog khaali hai — sab kuch plan me hai. ✨')}
<button class="btn soft" data-act="plandueall" data-v="${t0}">Sab backlog aaj me daal do</button>`
    : `${days.map((d) => {
      const cnt = D.tasks.filter((t) => t.due === d && !t.done).length + D.exams.filter((x) => x.date === d).length;
      return `<div class="dayhead"><span class="mono lbl">${d === t0 ? 'AAJ' : fmtDW(d).toUpperCase()}</span>${d === t0 ? `<span class="mono nowl">● ${cnt} item${cnt === 1 ? '' : 's'}</span>` : ''}</div>${dayItems(d) || '<div class="plrow empty-s mono">Kuch planned nahi — koi task add karo</div>'}`;
    }).join('')}`;
  body.innerHTML = `${head}
${seg([['today', 'Aaj'], ['tomorrow', 'Kal'], ['week', 'Week'], ['backlog', 'Backlog']], plView, 'plview')}
${examCard}
${body1}
<button class="btn" data-act="smartplan">${ic(P.spark, 20, 2)}Smart study plan banao</button>
<div class="mono lbl">MANAGERS</div>
<div class="tiles">${[['homework', 'Homework'], ['assignment', 'Assignments'], ['project', 'Projects'], ['backlog', 'Backlog'], ['revision', 'Revision'], ['test', 'Practice tests']].map(([k, l]) => `<button class="tile" data-act="kindopen" data-v="${k}"><b>${l}</b><span class="mono">${D.tasks.filter((t) => t.kind === k && !t.done).length} pending</span></button>`).join('')}</div>`;
}

/* Rule-based planner: user approve kare tabhi tasks bante hain.
   Sessions exam ke aage spread hoti hain (sab ek din pe nahi), aur
   exam na ho to bhi backlog tasks se plan ban jata hai.            */
export function suggestPlan() {
  const t0 = todayKey(), out = [];
  const have = new Set(D.tasks.map((t) => t.title + '|' + t.due));
  const used = {};                                   /* day -> kitni sessions */
  const slotTime = (d) => {
    const n = used[d] || 0; used[d] = n + 1;
    const base = 17 * 60 + n * 75;
    return pad(Math.floor(base / 60) % 24) + ':' + pad(base % 60);
  };

  /* 1) exams ke liye chapter-wise study sessions, din me spread */
  const ex = upcomingExams().filter((x) => daysBetween(t0, x.date) >= 0 && daysBetween(t0, x.date) <= 30).slice(0, 6);
  ex.forEach((x) => {
    const left = Math.max(1, daysBetween(t0, x.date));
    const sub = D.subjects.find((s) => (s.name || '').toLowerCase() === String(x.subject || '').toLowerCase());
    if (!sub) return;
    const chs = (sub.chapters || []).filter((c) => chapterProgress(c) < 1).sort(sortCh);
    if (!chs.length) return;
    const slots = Math.max(1, Math.min(chs.length, Math.ceil(left / 2), 6));
    for (let i = 0; i < slots; i++) {
      let off = slots === 1 ? Math.floor((left - 1) / 2) : Math.round((i / (slots - 1)) * (left - 1) * 0.72);
      off = Math.max(0, Math.min(left - 1, off));
      const d = addDaysY(t0, off);
      if (d >= x.date) break;
      const ch = chs[i % chs.length];
      const title = `${sub.name}: ${ch.name}`;
      if (have.has(title + '|' + d)) continue;
      out.push({ title, date: d, time: slotTime(d), why: `${x.subject || x.name} exam ${rel(x.date)}`, kind: 'study' });
    }
    /* weak chapters -> revision */
    const weak = (sub.chapters || []).filter((c) => c.weak && chapterProgress(c) < 1).slice(0, 2);
    weak.forEach((c) => {
      const d = addDaysY(t0, Math.max(0, left - 1));
      const title = `Revise ${sub.name}: ${c.name}`;
      if (have.has(title + '|' + d)) return;
      out.push({ title, date: d, time: slotTime(d), why: 'weak chapter', kind: 'revision' });
    });
  });

  /* 2) overdue / date-less backlog -> aaj ya kal */
  backlogTasks().slice(0, 6).forEach((t, i) => {
    const d = addDaysY(t0, i < 3 ? 0 : 1);
    out.push({ title: t.title, date: d, time: slotTime(d), why: t.due ? `${fmtD(t.due)} ka backlog` : 'plan nahi hua', kind: t.kind || 'task' });
  });

  /* 3) aaj/tomorrow due tasks jinke time nahi di */
  D.tasks.filter((t) => !t.done && (t.due === t0 || t.due === addDaysY(t0, 1)) && !t.dueTime).slice(0, 4).forEach((t) => {
    out.push({ title: t.title, date: t.due, time: slotTime(t.due), why: 'time fix karo', kind: t.kind || 'task' });
  });

  return out.slice(0, 16);
}
let PLAN = null;
function openSmartPlan() {
  PLAN = suggestPlan().map((x) => ({ ...x, on: true }));
  openSub('Smart plan', (body) => {
    body.innerHTML = PLAN.length ? `<div class="warnbox">Ye sirf suggestions hain. Jo chahiye wahi chuno, kuch bhi apne aap save nahi hoga.</div>${PLAN.map((p, i) => `<div class="chrow"><button class="tick" role="checkbox" aria-checked="${p.on}" data-act="planon" data-i="${i}">${p.on ? ic(P.check, 18, 3) : ''}</button><div class="tmain"><b>${esc(p.title)}</b><div class="tmeta mono">${fmtDW(p.date)} · ${p.time} · ${esc(p.why)}</div></div></div>`).join('')}<button class="btn" data-act="plansave">Selected sessions add karo</button>`
      : `<div class="empty">Abhi koi suggestion nahi bana. Task ya exam add karo — phir planner khud plan banayega.</div><button class="btn soft" data-act="plview" data-v="backlog">Backlog dekho</button>`;
  });
}

/* ================= STUDY TAB ================= */
export function studyPageHTML() {
  const nx = upcomingExams()[0], tp = totalProgress();
  const tiles = [['syllabus', 'Syllabus', `${tp}% complete`], ['datesheet', 'Datesheet', `${upcomingExams().length} upcoming`], ['planner', 'Planner', 'Timetable + homework'], ['revision', 'Revision', `${D.subjects.flatMap((s) => (s.chapters || []).filter((c) => c.weak)).length} weak`], ['scores', 'Test scores', `${tests().length} tests`], ['focus', 'Focus', 'Pomodoro timer']];
  return `<div class="phead"><h1>Study</h1><button class="addbtn" data-act="taskadd" data-kind="study" aria-label="Study task add">${ic(P.plus, 20, 2)}</button></div>
${heroArt('assets/art/hero-study.webp', 'STUDY MODE', tp >= 100 ? 'Syllabus complete!' : `${tp}% syllabus done`, tp >= 100 ? 'Ab revision aur practice pe focus karo.' : 'Chapters complete karo, scores badhao.')}
${nx ? `<div class="lime2"><div class="mono lbl-d">AGLA EXAM</div><h2>${esc(nx.subject || nx.name)}</h2><p>${rel(nx.date)} · ${fmtDW(nx.date)}${nx.start ? ' · ' + nx.start : ''}</p></div>` : `<div class="lime2"><div class="mono lbl-d">DATESHEET</div><h2>Exam add karo</h2><p>Datesheet photo/PDF se bhi import ho jati hai.</p><button class="btn dark" data-act="studyopen" data-v="datesheet">Datesheet kholo</button></div>`}
<div class="tiles">${tiles.map(([k, l, s]) => `<button class="tile" data-act="studyopen" data-v="${k}"><b>${l}</b><span class="mono">${s}</span></button>`).join('')}</div>
${D.subjects.length ? `<div class="mono lbl">SUBJECT PROGRESS</div>${D.subjects.map((s, i) => `<button class="subj" data-act="subjopen" data-id="${s.id}"><span class="sbar" style="background:${s.color || COLORS[i % 8]}"></span><div><b>${esc(s.name)}</b>${bar(subjectProgress(s), 6)}</div><em class="mono">${subjectProgress(s)}%</em></button>`).join('')}` : ''}`;
}
export function openStudyItem(k) {
  ({ syllabus: openSyllabus, datesheet: openDatesheet, planner: openPlanner, revision: openRevision, scores: openScores })[k]?.();
}

/* ================= click handling ================= */
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v, cid = b.dataset.cid;
  switch (a) {
    case 'studyopen': if (v === 'focus') import('./tasks.js').then((m) => m.openFocus()); else openStudyItem(v); break;
    case 'studyprof': studyProfForm(); break;
    case 'subjadd': subjectForm(); break;
    case 'subjedit': subjectForm(id); break;
    case 'subjopen': openSubject(id); break;
    case 'chapadd': chapterForm(); break;
    case 'chapedit': chapterForm(cid); break;
    case 'chapbulk': bulkForm(); break;
    case 'chapimport': importChapters(); break;
    case 'chapopen': openChapter(cid); break;
    case 'chapcycle': {
      const ch = (find('subjects', curSub).chapters || []).find((x) => x.id === cid), nx = NEXT[ch.status || 'pending'];
      saveChapters(curSub, (arr) => arr.map((x) => (x.id === cid ? { ...x, status: nx, topics: (x.topics || []).map((t) => ({ ...t, d: nx === 'completed' ? true : nx === 'pending' ? false : t.d })) } : x)));
      if (nx === 'completed') awardXP(20, 'chapter complete'); break;
    }
    case 'chapset': patchChapter((x) => { x.status = v; if (v === 'completed') x.topics = (x.topics || []).map((t) => ({ ...t, d: true })); }); break;
    case 'topictoggle': patchChapter((x) => { x.topics = x.topics.map((t) => (t.id === b.dataset.tid ? { ...t, d: !t.d } : t)); autoStatus(x); }); break;
    case 'topicdel': patchChapter((x) => { x.topics = x.topics.filter((t) => t.id !== b.dataset.tid); autoStatus(x); }); break;
    case 'revtoggle': patchChapter((x) => { const r = [...(x.rev || [false, false, false])]; r[Number(b.dataset.i)] = !r[Number(b.dataset.i)]; x.rev = r; if (r[Number(b.dataset.i)]) awardXP(5, 'revision'); }); break;
    case 'weaktoggle': patchChapter((x) => { x.weak = !x.weak; }); break;
    case 'revtask': { const c = (find('subjects', curSub).chapters || []).find((x) => x.id === curCh); add('tasks', { title: `Revise: ${c.name}`, kind: 'revision', prio: 'med', due: addDaysY(todayKey(), 1), dueTime: '18:00', repeat: 'none', rem: 0, done: false, subs: [] }); syncNotif(); toast('Kal ke liye revision task ban gaya'); break; }
    case 'revopen': curSub = b.dataset.sid; openChapter(cid); break;
    case 'revq': {
      curSub = b.dataset.sid; curCh = cid; const k = Number(b.dataset.i);
      patchChapter((x) => { const r = [...(x.rev || [false, false, false])]; r[k] = !r[k]; x.rev = r; }); break;
    }
    case 'dsview': dsView = v; refreshSub(); break;
    case 'dsmonth': { const [y, m] = dsMonth.split('-').map(Number), d = new Date(y, m - 1 + Number(v), 1); dsMonth = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; refreshSub(); break; }
    case 'examadd': examForm(null); break;
    case 'examedit': examForm(id); break;
    case 'examday': examForm(null, { date: v }); break;
    case 'examimport': formSheet({ title: 'Datesheet import', saveLabel: 'Photo / PDF chuno', values: {}, fields: [], extraHtml: '<p class="sub">Photo ya PDF se dates nikalta hoon. Save karne se pehle tum check karoge. Text paste bhi kar sakte ho.</p><button class="btn soft" type="button" data-act="examimport2">Text paste karo</button>', onSave: () => importDatesheet() }); break;
    case 'examimport2': $('[data-act=fcancel]') && $('[data-act=fcancel]').click(); setTimeout(() => pasteDatesheet(), 50); break;
    case 'impon': IMP.rows[Number(b.dataset.i)].on = !IMP.rows[Number(b.dataset.i)].on; refreshSub(); break;
    case 'impsave': {
      const notes = ($('#imp-notes') || {}).value || '';
      const bad = IMP.rows.filter((r) => r.on && (!r.subject.trim() || !/^\d{4}-\d{2}-\d{2}$/.test(r.date)));
      if (bad.length) return toast('Kuch rows me subject ya date galat hai');
      const pick = IMP.rows.filter((r) => r.on); if (!pick.length) return toast('Kuch select karo');
      pick.forEach((r) => add('exams', { name: '', subject: r.subject.trim(), date: r.date, start: r.start || '', end: r.end || '', loc: '', notes: notes.slice(0, 400) }));
      syncNotif(); toast(`${pick.length} exams save ho gaye`); IMP = null; $('[data-act=subback]').click(); break;
    }
    case 'scoreadd': scoreForm(); break;
    case 'scoreedit': scoreForm(id); break;
    case 'plview': plView = v; refreshSub(); break;
    case 'plandue': { const t = find('tasks', id); if (!t) break; upd('tasks', id, { due: v, dueTime: t.dueTime || '18:00' }); syncNotif(); toast('Plan me daal diya: ' + fmtD(v)); refreshSub(); break; }
    case 'plandueall': {
      const bl = D.tasks.filter((t) => !t.done && (!t.due || t.due < todayKey()));
      if (!bl.length) return toast('Backlog khaali hai');
      bl.forEach((t) => upd('tasks', t.id, { due: v, dueTime: t.dueTime || '18:00' }));
      syncNotif(); toast(`${bl.length} tasks aaj me daal diye`); refreshSub(); break;
    }
    case 'kindopen': openTasks(v); break;
    case 'smartplan': openSmartPlan(); break;
    case 'planon': PLAN[Number(b.dataset.i)].on = !PLAN[Number(b.dataset.i)].on; refreshSub(); break;
    case 'plansave': {
      const pick = PLAN.filter((p) => p.on); if (!pick.length) return toast('Kuch select karo');
      pick.forEach((p) => add('tasks', { title: p.title, kind: p.kind, prio: 'med', due: p.date, dueTime: p.time, repeat: 'none', rem: 10, done: false, subs: [] }));
      syncNotif(); toast(`${pick.length} sessions add ho gaye`); $('[data-act=subback]').click(); break;
    }
  }
});
