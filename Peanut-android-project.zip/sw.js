const CACHE = 'peanut-v4';
const SHELL = ['./', 'index.html', 'style.css', 'app.js', 'core.js', 'notify.js', 'avatar.js', 'emoji.js', 'tasks.js', 'study.js', 'life.js', 'insights.js', 'games.js', 'home.js', 'parse.js', 'music.js', 'localmusic.js', 'opentune.js', 'i18n.js', 'firebase-config.js', 'manifest.json',
  'i18n/en.js', 'i18n/hi.js', 'i18n/bn.js', 'i18n/ta.js', 'i18n/te.js', 'i18n/kn.js', 'i18n/ml.js', 'i18n/gu.js', 'i18n/pa.js', 'i18n/mr.js',
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/maskable-512.png', 'icons/apple-touch-icon.png',
  'music/manifest.json',
  'assets/art/hero-home.webp', 'assets/art/hero-community.webp', 'assets/art/hero-study.webp',
  'assets/art/hero-tracker.webp', 'assets/art/hero-music.webp', 'assets/art/hero-games.webp',
  'assets/art/mascot-solo.webp', 'assets/art/login-banner.webp'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Same-origin files: network first, offline pe cache. Firebase calls ko haath nahi lagate.
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin) return;
  e.respondWith(
    fetch(req)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy));
        return res;
      })
      .catch(() => caches.match(req).then((r) => r || caches.match('index.html')))
  );
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) if ('focus' in c) return c.focus();
      return self.clients.openWindow('./');
    })
  );
});
