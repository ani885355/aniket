/* Tasks, habits, focus timer */
import {
  $, $$, esc, S, D, store, toast, ic, P, add, upd, del, find, openSub, refreshSub, formSheet, awardXP, bar, seg, emptyBox, PRIO, dot,
  todayKey, addDaysY, fromYmd, ymd, fmtD, rel, fmtMin, pad, uid8, WD, daysBetween, addDays, openOv, closeOv, saveMe, fail, updRaw, arrayUnion, arrayRemove
} from './core.js';
import { sync as syncNotif, snooze } from './notify.js';
import { pickEmoji } from './emoji.js';

/* ================= TASKS ================= */
export const KINDS = [['task', 'Task'], ['homework', 'Homework'], ['assignment', 'Assignment'], ['project', 'Project'], ['backlog', 'Backlog'], ['study', 'Study session'], ['revision', 'Revision'], ['test', 'Practice test']];
const kindName = (k) => (KINDS.find((x) => x[0] === k) || KINDS[0])[1];
let tView = 'today', tKind = 'all';

export const isOverdue = (t) => !t.done && t.due && t.due < todayKey();
export function taskGroups(list = D.tasks) {
  const t0 = todayKey();
  return {
    today: list.filter((t) => !t.done && t.due === t0),
    upcoming: list.filter((t) => !t.done && (!t.due || t.due > t0)).sort((a, b) => (a.due || '9').localeCompare(b.due || '9')),
    overdue: list.filter(isOverdue).sort((a, b) => a.due.localeCompare(b.due)),
    done: list.filter((t) => t.done).sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0))
  };
}
export function openTasks(kindFilter) {
  tKind = kindFilter || 'all'; tView = 'today';
  openSub(kindFilter ? KINDS.find((k) => k[0] === kindFilter)[1] + 's' : 'Tasks', renderTasks,
    `<button class="addbtn" data-act="taskadd" aria-label="Naya task">${ic(P.plus, 20, 2)}</button>`);
}
function taskRow(t) {
  const subs = t.subs || [], sd = subs.filter((s) => s.d).length;
  const pr = PRIO[t.prio] || PRIO.med;
  const sub = subs.map((s) => `<button class="subt ${s.d ? 'on' : ''}" data-act="subtoggle" data-id="${t.id}" data-sid="${s.id}">${ic(P.check, 13, 2.6)}<span>${esc(s.t)}</span></button>`).join('');
  return `<div class="trow ${t.done ? 'done' : ''}"><button class="tick" role="checkbox" aria-checked="${!!t.done}" aria-label="Complete: ${esc(t.title)}" data-act="taskdone" data-id="${t.id}">${t.done ? ic(P.check, 18, 3) : ''}</button>
<div class="tmain" data-act="taskedit" data-id="${t.id}"><b>${esc(t.title)}</b>
<div class="tmeta mono">${dot(pr[1])}${pr[0]}${t.kind && t.kind !== 'task' ? ' · ' + kindName(t.kind) : ''}${t.due ? ` · ${isOverdue(t) ? '<u>' : ''}${fmtD(t.due)}${t.dueTime ? ' ' + t.dueTime : ''}${isOverdue(t) ? '</u>' : ''}` : ''}${t.repeat && t.repeat !== 'none' ? ' · ↻' + t.repeat : ''}${subs.length ? ` · ${sd}/${subs.length}` : ''}${t.cat ? ' · ' + esc(t.cat) : ''}</div>
${t.desc ? `<div class="tdesc">${esc(t.desc)}</div>` : ''}${sub ? `<div class="subs">${sub}</div>` : ''}</div></div>`;
}
function renderTasks(body) {
  let list = D.tasks.filter((t) => tKind === 'all' || t.kind === tKind || (tKind === 'task' && !t.kind));
  const g = taskGroups(list);
  const cur = g[tView];
  body.innerHTML = `${seg([['today', `Today ${g.today.length}`], ['upcoming', 'Upcoming'], ['overdue', `Overdue ${g.overdue.length || ''}`], ['done', 'Done']], tView, 'tview')}
<div class="rows2">${cur.length ? cur.map(taskRow).join('') : emptyBox(tView === 'done' ? 'Abhi tak kuch complete nahi hua. Pehla task chhota rakho.' : tView === 'overdue' ? 'Kuch bakaya nahi. Mast!' : 'Is list me kuch nahi. + dabao.')}</div>`;
}
export function taskForm(id, preset = {}) {
  const t = id ? find('tasks', id) : null;
  const v = t ? { ...t, subs: (t.subs || []).map((s) => s.t).join('\n') } : { prio: 'med', kind: 'task', repeat: 'none', rem: 0, due: todayKey(), ...preset };
  formSheet({
    title: t ? 'Task edit karo' : 'Naya task', values: v, saveLabel: t ? 'Update karo' : 'Task add karo',
    fields: [
      { k: 'title', l: 'Task', req: 1, max: 80, ph: 'Jaise: Maths ex 4.2 karo' },
      { k: 'kind', l: 'Type', t: 'select', o: KINDS },
      { k: 'prio', l: 'Priority', t: 'chips', o: [['low', 'Low'], ['med', 'Medium'], ['high', 'High']] },
      { k: 'due', l: 'Due date', t: 'date' }, { k: 'dueTime', l: 'Due time', t: 'time' },
      { k: 'repeat', l: 'Repeat', t: 'select', o: [['none', 'Nahi'], ['daily', 'Roz'], ['weekly', 'Har hafte'], ['monthly', 'Har mahine']] },
      { k: 'rem', l: 'Reminder', t: 'select', o: [[-1, 'Nahi'], [0, 'Due time pe'], [10, '10 min pehle'], [60, '1 ghanta pehle'], [1440, '1 din pehle']] },
      { k: 'cat', l: 'Category', max: 20, ph: 'Jaise: Ghar, College' },
      { k: 'desc', l: 'Description', t: 'textarea', max: 400 },
      { k: 'subs', l: 'Subtasks (har line ek)', t: 'textarea', rows: 3, max: 600 },
      { k: 'link', l: 'Link / attachment URL', max: 200, ph: 'https://...' }
    ],
    onSave: (f) => {
      const old = new Map(((t && t.subs) || []).map((s) => [s.t, s]));
      const subs = String(f.subs || '').split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 20).map((x) => old.get(x) || { id: uid8(), t: x, d: false });
      const data = { ...f, rem: Number(f.rem), subs };
      if (t) upd('tasks', t.id, data); else add('tasks', { ...data, done: false });
      syncNotif();
    },
    onDelete: t ? () => { del('tasks', t.id); syncNotif(); } : null
  });
}
export function completeTask(id) {
  const t = find('tasks', id); if (!t) return;
  if (t.done) { upd('tasks', id, { done: false, doneAt: null }); return; }
  const gain = t.prio === 'high' ? 15 : 10;
  if (t.repeat && t.repeat !== 'none') {
    const base = t.due && t.due > todayKey() ? t.due : todayKey();
    const next = t.repeat === 'daily' ? addDaysY(base, 1) : t.repeat === 'weekly' ? addDaysY(base, 7) : ymd(new Date(fromYmd(base).getFullYear(), fromYmd(base).getMonth() + 1, fromYmd(base).getDate()));
    upd('tasks', id, { due: next, subs: (t.subs || []).map((s) => ({ ...s, d: false })), lastDone: todayKey(), doneCount: (t.doneCount || 0) + 1 });
    awardXP(gain, 'repeat task');
  } else {
    upd('tasks', id, { done: true, doneAt: Date.now(), doneDate: todayKey(), xpGiven: true });
    if (!t.xpGiven) awardXP(gain, 'task complete');
  }
  syncNotif();
}

/* ================= HABITS ================= */
export const habitActive = (h, ds) => !(h.days && h.days.length) || h.days.map(Number).includes(fromYmd(ds).getDay());
export function habitStreak(h) {
  const log = new Set(h.log || []), skip = new Set(h.skips || []);
  let d = todayKey(), n = 0, guard = 0;
  while (guard++ < 800) {
    if (!habitActive(h, d) || skip.has(d)) { /* rest day: streak nahi tootta */ }
    else if (log.has(d)) n++;
    else if (d !== todayKey()) break;
    d = addDaysY(d, -1);
  }
  return n;
}
export function habitWeek(h, endDay = todayKey()) {
  let sched = 0, done = 0;
  for (let i = 0; i < 7; i++) {
    const d = addDaysY(endDay, -i);
    if (!habitActive(h, d) || (h.skips || []).includes(d)) continue;
    sched++; if ((h.log || []).includes(d)) done++;
  }
  return { sched, done, pct: sched ? Math.round(done / sched * 100) : 0 };
}
export const habitDoneToday = (h) => (h.log || []).includes(todayKey());
const PARTS = [['morning', 'Subah ki routine'], ['day', 'Din'], ['night', 'Raat ki routine']];
export function habitsHTML(compact) {
  const hs = D.habits.filter((h) => !h.archived).sort((a, b) => (a.time || '99').localeCompare(b.time || '99'));
  if (!hs.length) return emptyBox('Koi habit nahi. Pani peena, padhna, walk... kuch bhi add karo.');
  const t0 = todayKey();
  return PARTS.map(([k, lab]) => {
    const list = hs.filter((h) => (h.part || 'day') === k); if (!list.length) return '';
    return `<div class="mono lbl">${lab}</div>` + list.map((h) => {
      const done = habitDoneToday(h), act = habitActive(h, t0), st = habitStreak(h), w = habitWeek(h);
      const dots = Array.from({ length: 7 }, (_, i) => { const d = addDaysY(t0, i - 6); const on = (h.log || []).includes(d); return `<i class="hd ${on ? 'on' : ''} ${!habitActive(h, d) ? 'rest' : ''}"></i>`; }).join('');
      return `<div class="hrow"><button class="tick" role="checkbox" aria-checked="${done}" data-act="habtoggle" data-id="${h.id}" aria-label="${esc(h.name)} aaj ho gaya">${done ? ic(P.check, 18, 3) : ''}</button>
<div class="tmain" data-act="${compact ? 'habcal' : 'habedit'}" data-id="${h.id}"><b>${h.emoji ? esc(h.emoji) + ' ' : ''}${esc(h.name)}</b>
<div class="tmeta mono">${h.time || '--:--'}${!act ? ' · rest day' : ''} · ${w.done}/${w.sched} is hafte</div></div>
<div class="hside"><div class="hdots">${dots}</div><div class="mono hs">${ic(P.flame, 13, 2)}${st}</div></div>
<button class="xb" data-act="habedit" data-id="${h.id}" aria-label="Edit">${ic(P.edit, 16, 2)}</button></div>`;
    }).join('');
  }).join('');
}
export function habitForm(id) {
  const h = id ? find('habits', id) : null;
  formSheet._emoji = undefined;
  formSheet({
    title: h ? 'Habit edit karo' : 'Nayi habit', values: h || { part: 'day', days: [], remind: true, time: '' },
    fields: [
      { k: 'name', l: 'Naam', req: 1, max: 40, ph: 'Jaise: 2 litre paani' },
      { k: 'part', l: 'Kab', t: 'chips', o: [['morning', 'Subah'], ['day', 'Din'], ['night', 'Raat']] },
      { k: 'time', l: 'Reminder time', t: 'time' },
      { k: 'days', l: 'Kin dino pe (khali = roz)', t: 'chips', multi: true, o: WD.map((w, i) => [String(i), w]) },
      { k: 'remind', l: 'Reminder chalu', t: 'check' }
    ],
    extraHtml: `<button class="btn soft" type="button" data-act="habemoji">${h && h.emoji ? esc(h.emoji) : '🙂'} Emoji chuno</button>`,
    onSave: (f) => {
      const data = { ...f, days: (f.days || []).map(Number), emoji: (formSheet._emoji ?? (h && h.emoji)) || '' };
      if (h) upd('habits', h.id, data); else add('habits', { ...data, log: [], skips: [], archived: false });
      formSheet._emoji = undefined; syncNotif();
    },
    onDelete: h ? () => { del('habits', h.id); syncNotif(); } : null
  });
}
export function toggleHabit(id) {
  const h = find('habits', id); if (!h) return;
  const t0 = todayKey(), on = (h.log || []).includes(t0);
  updRaw('habits', id, { log: on ? arrayRemove(t0) : arrayUnion(t0) });
  if (!on) {
    awardXP(5, 'habit');
    const all = D.habits.filter((x) => !x.archived && habitActive(x, t0));
    if (all.length && all.every((x) => x.id === id || habitDoneToday(x))) toast('Aaj ki saari habits poori. Gazab!');
  }
}
export function habitCalendar(id) {
  const h = find('habits', id); if (!h) return;
  const now = new Date(), y = now.getFullYear(), m = now.getMonth(), first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate();
  let cells = '<i></i>'.repeat(first);
  for (let d = 1; d <= days; d++) {
    const ds = `${y}-${pad(m + 1)}-${pad(d)}`, on = (h.log || []).includes(ds), rest = !habitActive(h, ds);
    cells += `<div class="c ${on ? 'done' : ''} ${ds === todayKey() ? 'today' : ''} ${rest ? 'rest' : ''}">${d}</div>`;
  }
  formSheet({
    title: `${h.emoji || ''} ${h.name}`, values: {}, fields: [], saveLabel: 'Ok',
    extraHtml: `<div class="mono lbl">${now.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })} · streak ${habitStreak(h)}</div>
<div class="grid7">${WD.map((w) => `<span class="mono lbl">${w[0]}</span>`).join('')}${cells}</div>
<button class="btn soft" type="button" data-act="habskip" data-id="${h.id}">Aaj rest day (streak nahi tootegi)</button>`,
    onSave: () => {}
  });
}

/* ================= FOCUS ================= */
const PRESETS = [['focus', 25, 'Pomodoro 25'], ['short', 5, 'Short break 5'], ['long', 15, 'Long break 15'], ['deep', 50, 'Deep focus 50'], ['custom', 0, 'Custom']];
const loadF = () => store.json('nnn_focus', { mode: 'idle', kind: 'focus', mins: 25, link: '' });
let F = loadF(), fTick = null, ambient = null;
const saveF = () => { store.setJson('nnn_focus', F); syncNotif(); };
export const focusRunning = () => F.mode === 'run';
export const focusActive = () => F.mode === 'run' || F.mode === 'pause';
const leftMs = () => (F.mode === 'run' ? Math.max(0, F.end - Date.now()) : F.mode === 'pause' ? F.left : F.mins * 60000);
export const focusTarget = () => Number((S.me && S.me.focusTarget) || 120);
export function focusToday() {
  const t0 = todayKey();
  return D.sessions.filter((s) => s.date === t0 && s.kind !== 'break').reduce((a, s) => a + (s.mins || 0), 0);
}
export function openFocus() {
  if (F.mode === 'idle') F = { ...F, ...loadF() };
  openSub('Focus', renderFocus, `<button class="addbtn" data-act="focustarget" aria-label="Daily target">${ic(P.gear, 18, 2)}</button>`);
  startTick();
}
function startTick() { clearInterval(fTick); fTick = setInterval(tickFocus, 500); }
function linkOptions() {
  const o = [['', 'Kisi se nahi']];
  D.tasks.filter((t) => !t.done).slice(0, 30).forEach((t) => o.push(['task:' + t.id, 'Task: ' + t.title]));
  D.subjects.forEach((s) => o.push(['subject:' + s.id, 'Subject: ' + s.name]));
  return o;
}
function renderFocus(body) {
  const left = leftMs(), tot = F.mode === 'idle' ? F.mins * 60000 : F.total || F.mins * 60000, R = 92, C = 2 * Math.PI * R;
  const prog = tot ? 1 - left / tot : 0;
  const today = focusToday(), tgt = focusTarget();
  const hist = [...D.sessions].filter((s) => s.kind !== 'break').sort((a, b) => (b.ts || 0) - (a.ts || 0)).slice(0, 8);
  const week = Array.from({ length: 7 }, (_, i) => { const d = addDaysY(todayKey(), i - 6); return [d, D.sessions.filter((s) => s.date === d && s.kind !== 'break').reduce((a, s) => a + (s.mins || 0), 0)]; });
  const mx = Math.max(30, ...week.map((w) => w[1]));
  body.innerHTML = `<div class="focus">
<div class="chips scrollx">${PRESETS.map(([k, m, l]) => `<button class="chip" data-act="fpreset" data-k="${k}" data-m="${m}" aria-pressed="${F.kind === k || (k === 'custom' && F.custom)}" ${F.mode !== 'idle' ? 'disabled' : ''}>${l}</button>`).join('')}</div>
<div class="ring"><svg viewBox="0 0 200 200" width="240" height="240" aria-hidden="true"><circle cx="100" cy="100" r="${R}" fill="none" stroke="var(--s2)" stroke-width="12"/>
<circle id="f-arc" cx="100" cy="100" r="${R}" fill="none" stroke="var(--ac)" stroke-width="12" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - prog)}" transform="rotate(-90 100 100)"/></svg>
<div class="rt"><b id="f-time" class="mono">${fmtClock(left)}</b><span class="mono lbl">${F.mode === 'run' ? 'chal raha hai' : F.mode === 'pause' ? 'paused' : 'ready'}</span></div></div>
<div class="field"><label class="mono lbl" for="f-link">KISKE LIYE</label><select id="f-link" ${F.mode !== 'idle' ? 'disabled' : ''}>${linkOptions().map(([v, l]) => `<option value="${esc(v)}" ${v === F.link ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
<div class="two">${F.mode === 'idle' ? `<button class="btn" data-act="fstart">${ic(P.play, 20, 2)}Start</button>` :
    `<button class="btn" data-act="fpause">${ic(F.mode === 'run' ? P.pause : P.play, 20, 2)}${F.mode === 'run' ? 'Pause' : 'Resume'}</button><button class="btn soft" data-act="fstop">${ic(P.stop, 18, 2)}Stop</button>`}</div>
<div class="mono lbl">AMBIENT SOUND</div>
<div class="chips">${[['off', 'Off'], ['rain', 'Rain'], ['brown', 'Brown noise'], ['wind', 'Wind']].map(([k, l]) => `<button class="chip" data-act="fsound" data-v="${k}" aria-pressed="${(store.get('nnn_amb', 'off')) === k}">${l}</button>`).join('')}</div>
<div class="card-big"><div class="cal-h"><b>Aaj ka target</b><span class="mono">${fmtMin(today)} / ${fmtMin(tgt)}</span></div>${bar(tgt ? today / tgt * 100 : 0, 10)}</div>
<div class="card-big"><div class="cal-h"><b>Pichle 7 din</b><span class="mono">${fmtMin(week.reduce((a, w) => a + w[1], 0))}</span></div>
<div class="wbars">${week.map(([d, m]) => `<div class="wb"><i style="height:${Math.round(m / mx * 100)}%"></i><span class="mono">${WD[fromYmd(d).getDay()][0]}</span></div>`).join('')}</div></div>
<div class="mono lbl">SESSION HISTORY</div>
${hist.length ? hist.map((s) => `<div class="hist"><b>${fmtMin(s.mins)}</b><span>${esc(s.label || 'Focus')}</span><em class="mono">${fmtD(s.date)}${s.partial ? ' · adhura' : ''}</em></div>`).join('') : emptyBox('Abhi koi session nahi. Pehla 25 minute shuru karo.')}</div>`;
  const sel = $('#f-link'); if (sel) sel.onchange = () => { F.link = sel.value; saveF(); };
}
const fmtClock = (ms) => { const s = Math.ceil(ms / 1000); return `${pad(Math.floor(s / 60))}:${pad(s % 60)}`; };
function tickFocus() {
  if (F.mode === 'run' && Date.now() >= F.end) { finishFocus(true); return; }
  const t = $('#f-time'); if (!t) { if (!focusActive()) clearInterval(fTick); return; }
  const left = leftMs(); t.textContent = fmtClock(left);
  const arc = $('#f-arc'); if (arc) { const C = 2 * Math.PI * 92, tot = F.total || F.mins * 60000; arc.setAttribute('stroke-dashoffset', C * (left / tot)); }
}
function linkLabel() {
  if (!F.link) return '';
  const [ty, id] = F.link.split(':');
  const o = ty === 'task' ? find('tasks', id) : find('subjects', id);
  return o ? (o.title || o.name) : '';
}
function recordSession(mins, partial) {
  const isBreak = F.kind === 'short' || F.kind === 'long';
  if (mins < 1 && partial) return;
  add('sessions', { kind: isBreak ? 'break' : 'focus', mins: Math.round(mins), date: todayKey(), ts: Date.now(), label: linkLabel() || (isBreak ? 'Break' : 'Focus'), link: F.link || '', partial: !!partial });
  if (!isBreak && !partial) awardXP(Math.max(2, Math.round(mins * 0.5)), 'focus');
}
function finishFocus(done) {
  const mins = (F.total || F.mins * 60000) / 60000;
  recordSession(mins, false);
  const wasFocus = F.kind === 'focus' || F.kind === 'deep' || F.kind === 'custom';
  F = { ...F, mode: 'idle' }; saveF(); stopAmbient(); beep();
  toast(done ? (wasFocus ? 'Session poora! Ab thoda break lo' : 'Break khatam, wapas focus!') : 'Session band');
  refreshSub();
}
function beep() {
  try { const c = new (window.AudioContext || window.webkitAudioContext)(); const o = c.createOscillator(), g = c.createGain(); o.frequency.value = 880; g.gain.value = .15; o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + .35); if (navigator.vibrate) navigator.vibrate([200, 100, 200]); } catch { /* ignore */ }
}
function startAmbient(kind) {
  stopAmbient(); if (kind === 'off') return;
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)(), len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; if (kind === 'brown') { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w * 0.5; }
    const src = c.createBufferSource(); src.buffer = buf; src.loop = true;
    const f = c.createBiquadFilter(); f.type = kind === 'rain' ? 'highpass' : 'lowpass'; f.frequency.value = kind === 'rain' ? 900 : kind === 'wind' ? 500 : 800;
    const g = c.createGain(); g.gain.value = kind === 'brown' ? 0.5 : 0.18;
    src.connect(f); f.connect(g); g.connect(c.destination); src.start(); ambient = { c, src };
  } catch { toast('Is device pe ambient sound nahi chala'); }
}
function stopAmbient() { if (ambient) { try { ambient.src.stop(); ambient.c.close(); } catch { /* ignore */ } ambient = null; } }

document.addEventListener('visibilitychange', () => { if (!document.hidden && F.mode === 'run' && Date.now() >= F.end) finishFocus(true); });

/* ================= click handling ================= */
document.addEventListener('click', (e) => {
  const b = e.target.closest && e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act, id = b.dataset.id, v = b.dataset.v;
  switch (a) {
    case 'tview': tView = v; refreshSub(); break;
    case 'taskadd': taskForm(null, b.dataset.kind ? { kind: b.dataset.kind } : tKind !== 'all' ? { kind: tKind } : {}); break;
    case 'taskedit': taskForm(id); break;
    case 'taskdone': completeTask(id); break;
    case 'subtoggle': { const t = find('tasks', id); if (t) upd('tasks', id, { subs: t.subs.map((s) => (s.id === b.dataset.sid ? { ...s, d: !s.d } : s)) }); break; }
    case 'habadd': habitForm(null); break;
    case 'habedit': habitForm(id); break;
    case 'habtoggle': toggleHabit(id); break;
    case 'habcal': habitCalendar(id); break;
    case 'habskip': { const h = find('habits', id); if (h) { upd('habits', id, { skips: [...new Set([...(h.skips || []), todayKey()])] }); toast('Aaj rest day, streak safe'); $('#ov-form') && $('[data-act=fcancel]') && $('[data-act=fcancel]').click(); } break; }
    case 'habemoji': pickEmoji((em) => { formSheet._emoji = em; b.firstChild.textContent = em + ' Emoji chuno'; }); break;
    case 'fpreset': {
      const k = b.dataset.k; let m = Number(b.dataset.m);
      if (k === 'custom') { m = Math.min(240, Math.max(1, Number(prompt('Kitne minute?', '30')) || 0)); if (!m) return; }
      F = { ...F, kind: k, mins: m, custom: k === 'custom' }; saveF(); refreshSub(); break;
    }
    case 'fstart': {
      const tot = F.mins * 60000; F = { ...F, mode: 'run', total: tot, end: Date.now() + tot, link: ($('#f-link') || {}).value || F.link }; saveF();
      startAmbient(store.get('nnn_amb', 'off')); startTick(); refreshSub(); break;
    }
    case 'fpause':
      if (F.mode === 'run') { F = { ...F, mode: 'pause', left: F.end - Date.now() }; stopAmbient(); } else { F = { ...F, mode: 'run', end: Date.now() + F.left }; startAmbient(store.get('nnn_amb', 'off')); }
      saveF(); refreshSub(); break;
    case 'fstop': {
      const elapsed = ((F.total || 0) - leftMs()) / 60000;
      if (!confirm(elapsed >= 1 ? `${Math.round(elapsed)} min ka session save karke band karein?` : 'Timer band karein?')) return;
      if (elapsed >= 1) recordSession(elapsed, true);
      F = { ...F, mode: 'idle' }; saveF(); stopAmbient(); refreshSub(); break;
    }
    case 'fsound': store.set('nnn_amb', v); if (focusRunning()) startAmbient(v); refreshSub(); break;
    case 'focustarget': { const m = Number(prompt('Roz ka focus target (minute)?', String(focusTarget()))); if (m > 0) { saveMe({ focusTarget: Math.min(960, m) }); refreshSub(); } break; }
  }
});
window.addEventListener('nnn-done', (e) => {
  const key = String(e.detail || '');
  if (key.startsWith('task:')) { const t = find('tasks', key.split(':')[1]); if (t && !t.done) completeTask(t.id); }
  else if (key.startsWith('hab:')) { const h = find('habits', key.split(':')[1]); if (h && !habitDoneToday(h)) toggleHabit(h.id); }
});
