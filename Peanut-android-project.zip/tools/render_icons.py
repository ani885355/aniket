# Renders SVG sources to PNG with Chromium (no ImageMagick SVG delegate needed).
# Usage: python3 tools/render_icons.py            (run from project root)
import os, sys, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
ICONS = ROOT / "icons"
ASSETS = ROOT / "assets"

# (svg_source, out_path, width, height, bg_css)
JOBS = [
    (ICONS / "icon-src.svg",      ICONS / "icon-192.png",       192, 192,  None),
    (ICONS / "icon-src.svg",      ICONS / "icon-512.png",       512, 512,  None),
    (ICONS / "icon-src.svg",      ICONS / "icon-1024.png",     1024,1024,  None),
    (ICONS / "maskable-src.svg",  ICONS / "maskable-512.png",   512, 512,  None),
    (ICONS / "maskable-src.svg",  ICONS / "maskable-1024.png", 1024,1024,  None),
    (ICONS / "icon-src.svg",      ICONS / "apple-touch-icon.png", 180, 180, None),
]

SPLASH_JOBS = [
    (ASSETS / "splash-src.svg",       ASSETS / "splash.png",      1920, 1920),
    (ASSETS / "splash-src.svg",       ASSETS / "splash-dark.png", 1920, 1920),
    (ASSETS / "splash-light-src.svg", ASSETS / "splash-light.png",1920, 1920),
]


def render(page, svg_path, out_path, w, h, bg):
    svg = svg_path.read_text(encoding="utf-8")
    html = f"""<!doctype html><html><head><meta charset="utf-8"><style>
      html,body{{margin:0;padding:0;width:{w}px;height:{h}px;overflow:hidden}}
      body{{background:{bg or 'transparent'};display:block}}
      svg{{display:block;width:{w}px;height:{h}px}}
    </style></head><body>{svg}</body></html>"""
    page.set_viewport_size({"width": w, "height": h})
    page.set_content(html)
    page.wait_for_timeout(120)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    page.screenshot(path=str(out_path), omit_background=(bg is None))
    print(f"  {out_path.relative_to(ROOT)}  {w}x{h}  {out_path.stat().st_size//1024}KB")


def main():
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--force-color-profile=srgb", "--disable-lcd-text"])
        page = b.new_page(device_scale_factor=1)
        print("icons:")
        for src, out, w, h, bg in JOBS:
            if src.exists():
                render(page, src, out, w, h, bg)
            else:
                print(f"  skip (missing {src})")
        print("splash:")
        for src, out, w, h in SPLASH_JOBS:
            if src.exists():
                render(page, src, out, w, h, None)
            else:
                print(f"  skip (missing {src})")
        b.close()
    print("done")


if __name__ == "__main__":
    main()
