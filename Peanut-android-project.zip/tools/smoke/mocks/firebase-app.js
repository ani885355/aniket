/* Mock firebase-app */
export function initializeApp(cfg) { return { name: 'mock-app', options: cfg }; }
export function getApps() { return []; }
