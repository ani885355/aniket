/* Mock firebase-auth */
export const mockUser = { uid: 'testuid', email: 'tester@peanut.app', displayName: 'Tester' };
let current = mockUser;
const listeners = new Set();

export function getAuth() { return { currentUser: current }; }
export function onAuthStateChanged(auth, cb) {
  listeners.add(cb);
  const t = setTimeout(() => { try { cb(current); } catch (e) { console.error(e); } }, 40);
  return () => { clearTimeout(t); listeners.delete(cb); };
}
export function createUserWithEmailAndPassword() {
  current = mockUser;
  return Promise.resolve({ user: mockUser });
}
export function signInWithEmailAndPassword() {
  current = mockUser;
  return Promise.resolve({ user: mockUser });
}
export function signOut() {
  current = null;
  listeners.forEach((cb) => { try { cb(null); } catch (e) { console.error(e); } });
  return Promise.resolve();
}
export function updateProfile() { return Promise.resolve(); }
export function sendPasswordResetEmail() { return Promise.resolve(); }
export function setPersistence() { return Promise.resolve(); }
export function onIdTokenChanged() { return () => {}; }
