/* Mock firebase-firestore — in-memory store + seeded data.
   Path shape matches the real SDK: collection(db, 'users', uid, 'tasks') -> ref.path = ['users',uid,'tasks'] */
const store = new Map();
const K = (ref) => ref.path.join('/');

/* ---------------- seed data (dates relative to today) ---------------- */
const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const day = (n) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + n); return d; };
const T = ymd(day(0)), TM = ymd(day(1)), I3 = ymd(day(3)), I9 = ymd(day(9)), Y4 = ymd(day(-4));
const START = day(0).getTime();

const SEED = {
  'users/testuid': {
    name: 'Tester', email: 'tester@peanut.app', mode: 'student', xp: 240,
    avatar: { type: 'memoji', idx: 0 }, roomCode: 'ABC123', remindersOn: true,
    schedule: [
      { id: 's1', time: '07:00', title: 'Subah ki walk', sub: '20 min', on: true },
      { id: 's2', time: '18:00', title: 'Gym ya khel', sub: '', on: true }
    ]
  },
  'rooms/ABC123': { code: 'ABC123', owner: 'testuid', startDate: START, music: { ch: 'bloom' } },
  'rooms/ABC123/members/testuid': { name: 'Tester', avatar: { type: 'memoji', idx: 0 }, points: 140, checkins: [1, 2, 3, 4, 5, 6] },
  'rooms/ABC123/members/other': { name: 'Friendship', avatar: { type: 'memoji', idx: 3 }, points: 90, checkins: [1, 2, 3] },
  'rooms/ABC123/messages/msg1': { uid: 'other', name: 'Friendship', text: 'Day 6 ho gaya bhai!', ts: START },
  'rooms/ABC123/messages/msg2': { uid: 'testuid', name: 'Tester', text: 'Chal raha hai', ts: START + 1000 },
  'users/testuid/tasks/t1': { title: 'Maths homework', kind: 'homework', prio: 'high', due: T, dueTime: '17:00', done: false, subs: [] },
  'users/testuid/tasks/t2': { title: 'Chapter 3 padho', kind: 'study', prio: 'med', due: T, done: false, subs: [] },
  'users/testuid/tasks/t3': { title: 'English notes likho', kind: 'task', prio: 'low', due: '', done: false, subs: [] },
  'users/testuid/tasks/t4': { title: 'Old backlog item', kind: 'backlog', prio: 'med', due: ymd(day(-2)), done: false, subs: [] },
  'users/testuid/tasks/t5': { title: 'Done wala task', kind: 'task', prio: 'low', due: T, done: true, doneDate: T, subs: [] },
  'users/testuid/exams/e1': { subject: 'Maths', name: '', date: I3, start: '10:00', end: '13:00' },
  'users/testuid/exams/e2': { subject: 'Science', name: '', date: I9, start: '09:30', end: '12:00' },
  'users/testuid/subjects/s1': {
    name: 'Maths', color: '#C8F23A', chapters: [
      { id: 'c1', name: 'Algebra', status: 'pending', topics: [{ id: 'x', t: 'Quadratic', d: false }], rev: [false, false, false], weak: true },
      { id: 'c2', name: 'Trigonometry', status: 'ongoing', topics: [{ id: 'x', t: 'Sin/Cos', d: true }], rev: [false, false, false], weak: false },
      { id: 'c3', name: 'Geometry', status: 'completed', topics: [{ id: 'x', t: 'Lines', d: true }], rev: [false, false, false], weak: false }
    ]
  },
  'users/testuid/subjects/s2': {
    name: 'Science', color: '#8FB8DE', chapters: [
      { id: 'c4', name: 'Physics', status: 'pending', topics: [], rev: [false, false, false], weak: false }
    ]
  },
  'users/testuid/habits/h1': { name: 'Paani piyo', part: '', time: '08:00', log: [T], skips: [] },
  'users/testuid/sessions/s1': { kind: 'focus', mins: 45, date: T, ts: START, label: 'Focus' },
  'users/testuid/notes/n1': { title: 'Lecture notes', kind: 'note', body: 'Sirf notes', date: T },
  'users/testuid/events/v1': { title: 'Cricket', cat: 'fun', date: T, time: '17:30', repeat: 'none' },
  'users/testuid/scores/sc1': { subject: 'Maths', name: 'Unit test', marks: 34, total: 40, date: Y4 }
};
for (const [k, v] of Object.entries(SEED)) store.set(k, v);

export const seed = (obj) => { for (const [k, v] of Object.entries(obj)) store.set(k, v); };
export const dump = () => Object.fromEntries(store);
export { SEED };

export function doc(db, ...parts) { return { path: parts.map(String) }; }
export function collection(db, ...parts) { return { path: parts.map(String) }; }
export function query(c, ...conds) { return c; }
export const orderBy = () => () => {};
export const limit = () => () => {};
export const where = () => () => {};

export async function getDoc(ref) {
  const v = store.get(K(ref));
  return { exists: () => v !== undefined, data: () => v, id: ref.path[ref.path.length - 1] };
}
export async function setDoc(ref, data) { store.set(K(ref), JSON.parse(JSON.stringify(data))); notifyAll(); }
export async function updateDoc(ref, data) {
  const cur = store.get(K(ref)) || {};
  store.set(K(ref), { ...cur, ...JSON.parse(JSON.stringify(data)) });
  notifyAll();
}
export async function deleteDoc(ref) { store.delete(K(ref)); notifyAll(); }
export async function addDoc(ref, data) {
  const id = 'id' + Math.random().toString(36).slice(2, 9);
  store.set(K(ref) + '/' + id, JSON.parse(JSON.stringify(data)));
  notifyAll();
  return { id };
}

const watchers = [];
function emit(w) {
  try {
    if (store.has(K(w.ref))) {
      w.next({ exists: () => true, data: () => store.get(K(w.ref)), docs: [], metadata: { hasPendingWrites: false } });
      return;
    }
    const docs = [];
    const pfx = K(w.ref) + '/';
    for (const [k, v] of store) {
      if (k.startsWith(pfx) && !k.slice(pfx.length).includes('/')) docs.push({ id: k.slice(pfx.length), data: () => v });
    }
    w.next({ exists: () => true, data: () => undefined, docs, metadata: { hasPendingWrites: false } });
  } catch (e) { if (w.err) w.err(e); }
}
function notifyAll() { watchers.forEach((w) => setTimeout(() => emit(w), 5)); }

export function onSnapshot(ref, next, err) {
  const w = { ref, next, err };
  watchers.push(w);
  setTimeout(() => emit(w), 15);
  return () => { const i = watchers.indexOf(w); if (i >= 0) watchers.splice(i, 1); };
}
export const serverTimestamp = () => Date.now();
export const increment = (n) => n;
export const arrayUnion = (x) => x;
export const arrayRemove = (x) => x;
export async function runTransaction(db, fn) {
  return fn({ get: async () => ({ data: () => ({}) }), update: () => {}, set: () => {} });
}
export function initializeFirestore() { return { app: 'mock' }; }
export function getFirestore() { return { app: 'mock' }; }
export const persistentLocalCache = () => ({});
export const persistentMultipleTabManager = () => ({});
export function enableNetwork() { return Promise.resolve(); }
export function disableNetwork() { return Promise.resolve(); }
