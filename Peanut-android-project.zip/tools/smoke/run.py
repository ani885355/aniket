#!/usr/bin/env python3
"""Peanut smoke test — headless Chromium + mocked Firebase.
Serves the app, stubs the gstatic firebase modules, walks every tab and
sub-screen, and fails on any console error / unhandled rejection.

Usage: python3 tools/smoke/run.py [--shots DIR]
"""
import argparse, datetime, functools, http.server, json, os, pathlib, socketserver, sys, threading, time

ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
MOCKS = ROOT / "tools" / "smoke" / "mocks"

parser = argparse.ArgumentParser()
parser.add_argument("--shots", default=str(ROOT / "tools" / "smoke" / "shots"))
parser.add_argument("--port", type=int, default=8791)
args = parser.parse_args()
SHOTS = pathlib.Path(args.shots); SHOTS.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- http server
class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(ROOT), **kw)
    def log_message(self, *a): pass
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

socketserver.TCPServer.allow_reuse_address = True
httpd = socketserver.TCPServer(("127.0.0.1", args.port), Handler)
threading.Thread(target=httpd.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{args.port}"

# ---------------------------------------------------------------- seed data
def ymd(d): return d.strftime("%Y-%m-%d")
today = datetime.date.today()
T = ymd(today)
tomorrow = ymd(today + datetime.timedelta(days=1))
in3 = ymd(today + datetime.timedelta(days=3))
in9 = ymd(today + datetime.timedelta(days=9))
start_ms = int(datetime.datetime(today.year, today.month, today.day).timestamp() * 1000)

SEED = {
    "users/testuid": {
        "name": "Tester", "email": "tester@peanut.app", "mode": "student", "xp": 240,
        "avatar": {"type": "memoji", "idx": 0},
        "roomCode": "ABC123",
        "remindersOn": True,
        "schedule": [{"id": "s1", "time": "07:00", "title": "Walk", "sub": "", "on": True},
                     {"id": "s2", "time": "18:00", "title": "Gym", "sub": "", "on": True}],
    },
    "rooms/ABC123": {"code": "ABC123", "owner": "testuid", "startDate": start_ms, "music": {"ch": "bloom"}},
    "rooms/ABC123/members/testuid": {"name": "Tester", "avatar": {"type": "memoji", "idx": 0},
                                     "points": 140, "checkins": [1, 2, 3, 4, 5, 6]},
    "rooms/ABC123/members/other": {"name": "Friendship", "avatar": {"type": "memoji", "idx": 3},
                                   "points": 90, "checkins": [1, 2, 3]},
    "rooms/ABC123/messages/msg1": {"uid": "other", "name": "Friendship", "text": "Day 6 ho gaya bhai!", "ts": start_ms},
    "rooms/ABC123/messages/msg2": {"uid": "testuid", "name": "Tester", "text": "Chal raha hai", "ts": start_ms + 1000},
    "users/testuid/tasks/t1": {"title": "Maths homework", "kind": "homework", "prio": "high", "due": T, "dueTime": "17:00", "done": False, "subs": []},
    "users/testuid/tasks/t2": {"title": "Chapter 3 padho", "kind": "study", "prio": "med", "due": T, "done": False, "subs": []},
    "users/testuid/tasks/t3": {"title": "English notes likho", "kind": "task", "prio": "low", "due": "", "done": False, "subs": []},
    "users/testuid/tasks/t4": {"title": "Old backlog item", "kind": "backlog", "prio": "med", "due": ymd(today - datetime.timedelta(days=2)), "done": False, "subs": []},
    "users/testuid/tasks/t5": {"title": "Done wala task", "kind": "task", "prio": "low", "due": T, "done": True, "doneDate": T, "subs": []},
    "users/testuid/exams/e1": {"subject": "Maths", "name": "", "date": in3, "start": "10:00", "end": "13:00"},
    "users/testuid/exams/e2": {"subject": "Science", "name": "", "date": in9, "start": "09:30", "end": "12:00"},
    "users/testuid/subjects/s1": {"name": "Maths", "color": "#C8F23A", "chapters": [
        {"id": "c1", "name": "Algebra", "status": "pending", "topics": [{"id": "x", "t": "Quadratic", "d": False}], "rev": [False, False, False], "weak": True},
        {"id": "c2", "name": "Trigonometry", "status": "ongoing", "topics": [{"id": "x", "t": "Sin/Cos", "d": True}], "rev": [False, False, False], "weak": False},
        {"id": "c3", "name": "Geometry", "status": "completed", "topics": [{"id": "x", "t": "Lines", "d": True}], "rev": [False, False, False], "weak": False}]},
    "users/testuid/subjects/s2": {"name": "Science", "color": "#8FB8DE", "chapters": [
        {"id": "c4", "name": "Physics", "status": "pending", "topics": [], "rev": [False, False, False], "weak": False}]},
    "users/testuid/habits/h1": {"name": "Paani piyo", "part": "", "time": "08:00", "log": [T], "skips": []},
    "users/testuid/sessions/s1": {"kind": "focus", "mins": 45, "date": T, "ts": start_ms, "label": "Focus"},
    "users/testuid/notes/n1": {"title": "Lecture notes", "kind": "note", "body": "Sirf notes", "date": T},
    "users/testuid/events/v1": {"title": "Cricket", "cat": "fun", "date": T, "time": "17:30", "repeat": "none"},
    "users/testuid/scores/sc1": {"subject": "Maths", "name": "Unit test", "marks": 34, "total": 40, "date": ymd(today - datetime.timedelta(days=4))},
}
SEED_JS = json.dumps(SEED)

# ---------------------------------------------------------------- run
from playwright.sync_api import sync_playwright

errors, warnings = [], []
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("  PASS  " if ok else "  FAIL  ") + name + (("  -> " + detail) if detail and not ok else ""))

def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required"])
        page = browser.new_page(viewport={"width": 412, "height": 915}, device_scale_factor=2)

        def on_console(msg):
            t = msg.text
            if msg.type == "error":
                if "favicon" in t.lower():
                    return
                errors.append(t)
            elif msg.type == "warning" and "Firebase" not in t:
                warnings.append(t)

        page.on("console", on_console)
        page.on("pageerror", lambda e: errors.append("pageerror: " + str(e)))

        # --- stub the firebase CDN modules -------------------------------
        def route(route_obj):
            url = route_obj.request.url
            name = url.split("/")[-1]
            f = MOCKS / name
            if f.exists():
                route_obj.fulfill(status=200, content_type="application/javascript", body=f.read_text())
            else:
                route_obj.fulfill(status=200, content_type="application/javascript", body="export {};")
        page.route("**/firebasejs/**", route)

        # --- the mock firestore already carries the seed data -------------
        page.add_init_script("window.__SMOKE__ = true;")

        page.goto(BASE + "/index.html", wait_until="domcontentloaded")
        page.wait_for_timeout(3500)

        # ---------- auth screen ----------
        check("app title is Peanut", "Peanut" in page.title())
        check("login banner art loaded", page.evaluate(
            "() => { const i=document.querySelector('.authart'); return !!i && i.complete && i.naturalWidth>0; }"))

        # ---------- dashboard ----------
        check("dashboard visible after auth", page.locator("#dash").is_visible())
        page.wait_for_timeout(900)
        check("5 tab buttons", page.locator(".tabs .tab").count() == 5)
        check("room code shown", (page.locator("#top-code").inner_text() or "").strip() != "")

        # Home
        check("home hero image rendered", page.evaluate(
            "() => { const i=document.querySelector('.heroimg'); return !!i && i.complete && i.naturalWidth>0; }"))
        check("home shows today's task", page.locator("#p0").inner_text().find("Maths homework") >= 0)
        page.screenshot(path=str(SHOTS / "tab-home.png"))

        # Tracker
        page.locator('.tab[data-v="1"]').click(); page.wait_for_timeout(700)
        t1 = page.locator("#p1").inner_text()
        check("tracker shows challenge progress", "30" in t1)
        check("tracker shows habits", "Habits" in t1 or "habits" in t1.lower())
        page.screenshot(path=str(SHOTS / "tab-tracker.png"))

        # Study
        page.locator('.tab[data-v="2"]').click(); page.wait_for_timeout(700)
        s1 = page.locator("#p2").inner_text()
        check("study tab lists Maths", "Maths" in s1)
        page.screenshot(path=str(SHOTS / "tab-study.png"))

        # Community
        page.locator('.tab[data-v="3"]').click(); page.wait_for_timeout(900)
        c1 = page.locator("#p3").inner_text()
        check("community leaderboard has members", "Friendship" in c1)
        page.screenshot(path=str(SHOTS / "tab-community.png"))
        # games sub-view
        page.locator('[data-act=cmview][data-v=games]').click(); page.wait_for_timeout(600)
        gh = page.locator("#cm-games").inner_text()
        check("games view renders", len(gh) > 40)
        check("games hub has 9 game cards", page.locator("#cm-games .gcard").count() == 9,
              f"got {page.locator('#cm-games .gcard').count()}")
        check("games hub has hero art", page.evaluate(
            "() => { const i=document.querySelector('.ghero img'); return !!i && i.complete && i.naturalWidth>0; }"))
        check("new games present (RPS/Quiz/2048/Words/Reflex)",
              all(x in gh for x in ["Rock-Paper-Scissors", "Quiz Battle", "2048 Merge", "Word Challenge", "Reflex Test"]))
        page.screenshot(path=str(SHOTS / "games-hub.png"))
        # filter chips
        page.locator('#cm-games [data-act=gfilter][data-v="solo"]').click(); page.wait_for_timeout(500)
        check("solo filter narrows list", page.locator("#cm-games .gcard").count() == 5,
              f"got {page.locator('#cm-games .gcard').count()}")
        page.locator('#cm-games [data-act=gfilter][data-v="all"]').click(); page.wait_for_timeout(400)
        # 2048 opens and responds to a move
        page.locator('#cm-games [data-act=gopen][data-v="merge"]').click(); page.wait_for_timeout(700)
        check("2048 screen opens", page.locator("#sub-body .mgrid").count() == 1)
        before_cells = page.locator("#sub-body .mcell").count()
        page.locator('#sub [data-act=mvu][data-v="left"]').click(); page.wait_for_timeout(400)
        check("2048 board has 16 cells", before_cells == 16)
        check("2048 move re-renders board", page.locator("#sub-body .mgrid").count() == 1)
        page.screenshot(path=str(SHOTS / "game-2048.png"))
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(500)
        # word challenge
        page.locator('#cm-games [data-act=gopen][data-v="words"]').click(); page.wait_for_timeout(700)
        check("word challenge opens", page.locator("#sub-body .wdscram").count() == 1)
        page.screenshot(path=str(SHOTS / "game-words.png"))
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(500)
        # reflex
        page.locator('#cm-games [data-act=gopen][data-v="reflex"]').click(); page.wait_for_timeout(700)
        check("reflex test opens", page.locator("#sub-body .reflex").count() == 1)
        page.screenshot(path=str(SHOTS / "game-reflex.png"))
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(500)
        # wall sub-view
        page.locator('[data-act=cmview][data-v=wall]').click(); page.wait_for_timeout(700)
        check("wall shows message", "Day 6 ho gaya" in page.locator("#msgs").inner_text())
        # room sub-view
        page.locator('[data-act=cmview][data-v=room]').click(); page.wait_for_timeout(500)
        check("room tab renders", len(page.locator("#cm-room").inner_text()) > 40)

        # More
        page.locator('.tab[data-v="4"]').click(); page.wait_for_timeout(700)
        m1 = page.locator("#p4").inner_text()
        check("more tab has music entry", "Music" in m1)

        # ---------- PLANNER ----------
        page.locator('.tab[data-v="2"]').click(); page.wait_for_timeout(500)
        page.locator('#p2 [data-act=studyopen][data-v=planner]').click()
        page.wait_for_timeout(900)
        pl = page.locator("#sub-body").inner_text()
        check("planner opens", page.locator("#sub").is_visible())
        check("planner shows ALL task kinds (homework)", "Maths homework" in pl)
        check("planner shows default 'task' kind too", "English notes" in pl or "Backlog" in pl)
        check("planner has backlog view", "Backlog" in pl)
        page.screenshot(path=str(SHOTS / "planner.png"), full_page=False)

        # backlog tab
        page.locator('#sub [data-act=plview][data-v=backlog]').click(); page.wait_for_timeout(600)
        bl = page.locator("#sub-body").inner_text()
        check("planner backlog lists overdue", "Old backlog item" in bl)
        check("planner backlog has quick 'aaj' action", "aaj" in bl.lower())
        # schedule a backlog item for today
        page.locator('#sub [data-act=plandue][data-v="%s"]' % T).first.click(); page.wait_for_timeout(900)
        page.locator('#sub [data-act=plview][data-v="today"]').click(); page.wait_for_timeout(700)
        check("backlog item moved into today's plan",
              "Old backlog item" in page.locator("#sub-body").inner_text())

        # smart plan
        page.locator('#sub [data-act=smartplan]').click(); page.wait_for_timeout(900)
        sp = page.locator("#sub-body").inner_text()
        check("smart plan produces suggestions", ("Study:" in sp) or ("Revise" in sp) or ("session" in sp.lower()))
        distinct_days = page.evaluate(
            "() => new Set([...document.querySelectorAll('#sub-body .chrow .tmeta')]"
            ".map(e => e.textContent.trim().split('\\u00b7')[0].trim())).size")
        check("smart plan spreads across >=2 days", distinct_days >= 2, f"got {distinct_days}")
        page.screenshot(path=str(SHOTS / "smartplan.png"))

        # ---------- DAY TIMELINE ----------
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(500)
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(500)
        page.locator('.tab[data-v="4"]').click(); page.wait_for_timeout(600)
        page.locator('#p4 [data-act=moreopen][data-v=planner]').click(); page.wait_for_timeout(900)
        check("day timeline opens", page.locator("#sub").is_visible())
        check("day timeline has entries", len(page.locator("#sub-body").inner_text()) > 60)
        page.screenshot(path=str(SHOTS / "timeline.png"))

        # ---------- MUSIC ----------
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(500)
        page.locator('.tab[data-v="4"]').click(); page.wait_for_timeout(600)
        page.locator('#p4 [data-act=moreopen][data-v=music]').first.click(); page.wait_for_timeout(900)
        mu = page.locator("#sub-body").inner_text()
        check("music screen opens", page.locator("#sub").is_visible())
        check("music lists channels", mu.count("BPM") >= 4)
        check("music shows community channel", "COMMUNITY CHANNEL" in mu or "COMMUNITY" in mu)
        check("music credits mention Bloomee", "Bloomee" in mu)
        check("local music section present", "LOCAL MUSIC" in mu)
        check("local music add button present", page.locator('#sub [data-act=lmadd]').count() == 1)
        page.screenshot(path=str(SHOTS / "music.png"))
        # scroll to the OpenTune card for a dedicated shot
        page.evaluate("() => { const el=document.querySelector('#sub-body .otcard'); if(el) el.scrollIntoView({block:'start'}); }")
        page.wait_for_timeout(500)
        page.screenshot(path=str(SHOTS / "music-opentune.png"))
        page.evaluate("() => { const el=document.querySelector('#sub-body .chgrid'); if(el) el.scrollIntoView({block:'start'}); }")
        page.wait_for_timeout(500)
        page.screenshot(path=str(SHOTS / "music-channels.png"))
        page.evaluate("() => { const g=document.querySelector('#sub-body #chg-en'); if(g){ g.scrollIntoView({block:'center'}); } }")
        page.wait_for_timeout(500)
        page.screenshot(path=str(SHOTS / "music-english.png"))
        page.evaluate("() => { const el=document.querySelector('#sub-body'); if(el) el.scrollTop=0; }")
        page.wait_for_timeout(400)

        # play + now-playing strip
        page.locator('#sub [data-act=musicplay]').click(); page.wait_for_timeout(900)
        check("now-playing strip visible while playing", page.locator("#np").is_visible())
        check("audio context running", page.evaluate(
            "() => { const a = window.__pnAudio; return a && a.ctx ? a.ctx.state === 'running' : false; }"))
        # switch channel from the grid
        page.locator('#sub [data-act=musicch][data-v="desi"]').click(); page.wait_for_timeout(700)
        check("channel switch updates now-playing", "Desi" in page.locator("#music-ch").inner_text())
        # room owner can set the community channel
        page.locator('#sub [data-act=musicroomch][data-v="night"]').click(); page.wait_for_timeout(700)
        check("community channel change reflected", "Midnight" in page.locator("#sub-body").inner_text())
        check("OpenTune section present", "OPENTUNE" in mu)
        check("OpenTune search input present", page.locator('#sub #ot-q').count() == 1)
        check("OpenTune search button present", page.locator('#sub [data-act=otsearch]').count() == 1)
        check("OpenTune features (silence skip / normalize / tempo)",
              page.locator('#sub [data-act=otskip]').count() == 1 and
              page.locator('#sub [data-act=otnorm]').count() == 1 and
              page.locator('#sub [data-act=ottempo]').count() == 1)
        check("OpenTune library view tab", page.locator('#sub [data-act=otview][data-v="library"]').count() == 1)
        check("no Spotify left in app", "Spotify" not in page.evaluate("() => document.body.innerText"))
        # two independent channel sets
        hi_grp = page.locator('#sub .chgrid').first
        check("Hinglish channel group has 8", hi_grp.locator('.chcard').count() == 8,
              f"got {hi_grp.locator('.chcard').count()}")
        en_grp = page.locator('#sub .chgrid').nth(1)
        check("English channel group has 8", en_grp.locator('.chcard').count() == 8,
              f"got {en_grp.locator('.chcard').count()}")
        labels = page.locator('#sub .chgrid').all_inner_texts()
        check("Hinglish + English groups both present",
              "hinglish channels" in mu.lower() and "english channels" in mu.lower())
        # english channel selectable & independent
        page.locator('#sub [data-act=musicch][data-v="night-en"]').click(); page.wait_for_timeout(600)
        check("English channel selectable", "Neon Nights" in page.locator("#sub-body").inner_text())
        page.locator('#sub [data-act=musicch][data-v="bloom"]').click(); page.wait_for_timeout(600)
        check("Hinglish channel independently selectable", "phoolte" in page.locator("#sub-body").inner_text())


        # ---------- AVATAR CREATOR ----------
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(400)
        page.locator('.tab[data-v="4"]').click(); page.wait_for_timeout(500)
        page.locator('#p4 [data-act=moreopen][data-v=avatar]').click(); page.wait_for_timeout(900)
        check("avatar creator opens", page.locator("#avc-prev").count() == 1)
        # face shape chips
        shapes = page.locator('#sub-body [data-act=avset][data-k=face]')
        check("face shape options >= 5", shapes.count() >= 5, f"got {shapes.count()}")
        # switch to square and confirm geometry changes
        before = page.locator("#avc-prev").inner_html()
        page.locator('#sub-body [data-act=avset][data-k=face][data-v="square"]').click(); page.wait_for_timeout(500)
        after = page.locator("#avc-prev").inner_html()
        check("changing face shape redraws avatar", before != after)
        page.screenshot(path=str(SHOTS / "avatar.png"))
        # width slider present
        page.locator('#sub-body [data-act=avtab][data-v=face]').click(); page.wait_for_timeout(400)
        check("face width slider present", page.locator('#sub-body .rng[data-k=fw]').count() == 1)
        check("face length slider present", page.locator('#sub-body .rng[data-k=fh]').count() == 1)

        # ---------- THEMES ----------
        page.locator('[data-act=subback]').click(); page.wait_for_timeout(400)
        page.locator('#dash [data-act=profile]').first.click(); page.wait_for_timeout(700)
        check("profile sheet opens", page.locator("#profile-sheet").is_visible())
        check("8 themes offered", page.locator('#profile-sheet .thopt').count() == 8,
              f"got {page.locator('#profile-sheet .thopt').count()}")
        page.locator('#profile-sheet [data-act=theme][data-v=ocean]').click(); page.wait_for_timeout(500)
        check("ocean theme applied", page.evaluate("() => document.documentElement.dataset.theme") == "ocean")
        page.screenshot(path=str(SHOTS / "themes.png"))

        # ---------- LOGIN SCREEN (last: mock auto-auth) ----------
        page.keyboard.press("Escape"); page.wait_for_timeout(600)
        page.locator('#dash [data-act=profile]').first.click(); page.wait_for_timeout(700)
        page.locator('#profile-sheet [data-act=logout]').first.click(); page.wait_for_timeout(1400)
        check("auth screen visible after logout", page.locator("#auth").is_visible())
        check("auth has segmented login/signup", page.locator("#auth-form .seg button").count() == 2)
        check("auth art visible", page.evaluate(
            "() => { const i=document.querySelector('.authart'); if(!i) return false;"
            " const r=i.getBoundingClientRect(); return r.width>100 && r.height>50; }"))
        # language picker on the login page
        check("language button on login page", page.locator("#auth [data-act=langopen]").count() == 1)
        page.locator('#auth [data-act=langopen]').click(); page.wait_for_timeout(600)
        check("language sheet opens", page.locator("#ov-lang").is_visible())
        check("language sheet lists 10 languages", page.locator("#lang-list .langopt").count() == 10,
              f"got {page.locator('#lang-list .langopt').count()}")
        page.screenshot(path=str(SHOTS / "languages.png"))
        # switch to Hindi and verify the UI actually changes
        page.locator('#lang-list [data-act=setlang2][data-v="hi"]').click(); page.wait_for_timeout(900)
        check("language switched to Hindi", page.evaluate(
            "() => document.documentElement.lang") == "hi")
        check("UI text switched to Hindi", page.locator("#auth-form .seg button").first.inner_text() == "लॉगिन",
              page.locator("#auth-form .seg button").first.inner_text())
        page.screenshot(path=str(SHOTS / "login-hi.png"))
        # back to English
        page.locator('#auth [data-act=langopen]').click(); page.wait_for_timeout(500)
        page.locator('#lang-list [data-act=setlang2][data-v="en"]').click(); page.wait_for_timeout(700)
        check("language back to English", page.evaluate(
            "() => document.documentElement.lang") == "en")

        browser.close()

    # ---------- report ----------
    print("\n--- console errors ---")
    real = [e for e in errors if 'favicon' not in e.lower() and '404' not in e]
    for e in real[:25]:
        print("  ", e[:300])
    print(f"total console errors: {len(real)}")
    failed = [r for r in results if not r[1]]
    print(f"\n{len(results)-len(failed)}/{len(results)} checks passed")
    if failed:
        print("FAILED:")
        for n, _, d in failed:
            print("  -", n, d)
    if real:
        print("\nRESULT: FAIL (console errors)")
        sys.exit(1)
    if failed:
        print("\nRESULT: FAIL")
        sys.exit(1)
    print("\nRESULT: PASS")

if __name__ == "__main__":
    main()
