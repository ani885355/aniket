#!/usr/bin/env python3
"""Peanut promo — composes the final video from frames + voiceover + music bed."""
import json, pathlib, subprocess, shutil, math

VD = pathlib.Path(__file__).resolve().parent
FR = VD / "frames"; VO = VD / "vo"; OUT = VD / "out"
OUT.mkdir(exist_ok=True)
SCENES = json.loads((VD / "scenes.json").read_text(encoding="utf-8"))
FPS = 30
XF = 0.45          # crossfade seconds
LEAD = 0.35        # silence before VO starts
TAIL = 1.45        # silence after VO ends


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("FFMPEG FAIL:", " ".join(cmd[:8]))
        print(r.stderr[-2500:])
        raise SystemExit(1)


def dur(p):
    return float(subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
        capture_output=True, text=True).stdout.strip())


frames = sorted(FR.glob("*.png"))
assert len(frames) == len(SCENES), (len(frames), len(SCENES))

# ---------- 1. voiceover track ----------
vo_files = [VO / f"vo_{s['id']}.mp3" for s in SCENES]
vo_durs = [dur(f) for f in vo_files]
clip_durs = [d + LEAD + TAIL for d in vo_durs]

args = ["ffmpeg", "-y", "-v", "error"]
for f in vo_files:
    args += ["-i", str(f)]
parts = []
for i, d in enumerate(clip_durs):
    parts.append(f"[{i}:a]adelay={int(LEAD*1000)}:all=1,apad=whole_dur={d:.3f}[a{i}]")
concat = "".join(f"[a{i}]" for i in range(len(vo_files)))
fc = ";".join(parts) + f";{concat}concat=n={len(vo_files)}:v=0:a=1[vo]"
args += ["-filter_complex", fc, "-map", "[vo]", "-ac", "2", "-ar", "44100", str(OUT / "vo.wav")]
run(args)
print("vo.wav", round(dur(OUT / "vo.wav"), 2), "s")

# ---------- 2. music bed ----------
music = VD / "music.wav"
total = dur(OUT / "vo.wav")
if not music.exists() or dur(music) < total - 1:
    T = int(total) + 4
    run(["ffmpeg", "-y", "-v", "error",
         "-f", "lavfi", "-i", f"sine=frequency=146.83:duration={T}",
         "-f", "lavfi", "-i", f"sine=frequency=220.00:duration={T}",
         "-f", "lavfi", "-i", f"sine=frequency=293.66:duration={T}",
         "-f", "lavfi", "-i", f"sine=frequency=73.42:duration={T}",
         "-f", "lavfi", "-i", f"sine=frequency=55.00:duration={T}",
         "-filter_complex",
         "[0]tremolo=f=0.17:d=0.55,volume=0.30[a0];[1]tremolo=f=0.23:d=0.45,volume=0.20[a1];"
         "[2]tremolo=f=0.13:d=0.65,volume=0.13[a2];[3]tremolo=f=0.31:d=0.40,volume=0.34[a3];"
         "[4]tremolo=f=2.0:d=0.95,volume=0.30[a4];"
         "[a0][a1][a2][a3][a4]amix=inputs=5:normalize=0,lowpass=f=1100,"
         f"aecho=0.8:0.85:260|520:0.20|0.10,afade=t=in:st=0:d=4,afade=t=out:st={T-5}:d=5",
         "-ac", "2", "-ar", "44100", str(music)])

# ---------- 3. animated clips ----------
clips = []
for i, (f, d) in enumerate(zip(frames, clip_durs)):
    out = OUT / f"clip{i+1:02d}.mp4"
    nf = int(round(d * FPS))
    vf = (f"scale=1242:2208:force_original_aspect_ratio=increase,crop=1242:2208,"
          f"zoompan=z='min(1+0.00032*on,1.075)':d=1:"
          f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)-on*0.10':"
          f"s=1080x1920:fps={FPS}")
    run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-i", str(f), "-t", f"{d:.3f}",
         "-vf", vf, "-frames:v", str(nf), "-r", str(FPS), "-c:v", "libx264",
         "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p", str(out)])
    clips.append(out)
    print("clip", i + 1, round(d, 2), "s")

# ---------- 4. crossfade chain ----------
args = ["ffmpeg", "-y", "-v", "error"]
for c in clips:
    args += ["-i", str(c)]
chain, cur = [], "[0:v]"
acc = clip_durs[0]
for i in range(1, len(clips)):
    off = acc - XF
    lbl = f"[v{i}]"
    chain.append(f"{cur}[{i}:v]xfade=transition=fade:duration={XF}:offset={off:.3f}{lbl}")
    cur = lbl
    acc += clip_durs[i] - XF
fin = dur(OUT / "vo.wav")
chain.append(f"{cur}fade=t=out:st={fin-1.6}:d=1.6[vout]")
args += ["-filter_complex", ";".join(chain), "-map", "[vout]",
         "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p", "-r", str(FPS),
         str(OUT / "video_only.mp4")]
run(args)
print("video_only", round(dur(OUT / "video_only.mp4"), 2), "s")

# ---------- 5. mix voice + music ----------
run(["ffmpeg", "-y", "-v", "error", "-i", str(OUT / "video_only.mp4"), "-i", str(OUT / "vo.wav"),
     "-i", str(music),
     "-filter_complex",
     "[1:a]volume=1.25,alimiter=limit=0.95[vo];"
     "[2:a]volume=0.13,aloop=loop=-1:size=2147483647[m];"
     "[vo][m]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,"
     f"afade=t=out:st={fin-1.6}:d=1.6[aout]",
     "-map", "0:v", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
     "-movflags", "+faststart", str(OUT / "Peanut_promo_9x16.mp4")])
print("vertical done:", round(dur(OUT / "Peanut_promo_9x16.mp4"), 2), "s")

# ---------- 6. landscape 16:9 (blurred fill) ----------
run(["ffmpeg", "-y", "-v", "error", "-i", str(OUT / "Peanut_promo_9x16.mp4"),
     "-filter_complex",
     "[0:v]split=2[bgs][fgs];"
     "[bgs]scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080,"
     "gblur=sigma=42,eq=brightness=-0.10:saturation=0.7[bgb];"
     "[fgs]scale=1080:1920[fg];"
     "[bgb][fg]overlay=(W-w)/2:(H-h)/2[v]",
     "-map", "[v]", "-map", "0:a", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
     "-pix_fmt", "yuv420p", "-r", str(FPS), "-c:a", "copy", "-movflags", "+faststart",
     str(OUT / "Peanut_promo_16x9.mp4")])
print("landscape done:", round(dur(OUT / "Peanut_promo_16x9.mp4"), 2), "s")
