#!/usr/bin/env python3
"""Peanut promo — renders each scene as a 1080x1920 mockup frame (Chromium)."""
import json, pathlib, base64, sys

ROOT = pathlib.Path("/workspace/work")
VDIR = ROOT / "tools" / "video"
FRAMES = VDIR / "frames"
FRAMES.mkdir(parents=True, exist_ok=True)
SHOTS = ROOT / "tools" / "smoke" / "shots"
LOGO = (ROOT / "icons" / "logo.svg").read_text(encoding="utf-8")

SCENES = json.loads((VDIR / "scenes.json").read_text(encoding="utf-8"))

def data_uri(p):
    if not p:
        return ""
    b = pathlib.Path(p).read_bytes()
    return "data:image/png;base64," + base64.b64encode(b).decode()

CSS = """
@font-face{font-family:'Bricolage';src:local('Bricolage Grotesque');}
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:1080px;height:1920px;overflow:hidden;background:#0A0C08}
body{font-family:'Bricolage Grotesque','Noto Sans Devanagari','Noto Sans Bengali','Noto Sans Tamil','Noto Sans Telugu','Noto Sans Kannada','Noto Sans Malayalam','Noto Sans Gujarati','Noto Sans Gurmukhi',system-ui,sans-serif;
  color:#F4F3EA;-webkit-font-smoothing:antialiased;position:relative}
.bg{position:absolute;inset:0;background:
  radial-gradient(900px 900px at 78% 26%, rgba(200,242,58,.16), transparent 62%),
  radial-gradient(700px 700px at 12% 82%, rgba(232,185,111,.13), transparent 60%),
  linear-gradient(168deg,#12150D 0%,#0A0C08 52%,#070806 100%)}
.grain{position:absolute;inset:0;opacity:.16;
  background-image:radial-gradient(rgba(255,255,255,.14) .8px, transparent .8px);background-size:4px 4px}
.vig{position:absolute;inset:0;background:radial-gradient(120% 80% at 50% 45%, transparent 42%, rgba(0,0,0,.55) 100%)}
.wrap{position:absolute;inset:0;padding:60px 72px;display:flex;flex-direction:column}

/* top bar */
.topbar{display:flex;align-items:center;justify-content:space-between;height:56px;flex:none}
.brand{display:flex;align-items:center;gap:13px}
.brand .mk{width:44px;height:44px;border-radius:13px;overflow:hidden;background:#15180F;border:1px solid #2A2F22;display:grid;place-items:center}
.brand .mk svg{width:36px;height:42px}
.brand b{font-size:25px;font-weight:800;letter-spacing:-.03em}
.brand s{text-decoration:none;font-family:'DM Mono',monospace;font-size:13px;letter-spacing:.16em;color:#8F9B5A;margin-left:4px}
.counter{font-family:'DM Mono',monospace;font-size:15px;color:#6E7560;letter-spacing:.1em}

/* text block */
.txt{margin-top:56px;flex:none}
.kick{display:inline-block;font-family:'DM Mono',monospace;font-size:21px;font-weight:600;letter-spacing:.22em;
  color:#C8F23A;padding:9px 16px;border-radius:11px;background:rgba(200,242,58,.10);border:1px solid rgba(200,242,58,.26)}
h1{font-size:60px;font-weight:800;line-height:1.1;letter-spacing:-.035em;margin-top:26px;max-width:960px}
h1 em{font-style:normal;color:#C8F23A}
p.sub{font-size:27px;line-height:1.42;color:#9EA192;margin-top:20px;max-width:900px}
.chips{display:flex;flex-wrap:wrap;gap:10px;margin-top:26px}
.chip{padding:11px 18px;border-radius:13px;font-size:20px;font-weight:600;color:#D5D8C8;background:rgba(30,34,22,.78);
  border:1px solid #2A2F22;backdrop-filter:blur(6px)}
.chip.lime{color:#0E1206;background:#C8F23A;border-color:#C8F23A}

/* phone */
.stage{flex:1;position:relative;display:flex;align-items:flex-end;justify-content:center;margin-top:22px}
.phone{position:relative;border-radius:62px;padding:15px;background:linear-gradient(150deg,#39412C,#12150D 55%);
  box-shadow:0 46px 90px rgba(0,0,0,.62), 0 0 0 1.5px rgba(255,255,255,.09) inset}
.screen{position:relative;border-radius:48px;overflow:hidden;background:#000;box-shadow:0 0 0 2px rgba(0,0,0,.9) inset}
.screen img{display:block;width:100%;height:100%;object-fit:cover}
.notch{position:absolute;top:26px;left:50%;transform:translateX(-50%);width:150px;height:30px;border-radius:16px;
  background:#05060A;z-index:3;box-shadow:0 0 0 1px rgba(255,255,255,.05)}
.side{position:absolute;right:-3px;top:230px;width:4px;height:96px;border-radius:3px;background:#39412C}
.side.l{right:auto;left:-3px;top:270px;height:64px}
.glow{position:absolute;inset:-14% -10%;z-index:-1;border-radius:70px;
  background:radial-gradient(closest-side,rgba(200,242,58,.20),transparent 72%);filter:blur(26px)}

/* hero / close */
.hero{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:0}
.hero .mk{width:430px;height:516px;filter:drop-shadow(0 30px 60px rgba(0,0,0,.6))}
.hero h1{font-size:92px;margin-top:8px;text-align:center;max-width:none}
.hero p.sub{font-size:30px;text-align:center;margin-top:20px;max-width:none}
.hero .chips{justify-content:center;margin-top:36px}
.cta{margin-top:40px;display:flex;gap:14px;flex-wrap:wrap;justify-content:center}
.cta span{padding:18px 34px;border-radius:17px;font-size:24px;font-weight:800;letter-spacing:-.01em}
.cta .a{background:#C8F23A;color:#0E1206}
.cta .b{border:1.5px solid #39412C;color:#D5D8C8;background:rgba(30,34,22,.6)}
.hero .mk2{width:190px;height:228px;margin-bottom:30px}
"""

def frame_html(sc, idx, total):
    shot = data_uri(sc.get("shot"))
    prog = (idx + 1) / total
    dots = "".join(f'<i class="{"on" if i<=idx else ""}"></i>' for i in range(total))
    topbar = f"""<div class="topbar">
  <div class="brand"><span class="mk">{LOGO}</span><b>Peanut</b><s>PEANUT</s></div>
  <div class="counter">{idx+1:02d} / {total:02d}</div>
</div>"""

    if sc["kind"] == "hero":
        chips = "".join(f'<span class="chip">{c}</span>' for c in sc.get("chips", []))
        body = f"""<div class="hero">
  <div class="mk">{LOGO}</div>
  <h1>{sc['title'].replace(chr(10),'<br>')}</h1>
  <p class="sub">{sc['sub']}</p>
  <div class="chips">{chips}</div>
  <div class="cta"><span class="a">▶ App Store / Play Store</span><span class="b">🌐 Web app</span></div>
</div>"""
    elif sc["kind"] == "close":
        chips = "".join(f'<span class="chip">{c}</span>' for c in sc.get("chips", []))
        body = f"""<div class="hero">
  <div class="mk2">{LOGO}</div>
  <h1>{sc['title'].replace(chr(10),'<br>')}</h1>
  <p class="sub">{sc['sub']}</p>
  <div class="chips">{chips}</div>
  <div class="cta"><span class="a">⬇ Peanut download karo</span></div>
</div>"""
    else:
        chips = "".join(f'<span class="chip">{c}</span>' for c in sc.get("bullets", [])[:3])
        body = f"""<div class="txt">
  <span class="kick">{sc['kicker']}</span>
  <h1>{sc['title']}</h1>
  <p class="sub">{sc['sub']}</p>
  <div class="chips">{chips}</div>
</div>
<div class="stage">
  <div class="glow"></div>
  <div class="phone"><span class="side"></span><span class="side l"></span>
    <div class="screen" style="width:560px;height:1244px"><img src="{shot}" alt=""></div>
  </div>
</div>"""
    progbar = f"""<div style="position:absolute;left:0;bottom:0;height:7px;width:100%;background:#1A1E13">
<div style="height:100%;width:{prog*100:.1f}%;background:linear-gradient(90deg,#C8F23A,#8CC63F)"></div></div>
<div style="position:absolute;left:0;bottom:22px;width:100%;display:flex;justify-content:center;gap:9px">{dots}</div>"""
    dots_css = "<style>.dots i,.wrap>div:last-of-type i{}</style>"
    return f"""<!doctype html><html><head><meta charset="utf-8">
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;600;800&family=DM+Mono:wght@400;500&family=Noto+Sans+Devanagari:wght@400;600;800&family=Noto+Sans+Bengali:wght@400;600&family=Noto+Sans+Tamil:wght@400;600&family=Noto+Sans+Telugu:wght@400;600&family=Noto+Sans+Kannada:wght@400;600&family=Noto+Sans+Malayalam:wght@400;600&family=Noto+Sans+Gujarati:wght@400;600&family=Noto+Sans+Gurmukhi:wght@400;600&display=swap" rel="stylesheet">
<style>{CSS}
.dots i{{width:9px;height:9px;border-radius:50%;background:#2A2F22;display:block}}
.dots i.on{{background:#C8F23A}}
</style></head><body>
<div class="bg"></div><div class="grain"></div>
<div class="wrap">{topbar}{body}</div>
<div class="vig"></div>
<div style="position:absolute;left:0;bottom:0;height:7px;width:100%;background:#1A1E13"><div style="height:100%;width:{prog*100:.1f}%;background:linear-gradient(90deg,#C8F23A,#8CC63F)"></div></div>
<div class="dots" style="position:absolute;left:0;bottom:24px;width:100%;display:flex;justify-content:center;gap:9px">{dots}</div>
</body></html>"""


def main():
    from playwright.sync_api import sync_playwright
    total = len(SCENES)
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1080, "height": 1920}, device_scale_factor=1)
        for i, sc in enumerate(SCENES):
            html = frame_html(sc, i, total)
            f = VDIR / f"_{i}.html"
            f.write_text(html, encoding="utf-8")
            pg.goto(f.as_uri())
            pg.wait_for_timeout(1400)
            try:
                pg.wait_for_function("() => document.fonts.status === 'loaded'", timeout=8000)
            except Exception:
                pass
            pg.wait_for_timeout(350)
            out = FRAMES / f"{i+1:02d}_{sc['id']}.png"
            pg.screenshot(path=str(out))
            print("frame", out.name, out.stat().st_size // 1024, "KB")
            f.unlink(missing_ok=True)
        b.close()

if __name__ == "__main__":
    main()
