#!/usr/bin/env python3
"""Peanut promo video — scene definitions (Hinglish VO + on-screen captions)."""
import json, pathlib

OUT = pathlib.Path(__file__).resolve().parent
SHOTS = pathlib.Path("/workspace/work/tools/smoke/shots")

def shot(name):
    return str(SHOTS / name) if name else None

# kind: hero | phone | close
SCENES = [
  dict(
    id="s1", kind="hero", shot=None,
    kicker="PEANUT", title="30 din ka challenge.", sub="Tera room. Tere plan. Tera music.",
    chips=["Tasks", "Habits", "Planner", "Games", "Music"],
    vo="ये है Peanut — तेरा 30 दिन का challenge app। Tasks, habits, planner, games और music, सब कुछ एक जगह।",
    dur=11.5,
  ),
  dict(
    id="s2", kind="phone", shot=shot("languages.png"),
    kicker="10 भाषाएँ",
    title="भाषा बदलो, जहाँ से चाहो",
    sub="Login page पर ही globe button — पूरा app अपनी भाषा में।",
    bullets=["हिन्दी · বাংলা · தமிழ்", "తెలుగు · ಕನ್ನಡ · മലയാളം", "ગુજરાતી · ਪੰਜਾਬੀ · मराठी"],
    vo="और भाषा? Login page पर ही globe button दबाओ — हिन्दी, बंगला, तमिल, तेलुगु, कन्नड़, मलयालम, गुजराती, पंजाबी, मराठी — दस भाषाएँ, पूरा app अपनी भाषा में।",
    dur=16.0,
  ),
  dict(
    id="s3", kind="phone", shot=shot("tab-tracker.png"),
    kicker="ROOM CHALLENGE",
    title="30 दिन. एक ही room.",
    sub="Code bhejo, dost ko bulao, leaderboard jeeto.",
    bullets=["Daily check-in + streak", "Live leaderboard", "Chat, reactions & games"],
    vo="Room बनाओ या code से join करो। तीस चेक-इन स्ट्रीक, लीडरबोर्ड, और दोस्तों के साथ competition।",
    dur=13.0,
  ),
  dict(
    id="s4", kind="phone", shot=shot("planner.png"),
    kicker="STUDY PLANNER",
    title="Planner अब सच में काम करता है",
    sub="Har task dikhta hai, backlog hai, smart plan din-din sessions baant deta hai.",
    bullets=["Aaj · Kal · Week · Backlog", "Exam-aware smart plan", "Approve karo, bas ho gaya"],
    vo="Planner अब सच में काम करता है। हर task दिखता है, backlog है, और smart plan तुम्हारे exam के हिसाब से दिन-दिन sessions बाँट देता है — approve करो, बस।",
    dur=16.5,
  ),
  dict(
    id="s5", kind="phone", shot=shot("games-hub.png"),
    kicker="9 GAMES",
    title="चार नहीं, नौ games",
    sub="Dost ke saath real-time ya akele — filter karo aur khelo.",
    bullets=["Tic-Tac-Toe · Math Battle · RPS", "Quiz Battle · Memory · Daily Brain", "2048 · Word Challenge · Reflex"],
    vo="Games? अब सिर्फ चार नहीं, नौ। Tic-Tac-Toe, Math Battle, Rock-Paper-Scissors, Quiz Battle, Memory, Daily Brain, 2048, Word Challenge और Reflex Test — दोस्तों के साथ real-time या अकेले।",
    dur=19.0,
  ),
  dict(
    id="s6", kind="phone", shot=shot("music.png"),
    kicker="MUSIC",
    title="हर community का अपना channel",
    sub="Room code hi decide karta hai kaunsa channel baje.",
    bullets=["16 channels — Hinglish + English", "OpenTune se YouTube Music", "Apne device ke gaane"],
    vo="और music — हर community का अपना channel। Room code ही decide करता है कि कौन सा channel बजे। Hinglish aur English ke sixteen channels, OpenTune se YouTube Music, aur apne device ke gaane।",
    dur=17.0,
  ),
  dict(
    id="s7", kind="phone", shot=shot("avatar.png"),
    kicker="AVATAR",
    title="Memoji ab fully adjustable",
    sub="Saat chehre ke shapes, width aur length ke sliders.",
    bullets=["Round · Oval · Square · Heart", "Diamond · Long · Triangle", "8 ready-made presets"],
    vo="Avatar भी अब adjustable — सात चेहरे के shapes, चौड़ाई और लंबाई के sliders, आठ ready-made memoji।",
    dur=13.0,
  ),
  dict(
    id="s8", kind="phone", shot=shot("themes.png"),
    kicker="THEMES",
    title="8 themes, तेरा मन जैसा",
    sub="Garden se Ocean tak — aur sab kuch open source.",
    bullets=["Garden · Cream · Vapor · Bubble", "Ocean · Sunset · Forest · Ink", "Koi ads nahi, koi subscription nahi"],
    vo="आठ themes, तेरा मन जैसा। और सब कुछ open source — कोई ads नहीं, कोई subscription नहीं।",
    dur=13.5,
  ),
  dict(
    id="s9", kind="close", shot=None,
    kicker="PEANUT", title="अपना room बनाओ.\n30 दिन शुरू करो.",
    sub="Apne dosto ko bulao — aur challenge shuru.",
    chips=["Free · Open source", "Android APK", "Web app"],
    vo="तो बस — Peanut download करो। अपना room बनाओ, अपने दोस्तों को बुलाओ, और 30 दिन का challenge शुरू करो।",
    dur=13.0,
  ),
]

if __name__ == "__main__":
    (OUT / "scenes.json").write_text(json.dumps(SCENES, ensure_ascii=False, indent=1), encoding="utf-8")
    print("scenes:", len(SCENES), "total dur ~", round(sum(s["dur"] for s in SCENES), 1), "s")
